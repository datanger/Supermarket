clc,clear,close all;

run_all_parapara = 0;

dataFolder = uigetdir('','please select mat_data folder');
blf_dataFolder = uigetdir('','please select blf_data folder');
[mf4_info_filename, mf4_info_path] = uigetfile('*.mat', 'please select mf4_info.mat file');
mf4_file_list = fullfile(mf4_info_path,mf4_info_filename);
soft_ver = input('please input your ���� Soft Ver.: ',"s"); 
data_ver = input('please input your �f�[�^ ����(1:360, 2:360+): ',"s"); 
data_ver = str2double(data_ver);

isblf_avi = dir(fullfile(dataFolder,'*\*.avi'));
isblf_avi1 = dir(fullfile(dataFolder,'*.avi'));
if ~isempty(isblf_avi)
    max_videotime = 0;
    for i = 1:length(isblf_avi)
        aviPath = fullfile(isblf_avi(i).folder,isblf_avi(i).name);
        if contains(upper(isblf_avi(i).name), 'FRONT')
            newName = regexprep(isblf_avi(i).name, '(?i)(.*FRONT).*(\..*)', '$1$2');
            newPath = fullfile(isblf_avi(i).folder, newName);
            if ~strcmp(aviPath, newPath)
                movefile(aviPath, newPath);
                aviPath = newPath;  
                isblf_avi(i).name = newName;
            end
        end
        v = VideoReader(aviPath); 
        videotime = v.Duration; 
        if v.Duration > max_videotime
            max_videotime = v.Duration;
        end
    end
    VideoTimeInterval = round(max_videotime/100)*100;
elseif ~isempty(isblf_avi1)
    max_videotime = 0;
    for i = 1:length(isblf_avi1)
        aviPath = fullfile(isblf_avi1(i).folder,isblf_avi1(i).name);
        if contains(upper(isblf_avi1(i).name), 'FRONT')
            newName = regexprep(isblf_avi1(i).name, '(?i)(.*FRONT).*(\..*)', '$1$2');
            newPath = fullfile(isblf_avi1(i).folder, newName);
            if ~strcmp(aviPath, newPath)
                movefile(aviPath, newPath);
                aviPath = newPath;  
                isblf_avi1(i).name = newName;
            end
        end
        v = VideoReader(aviPath); 
        videotime = v.Duration; 
        if v.Duration > max_videotime
            max_videotime = v.Duration;
        end
    end
    VideoTimeInterval = round(max_videotime/100)*100;
else
    disp('cannot find avi path');
    VideoTimeInterval = input('please input Video time:',"s");
    VideoTimeInterval = str2double(VideoTimeInterval);
end
sliceData =0;
currentDir = pwd;
onlyMF4DataName = dir(strcat(dataFolder,'\*\*_ACore_XCP_remap.mat'));
if isempty(onlyMF4DataName)
    onlyMF4DataName = dir(strcat(dataFolder,'\*_ACore_XCP_remap.mat'));
    sliceData = 1;
end
parapara = 1;
exportExcel = 1;
dataDateArray = string([]);
for k = 1:length(onlyMF4DataName)
    vars = who;
    if ~sliceData
        simResName = strrep(onlyMF4DataName(k).name,'.mat','');
        folderName = split(onlyMF4DataName(k).folder,'\');
        dataDate = char(folderName(end));
        dataDate = string(dataDate(1:8));
        folderName = string(folderName(end));
        PlusName = string(regexp(folderName,'_Plus\d+','match'));
        onlyMF4DataNamePath = fullfile(onlyMF4DataName(k).folder,onlyMF4DataName(k).name);
    else
        simResName = strrep(onlyMF4DataName(k).name,'.mat','');
        folderName = onlyMF4DataName(k).folder;
        dataDate = simResName(2:16);
        PlusName = "";
        onlyMF4DataNamePath = fullfile(onlyMF4DataName(k).folder,onlyMF4DataName(k).name);
    end
    exportDate = char(dataDate);
    newStrDate = string(exportDate(1:8));
    if ~ismember(newStrDate, dataDateArray)
        dataDateArray = [dataDateArray, newStrDate];
    end
    load(onlyMF4DataNamePath);
    signals_time_sync;
    initial_plot_parapara;
    issue_extract;
    if exportExcel
        export_parsing_input_excel;
    end
    if parapara
        replot_parapara;
    end
    cmd = 'clearvars -except dataDate run_all_parapara ';
    cmd = [cmd, strjoin(vars, ' ')];
    eval(cmd);
end

for exportIndex = 1:length(dataDateArray)
    dataDate = dataDateArray(exportIndex);
    export_parsing_excel;
end

