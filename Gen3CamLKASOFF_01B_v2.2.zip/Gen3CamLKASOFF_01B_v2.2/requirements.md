1. <fix>(parapara): 修复impt数字显示错误的问题
2. <fix>(parapara):修复数据过短时生成parapara报错的问题
