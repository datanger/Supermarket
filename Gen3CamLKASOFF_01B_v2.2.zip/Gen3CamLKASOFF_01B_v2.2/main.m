clc,clear,close all;

dataFolder = uigetdir('','please select mat_data folder');
blf_dataFolder = uigetdir('','please select blf_data folder');
[mf4_info_filename, mf4_info_path] = uigetfile('*.mat', 'please select mf4_info.mat file');
mf4_file_list = fullfile(mf4_info_path,mf4_info_filename);
soft_ver = input('please input your software version: ',"s");

currentDir = pwd;
onlyMF4DataName = dir(strcat(dataFolder,'\*\*_ACore_XCP_remap.mat'));
parapara = 1;
exportExcel = 1;
for k = 1:length(onlyMF4DataName)
    vars = who;
    simResName = strrep(onlyMF4DataName(k).name,'.mat','');
    folderName = split(onlyMF4DataName(k).folder,'\');
    dataDate = char(folderName(end));
    dataDate = string(dataDate(1:8));
    folderName = string(folderName(end));
    dirName = strrep(onlyMF4DataName(k).folder,folderName,'');
    PlusName = string(regexp(folderName,'_Plus\d+','match'));
    onlyMF4DataNamePath = fullfile(onlyMF4DataName(k).folder,onlyMF4DataName(k).name);
    load(onlyMF4DataNamePath);
    signalsTimeSync;
    ViewerMF4_FromMF4ConvertedDataFrazki;
    if parapara
        CreateParapra;
    end
    if exportExcel
        ExportToExcel;
    end
    cmd = 'clearvars -except dataDate ';
    cmd = [cmd, strjoin(vars, ' ')];
    eval(cmd);
end

export_excel;
