function resim_time = getResimTimeByTypeAndOnlyTime(onlyType,onlyTime,onlyDic, getResimTimeDic)
    resim_time = '';
    
    all_only_time = onlyDic(onlyType);
    all_get_resim_time = getResimTimeDic(onlyType);

    for i = 1:length(all_only_time)
        if onlyTime== all_only_time(i)
            resim_time = all_get_resim_time(i);
            break
        end
    end
end