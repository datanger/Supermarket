1. <fix>(parapara): 修正问题点筛选逻辑，将生成parapara调整为仅生成问题点和问题点前一帧
2. <feat>(parapara): 增加开关控制是否生成全量parapara
