if swCANape == 1
    % Group1Time��50ms�����Ōv�����Ă���ϐ��̔z�񐔂��Ⴄ�ۂ̏���
    GroupTimeTmp = Group1Time; clear Group1Time;
    Group1Time = TimeColAdjst(GroupTimeTmp, length(saTldLaneCnvBusOut_saCurrentCtrlBusOut_log.saCtrlLnMode.signals.values(:,1)));
    clear GroupTimeTmp;
    % Group2Time��100ms�����Ōv�����Ă���ϐ��̔z�񐔂��Ⴄ�ۂ̏���
    if exist('Group3Time')
        fprintf('\nGroup3Time��100ms�̎��ԐM���Ƃ��Ďg���܂��B\n');
        clear Group2Time;
        Group2Time = Group3Time;
    end
    GroupTimeTmp = Group2Time; clear Group2Time;
    Group2Time = TimeColAdjst(GroupTimeTmp, length(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(:,1)));
    clear GroupTimeTmp;
    time = Group1Time;
elseif swCANape == 0
    time = S_Group1Time.signals.values;
    onFlg = 0;
    for i = 2:length(time)
        if time(i) ~= 0
            not0TimeSmpl = i;
            onFlg = 1;
        elseif onFlg
            time(i) = time(not0TimeSmpl)+(i-not0TimeSmpl)*0.05;
        end
    end    
end


%% CANape�f�[�^
if swCANape == 1
    %% 50ms�����v���̂���
    if sw50msLmOut
        % LM�o��Ctrl�Ԑ�
        S_lmVecCtrlLnPntX = saTldLaneCnvBusOut_saCurrentCtrlBusOut_log.saVecCtrlLnPntX;
        S_lmVecCtrlLnPntY = saTldLaneCnvBusOut_saCurrentCtrlBusOut_log.saVecCtrlLnPntY;
        S_lmCtrlLnExistFlg = saTldLaneCnvBusOut_saCurrentCtrlBusOut_log.saVecCtrlLnExistFlg;
        S_CtrlRangeStartIdx = saTldLaneCnvBusOut_saCurrentCtrlBusOut_log.saVecCtrlLnStartIdx;
        S_CtrlRangeEndIdx = saTldLaneCnvBusOut_saCurrentCtrlBusOut_log.saVecCtrlLnEndIdx;
    end

    % LM�o�͂̃J��������
    S_lmVecClinePointPosX = saTldLaneCnvBusOut_saCurrentCamBusOut_log.saVecClinePointPosX;
    S_lmVecClinePointPosY = saTldLaneCnvBusOut_saCurrentCamBusOut_log.saVecClinePointPosY;
    S_lmVecClineEndX.signals.values = saTldLaneCnvBusOut_saCurrentCamBusOut_log.saVecClineEndX.signals.values;
    S_lmVecClinebFlg.signals.values = saTldLaneCnvBusOut_saCurrentCamBusOut_log.saVecClinebFlg.signals.values;
%     S_lmVecClinePointPosX = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClinePointPosX;
%     S_lmVecClinePointPosY = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClinePointPosY;
%     S_lmVecClineEndX.signals.values = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClineEndX.signals.values;

    % �ԑ�/�ړ���
    S_egoSpd = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoSpd;
    S_lmodEgoMovX = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoMovX;
    S_lmodEgoMovY = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoMovY;
    S_lmodEgoRot = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoRot;
%     S_YawR = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoRateYaw;
    S_StrAgl = saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log.epsVecStrAngRad;
    
    % �J����C0
    S_MElaneDistanceY.signals.values = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadC0.signals.values;
%     S_MElaneDistanceY.signals.values = [saTldMiBusOut_fcCamBusOut_saCf1LaneBusOut_log.LanesC0LanePositionLeft.signals.values saTldMiBusOut_fcCamBusOut_saCf1LaneBusOut_log.LanesC0LanePositionRight.signals.values saTldMiBusOut_fcCamBusOut_saCf1LaneBusOut_log.LanesC0LanePositionNl.signals.values saTldMiBusOut_fcCamBusOut_saCf1LaneBusOut_log.LanesC0LanePositionNr.signals.values];
    S_MElaneExistenceProb.signals.values = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadConf.signals.values;
    S_MElaneQuality.signals.values = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadQuality.signals.values;
    S_MElaneType.signals.values = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadType.signals.values;

    % PL�o�H
    S_plPathX = saTldMiBusOut_plTldLtBusOut_plltBusOut_log.plltVecPathX;
    S_plPathY = saTldMiBusOut_plTldLtBusOut_plltBusOut_log.plltVecPathY;
    
    %% 100ms�����v���̂���
    if sw50msLmOut == 0
        S_lmVecCtrlLnPntX.signals.values = zeros(length(time),1353);
        S_lmVecCtrlLnPntY.signals.values = zeros(length(time),1353);
        S_lmCtrlLnExistFlg.signals.values = zeros(length(time),3);
        S_CtrlRangeStartIdx.signals.values = zeros(length(time),3);
        S_CtrlRangeEndIdx.signals.values = zeros(length(time),3);
        S_lmVecMapEgoLnPntX.signals.values = zeros(length(time),451);
        S_lmVecMapEgoLnPntY.signals.values = zeros(length(time),451);
        S_lmVecMapEgoLnStartIdx.signals.values = zeros(length(time),1);
        S_lmVecMapEgoLnEndIdx.signals.values = zeros(length(time),1);
    end
    S_lmInhStt.signals.values = zeros(length(time),1);
    S_lmLnMode.signals.values = zeros(length(time),1);
    S_lmPldStt.signals.values = zeros(length(time),1);
    S_mhStatus.signals.values = zeros(length(time),1);
    S_lmldVecLatFlg.signals.values = zeros(length(time),7);
    S_lmldVecLatPnt.signals.values = zeros(length(time),7);
    S_lmMpuRvudiffTime.signals.values = zeros(length(time),1);
    S_lmMapLnNum.signals.values = zeros(length(time),1);
    S_lmVecCtrlLnPntCurvature.signals.values = zeros(length(time),1353);
    S_lmmlXcorrStt.signals.values = zeros(length(time),1);
    S_lmmlXcorrIcpErrStt.signals.values = zeros(length(time),1);
    S_lmmlYrmStt.signals.values = zeros(length(time),1);
    S_lmldVecLaneLocMinus1.signals.values = zeros(length(time),3);
    S_mpuGnssOriLatLon.signals.values = zeros(length(time),3);
    S_lmmlXcorrDx.signals.values = zeros(length(time),1);
    S_lmmlXcorrDy.signals.values = zeros(length(time),1);
    S_lmmlXcorrDyaw.signals.values = zeros(length(time),1);
    S_lmmlYrmLocX.signals.values = zeros(length(time),1);
    S_lmmlYrmLocY.signals.values = zeros(length(time),1);
    S_lmmlYrmLocOri.signals.values = zeros(length(time),1);
    S_lmmiLanePntNum.signals.values = zeros(length(time),16);
    S_lmmiLtLinePntNum.signals.values = zeros(length(time),16);
    S_lmmiRtLinePntNum.signals.values = zeros(length(time),16);
    S_lmVecMapLnPntX.signals.values = zeros(length(time),7216);
    S_lmVecMapLnPntY.signals.values = zeros(length(time),7216);
    S_lmVecMapLnPntDistToLineL.signals.values = zeros(length(time),7216);
    S_lmVecMapLnPntDistToLineR.signals.values = zeros(length(time),7216);
    S_lmVecMapLnStartIdx.signals.values = zeros(length(time),16);
    S_lmVecMapLnEndIdx.signals.values = zeros(length(time),16);
    xcorrCamLNum = zeros(length(time),1);
    xcorrCamRNum = zeros(length(time),1);
    xcorrLNum = zeros(length(time),1);
    xcorrRNum = zeros(length(time),1);
    S_lmVecMapLnPntLineClassL.signals.values = zeros(length(time),7216);
    S_lmVecMapLnPntLineClassR.signals.values = zeros(length(time),7216);
    S_lmVecMapLnPntClass.signals.values = zeros(length(time),7216);
    if swMapBnd
        S_lmVecMapLnPntDistToBndL.signals.values = zeros(length(time),7216);
        S_lmVecMapLnPntDistToBndR.signals.values = zeros(length(time),7216);
        S_lmVecMapLnPntBndClassL.signals.values = zeros(length(time),7216);
        S_lmVecMapLnPntBndClassR.signals.values = zeros(length(time),7216);
    end
    
    for i = 1:length(Group1Time)
        for j = 2:length(Group2Time(1:end-1))
            if Group1Time(i)>Group2Time(j-1) && Group1Time(i)<=Group2Time(j)
                % LM�o��Ctrl�Ԑ�
                if sw50msLmOut == 0
                    S_lmVecCtrlLnPntX.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntX.signals.values(j,:);
                    S_lmVecCtrlLnPntY.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntY.signals.values(j,:);
                    S_lmCtrlLnExistFlg.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnExistFlg.signals.values(j,:);
                    S_CtrlRangeStartIdx.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnStartIdx.signals.values(j,:);
                    S_CtrlRangeEndIdx.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnEndIdx.signals.values(j,:);

                    S_lmVecMapEgoLnPntX.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapEgoBusOut_log.lmVecMapEgoLnPntX.signals.values(j,:);
                    S_lmVecMapEgoLnPntY.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapEgoBusOut_log.lmVecMapEgoLnPntY.signals.values(j,:);
                    S_lmVecMapEgoLnStartIdx.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapEgoBusOut_log.lmVecMapEgoLnStartIdx.signals.values(j,:);
                    S_lmVecMapEgoLnEndIdx.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapEgoBusOut_log.lmVecMapEgoLnEndIdx.signals.values(j,:);
                end
                % LM���X�e�[�^�X
                if isfield(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log,'lmInhStt')
                    S_lmInhStt.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmInhStt.signals.values(j,:);
                else
                    eMapSel = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),13) ...
                               || bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),14) ...
                               || bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),16) ...
                               || bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),17) ...
                               || bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),18) ...
                               || bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),19) ...
                               || bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),20) ...
                               || bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),21) ...
                               || bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),22) ...
                               || bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),25);
                    eYrmSel = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecStt.signals.values(j,11)~=0;
                    S_lmInhStt.signals.values(i,:) = bitset(S_lmInhStt.signals.values(i,:),3,eMapSel);
                    S_lmInhStt.signals.values(i,:) = bitset(S_lmInhStt.signals.values(i,:),5,eYrmSel);
                end
                S_lmLnMode.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values(j,:);
                S_lmPldStt.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:);
                S_mhStatus.signals.values(i,:) = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(j,:),13);
                S_lmldVecLatFlg.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmldVecLatFlg.signals.values(j,:);
                S_lmldVecLatPnt.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmldVecLatPnt.signals.values(j,:);
                % LM�o�͒n�}�Ԑ���
                S_lmMapLnNum.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmMapLnNum.signals.values(j,:);
                % ���H�ȗ�
                S_lmVecCtrlLnPntCurvature.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntCurvature.signals.values(j,:);
                S_lmmlXcorrStt.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecStt.signals.values(j,2);
                S_lmmlXcorrIcpErrStt.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecStt.signals.values(j,3);
                S_lmmlYrmStt.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecStt.signals.values(j,11);
                % LM���ԃ��[�����茋��(LM����)
                if isfield(saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log,'lmldVecLaneLocMinus1')
                    S_lmldVecLaneLocMinus1.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmldVecLaneLocMinus1.signals.values(j,:);
                else
                    S_lmldVecLaneLocMinus1.signals.values(i,:) = int16(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmCcOnlyPldStt.signals.values(j,:))-1;
                end
                if S_lmldVecLaneLocMinus1.signals.values(i,:) == 255
                    S_lmldVecLaneLocMinus1.signals.values(i,:) = -1;
                end
                % GNSS�ʒu
                S_mpuGnssOriLatLon.signals.values(i,2) = saTldMiBusOut_MPU_message4BusOut_log.gnssLatitude.signals.values(j,:);
                S_mpuGnssOriLatLon.signals.values(i,3) = saTldMiBusOut_MPU_message4BusOut_log.gnssLongitude.signals.values(j,:);
                % �␳��
                S_lmMpuRvudiffTime.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmiVecCorr.signals.values(j,4);
                S_lmmlXcorrDx.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlXcorrCorrX.signals.values(j,:);
                S_lmmlXcorrDy.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecCorrYawXY.signals.values(j,6);
                S_lmmlXcorrDyaw.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecCorrYawXY.signals.values(j,4);
                S_lmmlYrmLocX.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecCorrYawXY.signals.values(j,11);
                S_lmmlYrmLocY.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlYrmCorrY.signals.values(j,:);
                S_lmmlYrmLocOri.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlYrmCorrR.signals.values(j,:);
                % �n�}�_��
                S_lmmiLanePntNum.signals.values(i,:) = saTldMiBusOut_MPU_message1BusOut_log.lanePointNum.signals.values(j,:);
                S_lmmiLtLinePntNum.signals.values(i,:) = saTldMiBusOut_MPU_message1BusOut_log.leftLinePointNum.signals.values(j,:);
                S_lmmiRtLinePntNum.signals.values(i,:) = saTldMiBusOut_MPU_message1BusOut_log.rightLinePointNum.signals.values(j,:);
                % LM�o�͒n�}�_��
                S_lmVecMapLnPntX.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntX.signals.values(j,:);
                S_lmVecMapLnPntY.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntY.signals.values(j,:);
                S_lmVecMapLnPntDistToLineL.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntDistToLineL.signals.values(j,:);
                S_lmVecMapLnPntDistToLineR.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntDistToLineR.signals.values(j,:);
                S_lmVecMapLnStartIdx.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnStartIdx.signals.values(j,:);
                S_lmVecMapLnEndIdx.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnEndIdx.signals.values(j,:);
                S_lmVecMapLnPntLineClassL.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntLineClassL.signals.values(j,:);
                S_lmVecMapLnPntLineClassR.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntLineClassR.signals.values(j,:);
                S_lmVecMapLnPntClass.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntClass.signals.values(j,:);
                if swMapBnd
                    S_lmVecMapLnPntDistToBndL.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntDistToBndL.signals.values(j,:);
                    S_lmVecMapLnPntDistToBndR.signals.values(i,:) = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntDistToBndR.signals.values(j,:);
                end
                xcorrCamLNum(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecStt.signals.values(j,8);
                xcorrCamRNum(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecStt.signals.values(j,9);
                xcorrLNum(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecStt.signals.values(j,6);
                xcorrRNum(i,:) = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecStt.signals.values(j,7);
                break;
            end
        end
    end
    
%% GEN3 resim�f�[�^
elseif swCANape == 0
    if swSN ~= 1
        S_MElaneDistanceY.signals.values = S_laneC0PosIn.signals.values(:, 1:3:4);
        S_lmVecClineEndX.signals.values = S_lmVecClineEndX_Cam.signals.values;
        S_lmVecClinebFlg.signals.values = S_lmVecClinebFlg_Cam.signals.values;
    end
    
    S_lmVecClinePointPosX.signals.values = S_lmVecClinePointPosX_Cam.signals.values;
    S_lmVecClinePointPosY.signals.values = S_lmVecClinePointPosY_Cam.signals.values;
    S_egoSpd.signals.values = S_saEgoSpd.signals.values;
    
    S_lmodEgoMovX.signals.values(:,1) = S_saEgo50BusMovXYR.signals.values(:,1);
    S_lmodEgoMovY.signals.values(:,1) = S_saEgo50BusMovXYR.signals.values(:,2);
    S_lmodEgoRot.signals.values(:,1) = S_saEgo50BusMovXYR.signals.values(:,3); 
    
    % ME�̐M�����ۑ�����Ă��炸�A��ɕϐ�����Ɏg�p���Ă���݂̂ŁAplot�֌W�ł͎g�p����Ă��Ȃ��̂ŁA0����
    S_lineCamXMe.signals.values = 0;
    S_lineCamYMe.signals.values = 0;
    
    S_MElaneExistenceProb.signals.values = S_lmVecClineProbability_Cam.signals.values;
    S_MElaneQuality.signals.values = S_lmVecClineQuality_Cam.signals.values;
    S_MElaneType.signals.values = S_lmVecClineType_Cam.signals.values;
    
    S_plPathX.signals.values = zeros(length(time),51);
    S_plPathY.signals.values = zeros(length(time),51);

    if swComp
        compDataNum = length(dirNameOrg);
        for i = 1:compDataNum
            ORG{i}.S_lmVecClinePointPosX.signals.values = ORG{i}.S_lmVecClinePointPosX_Cam.signals.values;
            ORG{i}.S_lmVecClinePointPosY.signals.values = ORG{i}.S_lmVecClinePointPosY_Cam.signals.values;
            ORG{i}.S_lineCamXMe.signals.values = 0;
            ORG{i}.S_lineCamYMe.signals.values = 0;
            ORG{i}.S_MElaneExistenceProb.signals.values = ORG{i}.S_lmVecClineProbability_Cam.signals.values;
            ORG{i}.S_MElaneQuality.signals.values = ORG{i}.S_lmVecClineQuality_Cam.signals.values;
            ORG{i}.S_MElaneType.signals.values = ORG{i}.S_lmVecClineType_Cam.signals.values;
            if swSN ~= 1
                ORG{i}.S_lmVecClinebFlg.signals.values = ORG{i}.S_lmVecClinebFlg_Cam.signals.values;
            end
        end
    end
end

% LC���Ă���ӏ���Ctrl�Ԑ��̎��ԉ����тŔ��f
if exist('S_lmslLeftLcFlg')==0
    S_lmslLeftLcFlg.signals.values = CalcCtrlJump(...
        S_lmCtrlLnExistFlg.signals.values(:, 2), ...
        S_lmVecCtrlLnPntY.signals.values(:,602), ...
        time);
    % ���left��right��xor���Ƃ�̂�right��0�ŗǂ�
end

% % ���݂��Ă��Ȃ��ϐ���0�ő��
if exist('S_lmmlXcorrIcpDx') == 0
    S_lmmlXcorrIcpDx.signals.values = zeros(length(time),1);
end
% if exist('S_mhStatus') == 0
%     S_mhStatus.signals.values = zeros(length(time),1);
% end
% if exist('S_mpuGnssOriLatLon') == 0
%     S_mpuGnssOriLatLon.signals.values = zeros(length(time),3);
% end
% if exist('S_lmVecMapLnStartIdx') == 0
%     S_lmVecMapLnStartIdx.signals.values = zeros(length(time),16);
% end
% if exist('S_lmVecMapLnEndIdx') == 0
%     S_lmVecMapLnEndIdx.signals.values = zeros(length(time),16);
% end
if exist('S_lmmlXcorrIcpErr') == 0
    S_lmmlXcorrIcpErr.signals.values = zeros(length(time),1);
end
% if exist('S_lmslLeftLcFlg') == 0
%     S_lmslLeftLcFlg.signals.values = zeros(length(time),1);
% end
if exist('S_lmslRightLcFlg') == 0
    S_lmslRightLcFlg.signals.values = zeros(length(time),1);
end
% if exist('xcorrCamLNum') == 0
%     xcorrCamLNum = zeros(length(time),1);
% end
% if exist('xcorrCamRNum') == 0
%     xcorrCamRNum = zeros(length(time),1);
% end
% if exist('xcorrLNum') == 0
%     xcorrLNum = zeros(length(time),1);
% end
% if exist('xcorrRNum') == 0
%     xcorrRNum = zeros(length(time),1);
% end
% 
% % �c�ʒu�␳�Ɏg�p����J�����ƒn�}����
% if exist('S_lmmlXcorrDx') == 0
%     S_lmmlXcorrDx.signals.values = zeros(length(time),1);
% end
% if exist('S_lmmlXcorrDy') == 0
%     S_lmmlXcorrDy.signals.values = zeros(length(time),1);
% end
% if exist('S_lmmlXcorrDyaw') == 0
%     S_lmmlXcorrDyaw.signals.values = zeros(length(time),1);
% end
% if exist('S_lmmlYrmLocX') == 0
%     S_lmmlYrmLocX.signals.values = zeros(length(time),1);
% end
% if exist('S_lmmlYrmLocY') == 0
%     S_lmmlYrmLocY.signals.values = zeros(length(time),1);
% end
% if exist('S_lmmlYrmLocOri') == 0
%     S_lmmlYrmLocOri.signals.values = zeros(length(time),1);
% end
% if exist('S_lmmlMatchT') == 0
%     S_lmmlMatchT.signals.values = zeros(length(time),2);
% end
% if exist('S_lmmlMatchR') == 0
%     S_lmmlMatchR.signals.values = zeros(length(time),4);
% end
% 
% if exist('S_lmmlXcorrStt') == 0
%     S_lmmlXcorrStt.signals.values = zeros(length(time),1);
% end
% if exist('S_lmmlXcorrIcpErrStt') == 0
%     S_lmmlXcorrIcpErrStt.signals.values = zeros(length(time),1);
% end
% if exist('S_lmmlYrmStt') == 0
%     S_lmmlYrmStt.signals.values = zeros(length(time),1);
% end
% if exist('S_lmldVecLaneLocMinus1') == 0
%     S_lmldVecLaneLocMinus1.signals.values = zeros(length(time),3);
% end
% if exist('S_lmmlXcorrIcpCorrDlt') == 0
%     S_lmmlXcorrIcpCorrDlt.signals.values = zeros(length(time),3);
% end
% if exist('S_lmmlXcorrIcpPerrMin') == 0
%     S_lmmlXcorrIcpPerrMin.signals.values = zeros(length(time),408);
% end
% if exist('S_lmmlXcorrIcpVecDist') == 0
%     S_lmmlXcorrIcpVecDist.signals.values = zeros(length(time),408);
% end
% if exist('S_lmmlXcorrIdxMin') == 0
%     S_lmmlXcorrIdxMin.signals.values = zeros(length(time),1);
% end
% if exist('S_lmmlBfrMatchLine') == 0
%     S_lmmlBfrMatchLine.signals.values = zeros(length(time),500);
% end
% if exist('S_lmmlFltTc') == 0
%     S_lmmlFltTc.signals.values = zeros(length(time),3);
% end
% 
% %---------------------------�G���[���p���s�X�N���v�g------------------------------��
% if exist('S_lmmlXCorrMLB') == 0
%     S_lmmlXCorrMLB.signals.values = zeros(length(time),1000);
% end
% if exist('S_lmmlXCorrMRB') == 0
%     S_lmmlXCorrMRB.signals.values = zeros(length(time),1000);
% end
% if exist('S_lmmlXCorrCamLB') == 0
%     S_lmmlXCorrCamLB.signals.values = zeros(length(time),1000);
% end
% if exist('S_lmmlXCorrCamRB') == 0
%     S_lmmlXCorrCamRB.signals.values = zeros(length(time),1000);
% end
% %---------------------------�G���[���p���s�X�N���v�g------------------------------��
% 
% 
% %-------------------------------Comp�f�[�^�̕ϐ��⊮����(�ǉ�)------------------------------------%
% if swComp
%     for dc = 1:compDataNum
%         samples = length(time);
%         if exist('ORG{dc}.S_lmmlXcorrIcpDx', 'var') == 0
%             ORG{dc}.S_lmmlXcorrIcpDx.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_mhStatus', 'var') == 0
%             ORG{dc}.S_mhStatus.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_mpuGnssOriLatLon', 'var') == 0
%             ORG{dc}.S_mpuGnssOriLatLon.signals.values = zeros(length(time),3);
%         end
%         if exist('ORG{dc}.S_lmVecMapLnStartIdx', 'var') == 0
%             ORG{dc}.S_lmVecMapLnStartIdx.signals.values = zeros(length(time),16);
%         end
%         if exist('ORG{dc}.S_lmVecMapLnEndIdx', 'var') == 0
%             ORG{dc}.S_lmVecMapLnEndIdx.signals.values = zeros(length(time),16);
%         end
%         if exist('ORG{dc}.S_lmmlXcorrIcpErr', 'var') == 0
%             ORG{dc}.S_lmmlXcorrIcpErr.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmslLeftLcFlg', 'var') == 0
%             ORG{dc}.S_lmslLeftLcFlg.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmslRightLcFlg', 'var') == 0
%             ORG{dc}.S_lmslRightLcFlg.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.xcorrCamLNum', 'var') == 0
%             ORG{dc}.xcorrCamLNum.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.xcorrCamRNum', 'var') == 0
%             ORG{dc}.xcorrCamRNum.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.xcorrLNum', 'var') == 0
%             ORG{dc}.xcorrLNum.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.xcorrRNum', 'var') == 0
%             ORG{dc}.xcorrRNum.signals.values = zeros(length(time),1);
%         end
%         
%         % �c�ʒu�␳�Ɏg�p����J�����ƒn�}����
%         if exist('ORG{dc}.S_lmmlXcorrDx', 'var') == 0
%             ORG{dc}.S_lmmlXcorrDx.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmmlXcorrDy', 'var') == 0
%             ORG{dc}.S_lmmlXcorrDy.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmmlXcorrDyaw', 'var') == 0
%             ORG{dc}.S_lmmlXcorrDyaw.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmmlYrmLocX', 'var') == 0
%             ORG{dc}.S_lmmlYrmLocX.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmmlYrmLocY', 'var') == 0
%             ORG{dc}.S_lmmlYrmLocY.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmmlYrmLocOri', 'var') == 0
%             ORG{dc}.S_lmmlYrmLocOri.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmmlMatchT', 'var') == 0
%             ORG{dc}.S_lmmlMatchT.signals.values = zeros(length(time),2);
%         end
%         if exist('ORG{dc}.S_lmmlMatchR', 'var') == 0
%             ORG{dc}.S_lmmlMatchR.signals.values = zeros(length(time),4);
%         end
%         
%         if exist('ORG{dc}.S_lmmlXcorrStt', 'var') == 0
%             ORG{dc}.S_lmmlXcorrStt.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmmlXcorrIcpErrStt', 'var') == 0
%             ORG{dc}.S_lmmlXcorrIcpErrStt.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmmlYrmStt', 'var') == 0
%             ORG{dc}.S_lmmlYrmStt.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmldVecLaneLocMinus1', 'var') == 0
%             ORG{dc}.S_lmldVecLaneLocMinus1.signals.values = zeros(length(time),3);
%         end
%         if exist('ORG{dc}.S_lmmlXcorrIcpCorrDlt', 'var') == 0
%             ORG{dc}.S_lmmlXcorrIcpCorrDlt.signals.values = zeros(length(time),3);
%         end
%         if exist('ORG{dc}.S_lmmlXcorrIcpPerrMin', 'var') == 0
%             ORG{dc}.S_lmmlXcorrIcpPerrMin.signals.values = zeros(length(time),408);
%         end
%         if exist('ORG{dc}.S_lmmlXcorrIcpVecDist', 'var') == 0
%             ORG{dc}.S_lmmlXcorrIcpVecDist.signals.values = zeros(length(time),408);
%         end
%         if exist('ORG{dc}.S_lmmlXcorrIdxMin', 'var') == 0
%             ORG{dc}.S_lmmlXcorrIdxMin.signals.values = zeros(length(time),1);
%         end
%         if exist('ORG{dc}.S_lmmlBfrMatchLine', 'var') == 0
%             ORG{dc}.S_lmmlBfrMatchLine.signals.values = zeros(length(time),500); 
%         end
%         if exist('ORG{dc}.S_lmmlFltTc', 'var') == 0
%             ORG{dc}.S_lmmlFltTc.signals.values = zeros(length(time),3);
%         end
%         
%         if exist('ORG{dc}.S_lmmlXCorrCamLX', 'var') == 0
%             ORG{dc}.S_lmmlXCorrCamLX.signals.values = zeros(samples, 1050);
%             ORG{dc}.S_lmmlXCorrCamLY.signals.values = zeros(samples, 1050);
%             ORG{dc}.S_lmmlXCorrCamRX.signals.values = zeros(samples, 1050);
%             ORG{dc}.S_lmmlXCorrCamRY.signals.values = zeros(samples, 1050);
%             ORG{dc}.S_lmmlXCorrCamLB.signals.values = zeros(samples, 1050);
%             ORG{dc}.S_lmmlXCorrCamRB.signals.values = zeros(samples, 1050);
%             
%             ORG{dc}.S_lmmlXCorrMLX.signals.values = zeros(samples, 1100);
%             ORG{dc}.S_lmmlXCorrMLY.signals.values = zeros(samples, 1100);
%             ORG{dc}.S_lmmlXCorrMRX.signals.values = zeros(samples, 1100);
%             ORG{dc}.S_lmmlXCorrMRY.signals.values = zeros(samples, 1100);
%             
%             ORG{dc}.S_lmmlXCorrMLB.signals.values = zeros(samples, 1100);
%             ORG{dc}.S_lmmlXCorrMRB.signals.values = zeros(samples, 1100);
%         end
%     end
% end
%-------------------------------Comp�f�[�^�̕ϐ��⊮����(�ǉ�)------------------------------------%

function ctrlJump = CalcCtrlJump(exist_flg, ctrl_y, time)
    ctrlJump = zeros(length(time),1);
    for i = 2:length(time)
        if exist_flg(i) == 0 || exist_flg(i - 1) == 0
            % Ctrl�Ԑ����Ȃ��̂ŉ������Ȃ�
            continue;
        end
        if abs(ctrl_y(i) - ctrl_y(i - 1)) > 2
            ctrlJump(i) = 1;
        end
    end
end

function GroupTime = TimeColAdjst(GroupTimeIn, varLen)
    % Group2Time��100ms�����Ōv�����Ă���ϐ��̔z�񐔂��Ⴄ�ۂ̏���
    lenGroupTime = length(GroupTimeIn);
    lenGroupTimeVar = varLen;
    if lenGroupTime > lenGroupTimeVar
        GroupTime = GroupTimeIn(1:end-1);
    elseif lenGroupTime < lenGroupTimeVar
        GroupTime = [GroupTimeIn(1:end) GroupTimeIn(end)+0.1];
    else
        GroupTime = GroupTimeIn;
    end
end
