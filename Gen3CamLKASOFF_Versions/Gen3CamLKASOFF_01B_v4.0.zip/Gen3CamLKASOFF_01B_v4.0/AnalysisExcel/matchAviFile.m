function [aviName, aviMatchResult] = matchAviFile(aviDir,curPoint,simResName)
    VideoTimeInterval = evalin('base', 'VideoTimeInterval');
    
    names = {aviDir.name};
    [~, idx] = sort(names);
    aviDir = aviDir(idx);

    videoTotalTime = 0;
    aviMatchResult = 0;
    aviName = 0;

    if isempty(aviDir)
        return;
    end
    startTime = string(strrep(simResName,'_ACore_XCP_remap.mat',''));
    startTime = datetime(startTime,'InputFormat','yyyyMMdd_HHmmss');


    for k = 1:length(aviDir)
        aviName = aviDir(k).name;
        aviFolder = aviDir(k).folder;
        aviPath = fullfile(aviFolder,aviName);

        v = VideoReader(aviPath);
        videotime = v.Duration;
        videoTotalTime = videoTotalTime + videotime;
    
        if contains(aviDir(1).name, '_AXIS_FRONT.avi')
            curTime = string(strrep(aviDir(k).name,'_AXIS_FRONT.avi',''));
            curTime = datetime(curTime,'InputFormat','yyyyMMdd_HHmmss');
            calculateTime = curTime + duration(0,0,mod(curPoint,VideoTimeInterval)) - startTime;
        elseif contains(aviDir(1).name, '_AXIS_Front.avi')
            curTime = string(strrep(aviDir(k).name,'_AXIS_Front.avi',''));
            curTime = datetime(curTime,'InputFormat','yyyyMMdd_HHmmss');
            calculateTime = curTime + duration(0,0,mod(curPoint,VideoTimeInterval)) - startTime;
        else
            curTime = string(strrep(aviDir(k).name,'_Axis_Camera_Front.avi',''));
            curTime = datetime(curTime,'InputFormat','yyyyMMdd_HHmmss');
            calculateTime = curTime + duration(0,0,mod(curPoint,VideoTimeInterval)) - startTime;
        end
        
%         if curPoint <= videoTotalTime && abs(curPoint - seconds(calculateTime)) < 120
        if abs(curPoint - seconds(calculateTime)) < 120
            aviMatchResult = 1;
            break;
        end
    end
end