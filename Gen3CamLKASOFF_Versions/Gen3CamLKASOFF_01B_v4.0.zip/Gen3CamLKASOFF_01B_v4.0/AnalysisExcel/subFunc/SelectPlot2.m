rectangle(ax99,'Position',[-veclWidth/2 -veclLength/2 veclWidth veclLength],'FaceColor','y');
for i = 1:length(swDispCont)
    if swDispCont(i) == 2 || swDispCont(i) == 3 || swDispCont(i) == 5
        for ln = 0:15
            if mapLaneNum(l) > ln
                lnPntNum = 451;
                if ln == 0,      color = 'r'; marker = '.';
                elseif ln == 1,  color = 'b'; marker = '.';
                elseif ln == 2,  color = 'g'; marker = '.';
                elseif ln == 3,  color = 'm'; marker = '.';
                elseif ln == 4,  color = 'c'; marker = '.';
                elseif ln == 5,  color = '#EDB120'; marker = '.'; % オレンジ
                elseif ln == 6,  color = '#7E2F8E'; marker = '.'; % 紫
                elseif ln == 7,  color = '#A2142F'; marker = '.'; % 茶
                elseif ln == 8,  color = 'r'; marker = '+';
                elseif ln == 9,  color = 'b'; marker = '+';
                elseif ln == 10, color = 'g'; marker = '+';
                elseif ln == 11, color = 'm'; marker = '+';
                elseif ln == 12, color = 'c'; marker = '+';
                elseif ln == 13, color = '#EDB120'; marker = '+'; % オレンジ
                elseif ln == 14, color = '#7E2F8E'; marker = '+'; % 紫
                elseif ln == 15, color = '#A2142F'; marker = '+'; % 茶
                end
                % 受信時間合わせした自己位置ベース地図区画線・中心線
                if swDispCont(i) == 2
                    if chkbox_MapLane.Value
                        plotMapLaneFunc(ax99,l,ln,mapCtMpuX,mapCtMpuY,mapLanePntNum(l,:),color,marker,swLmmlMapMinimize);
                    end
                    if chkbox_MapLine.Value
                        plotMapLaneFunc(ax99,l,ln,mapLtMpuX,mapLtMpuY,mapLtLinePntNum(l,:),color,marker,swLmmlMapMinimize);
                        plotMapLaneFunc(ax99,l,ln,mapRtMpuX,mapRtMpuY,mapRtLinePntNum(l,:),color,marker,swLmmlMapMinimize);
                    end
                end
                % LM自己位置ベース地図区画線・中心線
                if swDispCont(i) == 3
                    if chkbox_MapLane.Value
                        plotMapLaneFunc(ax99,l,ln,mapCtLmX,mapCtLmY,mapLanePntNum(l,:),color,marker,swLmmlMapMinimize);
                    end
                    if chkbox_MapLine.Value
                        plotMapLaneFunc(ax99,l,ln,mapLtLmX,mapLtLmY,mapLtLinePntNum(l,:),color,marker,swLmmlMapMinimize);
                        plotMapLaneFunc(ax99,l,ln,mapRtLmX,mapRtLmY,mapRtLinePntNum(l,:),color,marker,swLmmlMapMinimize);
                    end
                end
                % LM出力地図区画線・中心線
                if swDispCont(i) == 5
                    if chkbox_MapLane.Value
                        plotLmOutMapLaneFunc(ax99,l,ln,cMpXOut,cMpYOut,cMpStartIdxOut,cMpEndIdxOut,cMpCtClass(l,:),color,marker,0);
                        if swMapClass
                            plotLmOutMapLaneCtClassFunc(ax99,l,ln,cMpXOut,cMpYOut,cMpStartIdxOut,cMpEndIdxOut,cMpCtClass(l,:),color);
                        end
                    end
                    if chkbox_MapLine.Value
                        if swMapClass
                            plotLmOutMapLineClassFunc(ax99,l,ln,cMpXOut,cMpLtYOut,cMpStartIdxOut,cMpEndIdxOut,cMpLtClassOut(l,:),color);
                            plotLmOutMapLineClassFunc(ax99,l,ln,cMpXOut,cMpRtYOut,cMpStartIdxOut,cMpEndIdxOut,cMpRtClassOut(l,:),color);
                        else
                            plotLmOutMapLaneFunc(ax99,l,ln,cMpXOut,cMpLtYOut,cMpStartIdxOut,cMpEndIdxOut,cMpLtClassOut(l,:),color,marker,1);
                            plotLmOutMapLaneFunc(ax99,l,ln,cMpXOut,cMpRtYOut,cMpStartIdxOut,cMpEndIdxOut,cMpRtClassOut(l,:),color,marker,1);
                        end
                    end
				    if chkbox_MapBdr.Value && swMapBnd
                        plotLmOutMapLaneFunc(ax99,l,ln,cMpXOut,cBndLtYOut,cMpStartIdxOut,cMpEndIdxOut,ones(size(cMpXOut)),color,marker,1);
                        plotLmOutMapLaneFunc(ax99,l,ln,cMpXOut,cBndRtYOut,cMpStartIdxOut,cMpEndIdxOut,ones(size(cMpXOut)),color,marker,1);
				    end
                end
            else
                break;
            end
        end
    end

    % Ctrl車線    
    if swDispCont(i) == 4
        if chkbox_Ctrl.Value
            if cOutNum(l) ~= 0
                for ln = 0:cOutNum(l)-1
                    plotLmOutCtrlLaneFunc(ax99,l,ln,lmCtrlX,lmCtrlY,cOutStartIdx,cOutEndIdx,1);
                    if swComp && (chkbox_Comp1.Value || chkbox_Comp2.Value)
                        for dc = 1:compDataNum
                            plotLmOutCtrlLaneFunc(ax99,l,ln,ctrlXOrg{dc},ctrlYOrg{dc},cOutStartIdxOrg{dc},cOutEndIdxOrg{dc},dc+1);
                        end
                    end
                end
                ln = 1;
                if chkbox_MpuBs.Value
                    plotLmOutCtrlLaneFunc(ax99,l,ln,lmCtrlXBsMpuLoc,lmCtrlYBsMpuLoc,cOutStartIdx(:,2),cOutEndIdx(:,2),101); hold on;
                end
                if chkbox_YrmBs.Value
                    plotLmOutCtrlLaneFunc(ax99,l,ln,lmCtrlXBsYrmLoc,lmCtrlYBsYrmLoc,cOutStartIdx(:,2),cOutEndIdx(:,2),102); hold on; 
                end
                if chkbox_DrBs.Value
                    plotLmOutCtrlLaneFunc(ax99,l,ln,lmCtrlXBsDrLoc,lmCtrlYBsDrLoc,cOutStartIdx(:,2),cOutEndIdx(:,2),103); hold on;
                end
            end
        end
    end

    % カメラC0軌跡
    if (swDispCont(i) == 6) || (swDispCont(i) == 61)
        if chkbox_camC0Trace.Value
            plotCamC0TraceFunc(ax99,l,TransClineLPosX,TransClineLPosY,TransClineRPosX,TransClineRPosY,TransClineCPosX,TransClineCPosY,swC0Stt,TransClineLStt, TransClineRStt, TransClineCStt, swDispCont(i));
            % 走路誤差量を算出するC0軌跡の2点を緑色でプロットする場合、下記2文のコメントアウトを外す
%             plot(ax99,TransClineCPosY(l,c0IdxFl(l)),TransClineCPosX(l,c0IdxFl(l)),'go','MarkerFaceColor','g'); hold on;
%             plot(ax99,TransClineCPosY(l,c0IdxCe(l)),TransClineCPosX(l,c0IdxCe(l)),'go','MarkerFaceColor','g'); hold on;
        end
    end

    % LM出力カメラ区画線    
    if swDispCont(i) == 7
        if chkbox_camLine.Value
            plotCamLineFunc(ax99,l,lmCamX,lmCamY );
        end
    end

    % PLpath形状  
    if swDispCont(i) == 8
        plot(ax99,S_plPathY.signals.values(l,:),S_plPathX.signals.values(l,:),'ko');
    end

        % 物標情報
    if swDispCont(i) == 9
        vecObsID = S_pfVecObjId.signals.values(l,:);
        vecObsX = S_pfVecObjPosX.signals.values(l,:);
        vecObsY = S_pfVecObjPosY.signals.values(l,:);
%         vecObsVelX = Data.ObsVelXAll(l,:);
%         vecObsVelY = Data.ObsVelYAll(l,:);
        vecObsL = S_pfVecObjLength.signals.values(l,:);
        vecObsW = S_pfVecObjWidth.signals.values(l,:);
        objsizetmp = size(S_pfVecObjPosX.signals.values);
        vecObsYaw = cast(zeros(length(time),objsizetmp(2)),'single');
        for obsIdx=1:30
            if vecObsID(obsIdx)~=0
                id    = vecObsID(obsIdx);
                x     = vecObsX(obsIdx);
                y     = vecObsY(obsIdx);
%                 vx    = vecObsVelX(obsIdx);
%                 vy    = vecObsVelY(obsIdx);
                L     = vecObsL(obsIdx);
                w     = vecObsW(obsIdx);
                theta = vecObsYaw(obsIdx);
                costh = cos(theta);
                sinth = sin(theta);
                tl_x =  L*0.5;                          % 蠏榊ｿ休
                tl_y =  w*0.5;                          % 蠏榊ｿ及
                tr_x =  L*0.5;                          % 蝪?蠢休
                tr_y = -w*0.5;                          % 蝪?蠢及
                br_x = -L*0.5;                          % 蝪?螢度
                br_y = -w*0.5;                          % 蝪?螢土
                bl_x = -L*0.5;                          % 蠏榊｣度
                bl_y =  w*0.5;                          % 蠏榊｣土
                x1 = tl_x*costh - tl_y*sinth + x;       % 蠏榊ｿ休蠏玲?玲寇蟋ｺ
                y1 = tl_x*sinth + tl_y*costh + y;       % 蠏榊ｿ及蠏玲?玲寇蟋ｺ
                x2 = tr_x*costh - tr_y*sinth + x;       % 蝪?蠢休蠏玲?玲寇蟋ｺ
                y2 = tr_x*sinth + tr_y*costh + y;       % 蝪?蠢及蠏玲?玲寇蟋ｺ
                x3 = br_x*costh - br_y*sinth + x;       % 蝪?螢度蠏玲?玲寇蟋ｺ
                y3 = br_x*sinth + br_y*costh + y;       % 蝪?螢土蠏玲?玲寇蟋ｺ
                x4 = bl_x*costh - bl_y*sinth + x;       % 蠏榊｣度蠏玲?玲寇蟋ｺ
                y4 = bl_x*sinth + bl_y*costh + y;       % 蠏榊｣土蠏玲?玲寇蟋ｺ
                X = [x1 x2 x3 x4];                      % 證疲?怜⊆謐?謠ｰX
                Y = [y1 y2 y3 y4];                      % 證疲?怜⊆謐?謠ｰY
                VX = [(x1+x4)/2 (x2+x3)/2 x];
                VY = [y+0.1 y-0.1 y];
                obs(obsIdx) = patch(ax99, Y, X, 'yellow');
                set(obs(obsIdx), 'FaceAlpha', 0.5); 
            else
                obs(obsIdx) = patch(ax99, [0,0,0,0], [0,0,0,0], 'yellow');
            end
        end
    end
end

function plotCamC0TraceFunc(ax99,smpl,c0LX,c0LY,c0RX,c0RY,c0CX,c0CY,swC0Stt,c0SttL,c0SttR,c0SttC,swDisp)
    if swC0Stt
        plot(ax99,c0LY(smpl,boolean(c0SttL(smpl,:))),c0LX(smpl,boolean(c0SttL(smpl,:))),'ro','MarkerFaceColor','r'); hold on;
        plot(ax99,c0LY(smpl,boolean(~c0SttL(smpl,:))),c0LX(smpl,boolean(~c0SttL(smpl,:))),'o','MarkerEdgeColor','#808080','MarkerFaceColor','#808080'); hold on;
        plot(ax99,c0RY(smpl,boolean(c0SttR(smpl,:))),c0RX(smpl,boolean(c0SttR(smpl,:))),'ro','MarkerFaceColor','r'); hold on;
        plot(ax99,c0RY(smpl,boolean(~c0SttR(smpl,:))),c0RX(smpl,boolean(~c0SttR(smpl,:))),'o','MarkerEdgeColor','#808080','MarkerFaceColor','#808080'); hold on;
        if swDisp == 6
            plot(ax99,c0CY(smpl,boolean(c0SttC(smpl,:))),c0CX(smpl,boolean(c0SttC(smpl,:))),'ro','MarkerFaceColor','r'); hold on;
            plot(ax99,c0CY(smpl,boolean(~c0SttC(smpl,:))),c0CX(smpl,boolean(~c0SttC(smpl,:))),'o','MarkerEdgeColor','#808080','MarkerFaceColor','#808080'); hold on;
        end
    else
        plot(ax99,c0LY(smpl,:),c0LX(smpl,:),'ro','MarkerFaceColor','r'); hold on;
        plot(ax99,c0RY(smpl,:),c0RX(smpl,:),'ro','MarkerFaceColor','r'); hold on;
        if swDisp == 6
            plot(ax99,c0CY(smpl,:),c0CX(smpl,:),'ro','MarkerFaceColor','r'); hold on;
        end
    end
end

function plotCamLineFunc(ax99,smpl,camX,camY)
    len = length( camY( smpl, : ) );
    leftCamX = camX( smpl, 1:len/4 );
    rightCamX = camX( smpl, len/4+1:len*2/4 );
    leftOutCamX = camX( smpl, len*2/4+1:len*3/4 );
    rightOutCamX = camX( smpl, len*3/4+1:len*4/4 );
    
    leftCamY = camY( smpl, 1:len/4 );
    rightCamY = camY( smpl, len/4+1:len*2/4 );
    leftOutCamY = camY( smpl, len*2/4+1:len*3/4 );
    rightOutCamY = camY( smpl, len*3/4+1:len*4/4 );
    
    leftIndex = leftCamY ~= 0 | leftCamX ~= 0;
    rightIndex = rightCamX ~= 0 \ rightCamY ~= 0;
    leftOutIndex = leftOutCamX ~= 0 | leftOutCamY ~= 0;
    rightOutIndex = rightOutCamY ~= 0 | rightOutCamX ~= 0;
    
    plot(ax99,leftCamY( leftIndex ),leftCamX( leftIndex ),'k.' ); hold on;
    plot(ax99,rightCamY( rightIndex ),rightCamX( rightIndex ),'k.' ); hold on;
    plot(ax99,leftOutCamY( leftOutIndex ),leftOutCamX( leftOutIndex ),'.', "Color", [ 0.5 0.5 0.5 ] ); hold on;
    plot(ax99,rightOutCamY( rightOutIndex ),rightOutCamX( rightOutIndex ),'.', "Color", [ 0.5 0.5 0.5 ] ); hold on;

end

function plotLmOutCtrlLaneFunc(ax99,smpl,ln,lnX,lnY,startIdx,endIdx,sw)
    lnPntNum = 451;
    % ctrl車線は左車線・自車線・右車線の順に配列化されているため、ln=0(1車線)のときは452～902配列を参照する
    if ln == 0
        ln = 1;
    elseif ln == 1
        ln = 0;
    end
    
    if sw == 1 && ln == 1
        color = 'bp';
    else
        if sw == 1
            color = 'bo';
        elseif sw == 2
            color = 'co';
        elseif sw == 3
            color = 'ko';
        elseif sw == 101
            color = 'g+';
        elseif sw == 102
            color = 'm+';
        elseif sw == 103
            color = 'k+';
        end
    end
    
    if startIdx(smpl,ln+1) ~= -1 && endIdx(smpl,ln+1) ~= -1
        plot(ax99,lnY(smpl,lnPntNum*ln+startIdx(smpl,ln+1) + 1:lnPntNum*ln+endIdx(smpl,ln+1)+1),lnX(smpl,lnPntNum*ln+startIdx(smpl,ln+1) + 1:lnPntNum*ln+endIdx(smpl,ln+1)+1),color); hold on;
    end
end

function plotLmOutMapLaneFunc(ax99,smpl,ln,lnX,lnY,startIdx,endIdx,class,color,marker,swLine)
% swLineは入力データが区画線ならば1, 中心線ならば0を入れる
    lnPntNum = 451;
    if startIdx(smpl,ln+1) ~= -1 && endIdx(smpl,ln+1)+1 ~= -1
        idxDir = lnPntNum*ln+startIdx(smpl,ln+1)+1:lnPntNum*ln+endIdx(smpl,ln+1)+1;
        y = lnY(smpl,idxDir);
        x = lnX(smpl,idxDir);
        if swLine
            validBit = (bitget(class(idxDir),1)==0); % 有効フラグ
        else
            validBit = (bitget(class(idxDir),1)~=0); % 有効フラグ
        end
        plot(ax99,y(validBit),x(validBit),'Color',color,'Marker',marker,'LineStyle','none'); hold on;
    end
end

function plotLmOutMapLineClassFunc(ax99,smpl,ln,lnX,lnY,startIdx,endIdx,class,color)
    % 地図区画線各ビット定義
    % 0bit       線なし
    % 1bit       白実線
    % 2bit　　　 白破線
    % 3bit　　　 黄実線
    % 4bit　　　 跨ぎ線フラグ
    % 5bit　　　 仮想線フラグ
    lnPntNum = 451;
    if startIdx(smpl,ln+1) ~= -1 && endIdx(smpl,ln+1)+1 ~= -1
        idxDir = lnPntNum*ln+startIdx(smpl,ln+1)+1:lnPntNum*ln+endIdx(smpl,ln+1)+1;
        idxDirItrVl = [idxDir(1):20:idxDir(end)-20 idxDir(end)];
        y = lnY(smpl,idxDir);
        x = lnX(smpl,idxDir);
        classBitDs = (bitget(class(idxDir),3)~=0);                                  % 破線
        classBitSl = ((bitget(class(idxDir),2)+bitget(class(idxDir),4))~=0);        % 白&黄実線
        classBitMtg = (bitget(class(idxDirItrVl),5)~=0);                            % 跨ぎ線
        classBitVtl = (bitget(class(idxDirItrVl),6)~=0);                            % 仮想区画線
        plot(ax99,y(classBitDs),x(classBitDs),'Color',color,'LineStyle','--'); hold on;
        plot(ax99,y(classBitSl),x(classBitSl),'Color',color,'LineStyle','-'); hold on;
        plot(ax99,y(classBitMtg),x(classBitMtg),'Color',color,'Marker','*','MarkerSize',10); hold on;
        plot(ax99,y(classBitVtl),x(classBitVtl),'Color',color,'MarkerFaceColor',color,'Marker','square','MarkerSize',10); hold on;
    end
end

function plotLmOutMapLaneCtClassFunc(ax99,smpl,ln,lnX,lnY,startIdx,endIdx,class,color)
    % 地図区画線各ビット定義
    % 0bit       有効/無効フラグ(外挿点は無効)
    % 1bit       走行車線フラグ
    % 2bit       追越車線フラグ
    % 3bit       退避車線フラグ
    % 4bit       バス専用走行路フラグ
    % 5bit       ゆずり車線フラグ
    % 6bit       登坂車線フラグ
    % 7-8bit     空
    % 9bit　     分岐帯
    % 10bit      合流帯
    % 11bit      車線増加帯
    % 12bit      車線減少帯
    % 13bit      右車線変更可能フラグ
    % 14bit      左車線変更可能フラグ
    % 15bit　　  トンネル区間フラグ
    % 16bit      料金所フラグ
    % 17bit      Baidu特有分岐・車線増加
    % 18bit      Baidu特有合流・車線現象
    % 19bit      HOVレーンフラグ
    % 20bit      タクシーレーンフラグ
    % 21bit      税関車両専用車線フラグ(予約:7.0にて有効)
    lnPntNum = 451;
    if startIdx(smpl,ln+1) ~= -1 && endIdx(smpl,ln+1)+1 ~= -1
        idxDirTmp = lnPntNum*ln+startIdx(smpl,ln+1)+1:lnPntNum*ln+endIdx(smpl,ln+1)+1;
        idxDir = [idxDirTmp(1):20:idxDirTmp(end)-20 idxDirTmp(end)];
        y = lnY(smpl,idxDir);
        x = lnX(smpl,idxDir);
        tonnelBit = (bitget(class(idxDir),16)~=0);                          % トンネル区間
        HovBit = (bitget(class(idxDir),20)~=0);                             % HOVレーン
        sepBit = (bitget(class(idxDir),10)~=0);                             % 分岐
        merBit = (bitget(class(idxDir),11)~=0);                             % 合流
        lnUpBit = (bitget(class(idxDir),12)~=0);                            % 車線増加
        lnDownBit = (bitget(class(idxDir),13)~=0);                          % 車線減少
        plot(ax99,y(tonnelBit),x(tonnelBit),'Color',color,'Marker','_','MarkerSize',15); hold on;
        plot(ax99,y(HovBit),x(HovBit),'Color',color,'MarkerFaceColor',color,'Marker','diamond','MarkerSize',8); hold on;
        plot(ax99,y(sepBit),x(sepBit),'Color',color,'MarkerFaceColor',color,'Marker','^','MarkerSize',8); hold on;
        plot(ax99,y(merBit),x(merBit),'Color',color,'MarkerFaceColor',color,'Marker','v','MarkerSize',8); hold on;
        plot(ax99,y(lnUpBit),x(lnUpBit),'Color',color,'Marker','*','MarkerSize',15); hold on;
        plot(ax99,y(lnDownBit),x(lnDownBit),'Color',color,'Marker','x','MarkerSize',15); hold on;
    end
end

function plotMapLaneFunc(ax,smpl,ln,X,Y,lnPntNum,color,marker,swMin)
    if swMin
        if ln == 0
            lnPntNumMax = 0;
        else
            lnPntNumMax = sum(lnPntNum(ln:-1:1));
        end
    else
        lnPntNumMax = 650*ln;
    end
    plot(ax,Y(smpl,lnPntNumMax+1:lnPntNumMax+lnPntNum(ln+1)),X(smpl,lnPntNumMax+1:lnPntNumMax+lnPntNum(ln+1)),'Color',color,'Marker',marker); hold on;
%     plot(ax,Y(smpl,:),X(smpl,:),'r.-'); hold on;
end
