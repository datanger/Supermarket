%time = S_lmInhStt.time;
%cutSmpl = max(1,l-tt*5):min(l+tt*5,length(time));

% timeChartIndex = 3000;
lmmmMapDiffStt = S_lmmmMapDiffStt.signals.values;
lmmmCamDiffStt = S_lmmmCamDiffStt.signals.values;
ReserveUint7 = S_lmVecReserveUint.signals.values(:,7);
cutSmpl4save = max(1,timeChartIndex-tt*20):min(timeChartIndex+tt*20,length(time));
if length(time(:,1)) == 1
    time = transpose(time);
end
% nn = 9;
% iii = 1;
%% MAP 1
ax511 = subplot(9,4,3);

plot(ax511,time(cutSmpl4save,1),bitget(S_lmInhStt.signals.values(cutSmpl4save,1),3),'r.-'); hold on;
plot(ax511,time(cutSmpl4save,1),bitget(S_lmInhStt.signals.values(cutSmpl4save,1),5)*2,'b.-'); hold on;
plot(ax511,time(cutSmpl4save,1),(S_mhStatus.signals.values(cutSmpl4save,1)~=0)*3,'g.-'); hold on;
xline(ax511,time(timeChartIndex));

grid minor;
ax511.YLim = [ 0 3 ];
ax511.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];


% ax511.XLim = [min(1,timeChartIndex-tt*5) max(1,timeChartIndex-tt*5)];
% title(ax511,'red:e Map, bule:e YRM, green:mhStt');

% txt = text(ax511,ax511.XLim(2),ax511.YLim(2),'e Map');
plotValue=bitget(S_lmInhStt.signals.values(timeChartIndex,1),3);
% txt.String = strcat('e Map: ',int2str(plotValue));
% txt.Color = 'red';txt.Units='normalized';txt.Position= [1 0.75 0];

% txt = text(ax511,ax511.XLim(2),ax511.YLim(2),'e YRM');
plotValue1=bitget(S_lmInhStt.signals.values(timeChartIndex,1),5)*2;
% txt.String = strcat('e YRM: ',int2str(plotValue));
% txt.Color = 'blue';txt.Units='normalized';txt.Position= [1 0.5 0];

% txt = text(ax511,ax511.XLim(2),ax511.YLim(2),'mhStt');
plotValue2=(S_mhStatus.signals.values(timeChartIndex,1)~=0)*3;
% txt.String = strcat('mhStt: ',num2str(plotValue));
% txt.Color = 'green';txt.Units='normalized';txt.Position= [1 0.25 0];
title(ax511,strcat('\color{red}eMap:',num2str(plotValue),'  \color{blue}eYrm:',num2str(plotValue1),'  \color{green}mhStt:',num2str(plotValue2)),'Fontsize',7);

%-------------------------------------------------------------------------------------------------------------------%
%% MAP 2
% iii = iii+1;
ax512 = subplot(9,4,7);

plot(ax512,time(cutSmpl4save,1),1./abs(curv(cutSmpl4save,2)),'b.-'); hold on;
xline(ax512,time(timeChartIndex));

grid minor;
yticks( ax512, 0:100:600 );
ax512.YLim = [ 0 600 ];
ax512.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
% title(ax512,'radius of curvature[m]');
% 
% txt = text(ax512,ax512.XLim(2),ax512.YLim(2),'radius of curvature[m]');
plotValue=1./abs(curv(timeChartIndex,2));
% txt.String = strcat('Radius[m]: ',sprintf('%.1f', plotValue));
% txt.Color = 'blue';txt.Units='normalized';txt.Position= [1 0.5 0];

title(ax512,strcat('Radius:',sprintf('%.1f', plotValue)),'Color','b','Fontsize',7);

%-------------------------------------------------------------------------------------------------------------------%
%% MAP 3
% iii = iii+1;
ax513 = subplot(9,4,11);

plot(ax513,time(cutSmpl4save,1),S_egoSpd.signals.values(cutSmpl4save,1)*3.6,'r.-'); hold on;
xline(ax513,time(timeChartIndex));

grid minor;
ax513.YLim = [ 0 120 ];
ax513.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
% title(ax513,'speed[km/h]');

% txt = text(ax513,ax513.XLim(2),ax513.YLim(2),'speed[km/h]');
plotValue=S_egoSpd.signals.values(timeChartIndex,1)*3.6;
% txt.String = strcat('speed[km/h]: ',sprintf('%.1f', plotValue));
% txt.Color = 'red';txt.Units='normalized';txt.Position= [1 0.5 0];
title(ax513,strcat('egoSpd:',sprintf('%.1f', plotValue)),'Color','r','Fontsize',7);

if swXcorr == 0
    %-------------------------------------------------------------------------------------------------------------------%
    %    DELETED
    %     iii = iii+1;
    % %     ax514 = subplot(nn,1,iii);
    %     ax514 = subplot(nn,3,iii*3);
    %
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),13)); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),14)*2); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),15)*3); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),16)*4); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),17)*5); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),18)*6); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),19)*7); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),20)*8); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),21)*9,'r.-'); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),22)*10); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),23)*11); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),24)*12); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),25)*13); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),26)*14); hold on;
    %     plot(ax514,time(cutSmpl4save,1),bitget(S_lmPldStt.signals.values(cutSmpl4save,1),27)*15); hold on;
    %     xline(ax514,time(timeChartIndex));
    %
    %     grid minor;
    %     yticks(ax514,[0:1:15]);
    %     ax514.YLim = [ 0 15 ];
    %     ax514.XLim = [min(cutSmpl4save)/5 max(cutSmpl4save)/5];
    %
    %     title(ax514,'lmPldStt');
    
    % yrmStt
    %-------------------------------------------------------------------------------------------------------------------%
    %% MAP 4
%     iii = iii+1;
%     %     ax515 = subplot(nn,1,iii);
%     ax515 = subplot(nn,3,iii*3);
%     
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),13)); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),14)*2); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),15)*3); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),16)*4); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),17)*5); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),18)*6); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),19)*7); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),20)*8); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),21)*9); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),22)*10); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),23)*11); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),24)*12); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),25)*13); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),26)*14); hold on;
%     plot(ax515,time(cutSmpl4save,1),bitget(S_lmmlYrmStt.signals.values(cutSmpl4save,1),27)*15); hold on;
%     xline(ax515,time(timeChartIndex));
%     % title(ax16,{'[1]e lineCam','[2]e lineMap','[3]e R','[4]e T','[5]e de','[6]e cnt','[7]e wrongLane','[8]CamLineLostFlg','[9]CamDiffAsapFlag','[10]CamLineLostBothFlg','[11]CamBothErrFlg'});
%     
%     grid minor;
%     ax515.YLim = [ 0 15 ];
%     ax515.XLim = [min(cutSmpl4save)/5 max(cutSmpl4save)/5];
%     title(ax515,'yrmStt');
    
    %-------------------------------------------------------------------------------------------------------------------%
    %% MAP 4
%     iii = iii+1;
    ax516 = subplot(9,4,15);
    
    plot(ax516, time(cutSmpl4save,1),bitget(S_lmLnMode.signals.values(cutSmpl4save),19),'k.-'); hold on;
    plot(ax516, time(cutSmpl4save,1),bitget(S_lmLnMode.signals.values(cutSmpl4save),20)*2,'r.-'); hold on;
    plot(ax516, time(cutSmpl4save,1),bitget(S_lmLnMode.signals.values(cutSmpl4save),17)*3,'b.-'); hold on;
    plot(ax516, time(cutSmpl4save,1),bitget(S_lmLnMode.signals.values(cutSmpl4save),18)*4,'m.-'); hold on;
    %     legend('RightLineMatch','LeftLineMatch','CameraBase','MapBase');
    
    xline(ax516,time(timeChartIndex));
    grid minor;
    ax516.YLim = [ 0 5 ];
    ax516.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
%     title(ax516,'black:RightLineMatch, red:LeftLineMatch, bule:CameraBase, maze:MapBase');
    
%     txt = text(ax516,ax516.XLim(2),ax516.YLim(2),'RightLineMatch');
    plotValue=bitget(S_lmLnMode.signals.values(timeChartIndex),19);
%     txt.String = strcat('RightLineMatch: ',int2str(plotValue));
%     txt.Units='normalized';txt.Color = 'black';txt.Position= [1 0.9 0];
    
%     txt = text(ax516,ax516.XLim(2),ax516.YLim(2),'LeftLineMatch');
    plotValue1=bitget(S_lmLnMode.signals.values(timeChartIndex),20);
%     txt.String = strcat('LeftLineMatch: ',int2str(plotValue));
%     txt.Units='normalized';txt.Color = 'red';txt.Position= [1 0.6333 0];
    
%     txt = text(ax516,ax516.XLim(2),ax516.YLim(2),'CameraBase');
    plotValue2=bitget(S_lmLnMode.signals.values(timeChartIndex),17);
%     txt.String = strcat('CameraBase: ',int2str(plotValue));
%     txt.Units='normalized';txt.Color = 'blue';txt.Position= [1 0.3667 0];
    
%     txt = text(ax516,ax516.XLim(2),ax516.YLim(2),'MapBase');
    plotValue3=bitget(S_lmLnMode.signals.values(timeChartIndex),18);
%     txt.String = strcat('MapBase: ',int2str(plotValue));
%     txt.Units='normalized';txt.Color = 'magenta';txt.Position= [1 0.1 0];
    title(ax516,strcat('\color{black}RightLineMatch:',num2str(plotValue),'  \color{red}LeftLineMatch:',num2str(plotValue1),'  \color{blue}CameraBase:',num2str(plotValue2),'  \color{magenta}MapBase:',num2str(plotValue3)),'Fontsize',7);
    
    %-------------------------------------------------------------------------------------------------------------------%
    % NEWLY ADDED
    %% MAP 5
%     iii = iii+1;
    ax517 = subplot(9,4,19);
    
    pld5 = bitget(S_lmPldStt.signals.values,5);
    pld6 = bitget(S_lmPldStt.signals.values,6);
    pld13 = bitget(S_lmPldStt.signals.values,13);
    pld14 = bitget(S_lmPldStt.signals.values,14);
    pld15 = bitget(S_lmPldStt.signals.values,15);
    pld16 = bitget(S_lmPldStt.signals.values,16);
    pld17 = bitget(S_lmPldStt.signals.values,17);
    pld18 = bitget(S_lmPldStt.signals.values,18);
    pld19 = bitget(S_lmPldStt.signals.values,19);
    pld20 = bitget(S_lmPldStt.signals.values,20);
    pld21 = bitget(S_lmPldStt.signals.values,21);
    pld22 = bitget(S_lmPldStt.signals.values,22);
    pld23 = bitget(S_lmPldStt.signals.values,23);
    pld24 = bitget(S_lmPldStt.signals.values,24);
    pld25 = bitget(S_lmPldStt.signals.values,25);
    pld26 = bitget(S_lmPldStt.signals.values,26);
    pld27 = bitget(S_lmPldStt.signals.values,27);
    pldON= pld5|pld6|pld13|pld14|pld15|pld16|pld17|pld18|pld19|pld20|pld21|pld22|pld22|pld23|pld24|pld25|pld26|pld27;
    plot(ax517,time(cutSmpl4save,1),pldON(cutSmpl4save,1),'b.-'); hold on;
    xline(ax517,time(timeChartIndex));
    grid minor;
    ax517.YLim = ([0 2]);
    ax517.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
%     title(ax517,'System Limit');
    
%     txt = text(ax517,ax517.XLim(2),ax517.YLim(2),'System Limit');
    plotValue=pldON(timeChartIndex,1);
%     txt.String = strcat('System Limit: ',int2str(plotValue));
%     txt.Units='normalized';txt.Color = 'blue';txt.Position= [1 0.5 0];
    title(ax517,strcat('System Limit:',num2str(plotValue)),'Color','b','Fontsize',7);
    %-------------------------------------------------------------------------------------------------------------------%
    % NEWLY ADDED
    % NEWLY ADDED
    %% MAP 6
%     iii = iii+1;
    ax518 = subplot(9,4,23);
    
    plot(ax518,time(cutSmpl4save,1),S_lmVecClinebFlg.signals.values(cutSmpl4save,1),'k.-'); hold on;
    plot(ax518,time(cutSmpl4save,1),S_lmVecClinebFlg.signals.values(cutSmpl4save,2),'r.-'); hold on;
    
    xline(ax518,time(timeChartIndex));
    grid minor;
    ax518.YLim = ([0 2]);
    ax518.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
%     title(ax518,'Left & Right ClinbFlg');
    
%     txt = text(ax518,ax518.XLim(2),ax518.YLim(2),'Left ClinbFlg');
    plotValue=S_lmVecClinebFlg.signals.values(timeChartIndex,1);
%     txt.String = strcat('Left ClinbFlg: ',int2str(plotValue));
%     txt.Units='normalized';txt.Color = 'black';txt.Position= [1 0.6667 0];
    
%     txt = text(ax518,ax518.XLim(2),ax518.YLim(2),'Right ClinbFlg');
    plotValue1=S_lmVecClinebFlg.signals.values(timeChartIndex,2);
%     txt.String = strcat('Right ClinbFlg: ',int2str(plotValue));
%     txt.Units='normalized';txt.Color = 'red';txt.Position= [1 0.3333 0];
    title(ax518,strcat('\color{black}LeftClinebFlg:',int2str(plotValue),'  \color{red}RightClinebFlg:',int2str(plotValue1)),'Fontsize',7);
    
    %-------------------------------------------------------------------------------------------------------------------%
    %% MAP 7
%     iii = iii+1;
    %     ax516 = subplot(nn,1,iii);
    ax519 = subplot(9,4,[27,31]);
    
    plot(ax519, time(cutSmpl4save,1),tgtDiffy(cutSmpl4save),'b.-', "DisplayName", "1.05�b��LM���H����" );
    yline( ax519, -0.3, "-r", "DisplayName", "2sigma min" );
    yline( ax519, 0.3, "-r", "DisplayName", "2sigma max" );
    
    grid minor;
    title(ax519,'Gap of deltaY at 1.05sec ahead [m]','Fontsize',7);
    xline(ax519,time(timeChartIndex));
    %     ax516.YLim = [ -0.5 0.5 ];
    ax519.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
    
%     txt = text(ax519,ax519.XLim(2),ax519.YLim(2),'Gap value');
    plotValue=tgtDiffy(timeChartIndex);
%     txt.String = strcat('Gap value: ',sprintf('%.3f', plotValue));
%     txt.Units='normalized';txt.Color = 'blue';txt.Position= [1 0.5 0];
    title(ax519,strcat('Gap value:',sprintf('%.3f', plotValue)),'Color','b','Fontsize',7);
    
    %% MAP 8
    ax520 = subplot(9,4,35);
    set(ax520,'xtick',[]);
    set(ax520,'ytick',[]);
    set(ax520,'xcolor','w');
    set(ax520,'ycolor','w');
    mhStt_num = mhStt(timeChartIndex);
    lmPldStt_num = lmPldStt(timeChartIndex);
    lmInhStt_num = lmInhStt(timeChartIndex);
    lmLnMode_num = lmLnMode(timeChartIndex);
    lmmmMapDiffStt_num = lmmmMapDiffStt(timeChartIndex);
    lmmmCamDiffStt_num = lmmmCamDiffStt(timeChartIndex);

    binstr = dec2bin(mhStt_num,32);
    binstr1 = dec2bin(lmPldStt_num,32);
    binstr2 = dec2bin(lmInhStt_num,32);
    binstr3 = dec2bin(lmLnMode_num,32);
    binstr4 = dec2bin(lmmmMapDiffStt_num,32);
    binstr5 = dec2bin(lmmmCamDiffStt_num,32);
    binstr6 = dec2bin(ReserveUint7,32);
    
    txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'mhStt','FontSize',8);
    % txt.String = strcat('lmPldStt : ',binstr1);
    txt.String = sprintf('mhStt: %s %s %s %s %s %s %s %s',binstr(1:4),binstr(5:8),...
        binstr(9:12),binstr(13:16),binstr(17:20),binstr(21:24),binstr(25:28),binstr(29:32));
    txt.Color = 'black';
    txt.Units='normalized';
    txt.Position= [0.01 1 0];
    

    txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmPldStt','FontSize',8);
    % txt.String = strcat('lmPldStt : ',binstr1);
    txt.String = sprintf('lmPldStt: %s %s %s %s %s %s %s %s',binstr1(1:4),binstr1(5:8),...
        binstr1(9:12),binstr1(13:16),binstr1(17:20),binstr1(21:24),binstr1(25:28),binstr1(29:32));
    txt.Color = 'black';
    txt.Units='normalized';
    txt.Position= [0.01 0.85 0];

    txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmInhStt','FontSize',8);
    txt.String = sprintf('lmInhStt: %s %s %s %s %s %s %s %s',binstr2(1:4),binstr2(5:8),...
        binstr2(9:12),binstr2(13:16),binstr2(17:20),binstr2(21:24),binstr2(25:28),binstr2(29:32));
    txt.Color = 'black';
    txt.Units='normalized';
    txt.Position= [0.01 0.70 0];

    txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmLnMode','FontSize',8);
    txt.String = sprintf('lmLnMode: %s %s %s %s %s %s %s %s',binstr3(1:4),binstr3(5:8),...
        binstr3(9:12),binstr3(13:16),binstr3(17:20),binstr3(21:24),binstr3(25:28),binstr3(29:32));
    txt.Color = 'black';
    txt.Units='normalized';
    txt.Position= [0.01 0.55 0];

    txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmmmMapDiffStt','FontSize',8);
    txt.String = sprintf('lmmmMapDiffStt: %s %s %s %s %s %s %s %s',binstr4(1:4),binstr4(5:8),...
        binstr4(9:12),binstr4(13:16),binstr4(17:20),binstr4(21:24),binstr4(25:28),binstr4(29:32));
    txt.Color = 'black';
    txt.Units='normalized';
    txt.Position= [0.01 0.40 0];

    txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmmmCamDiffStt','FontSize',8);
    txt.String = sprintf('lmmmCamDiffStt: %s %s %s %s %s %s %s %s',binstr5(1:4),binstr5(5:8),...
        binstr5(9:12),binstr5(13:16),binstr5(17:20),binstr5(21:24),binstr5(25:28),binstr5(29:32));
    txt.Color = 'black';
    txt.Units='normalized';
    txt.Position= [0.01 0.25 0];
    
    txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'ReserveUint7','FontSize',8);
    txt.String = sprintf('ReserveUint7: %s %s %s %s %s %s %s %s',binstr6(1:4),binstr6(5:8),...
        binstr6(9:12),binstr6(13:16),binstr6(17:20),binstr6(21:24),binstr6(25:28),binstr6(29:32));
    txt.Color = 'black';
    txt.Units='normalized';
    txt.Position= [0.01 0.1 0];

    
end

%
% %���n��v���b�g��������
% top = 0.925;
% bottom = 0.11;
% gap = 0.0194; %�T�u�v���b�g�Ԃ̕�(Figure�S�̂ɑ΂���䗦)
%
% heightUnit = ( top - bottom + gap ) / sum( axTimeHeight );
%
% for i = 1:length( axTime )
%     ax991 = axTime( i );
% %     axPosition = ax991.Position;
%     axLeft = axPosition( 1 );
%     axBottom = axPosition( 2 );
%     axWidth = axPosition( 3 );
%     axHeight = axPosition( 4 );
%
%     if axTimeHeight( i ) == 0
% %         cla( ax991 );
% %         ax991.Visible = 'off';
%     else
% %         ax991.Visible = 'on';
%         axBottom = top + gap - ( heightUnit * sum( axTimeHeight( 1:i ) )  ) ;
%         axHeight = heightUnit * axTimeHeight( i ) - gap ;
%         axPosition = [ axLeft axBottom axWidth axHeight ];
% %         ax991.Position = axPosition;
%     end
%
%     pause( 0.1 );
% end
%