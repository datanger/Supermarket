DataIndex = [];
for i = 2:length(eMap)
    conditionA = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(i),8) || ...
    bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(i),9) || ...
    bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(i),10);
    conditionB = saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmVecCtrlLnExistFlg.signals.values(i,2) == 0;
    conditionC = bitget(smVecSysActivateMode(i),2);
    conditionD = bitget(smVecSysActivateMode(i-1),2);
    if eMap(i) == 1 && (conditionA || conditionB) &&  conditionC == 0 && conditionD == 1
        DataIndex = [DataIndex;i];
    end
end

numIdx = [];
numIdxType = "";
if ~isempty(DataIndex)
    numIdx = DataIndex(1);
    for i = 2:length(DataIndex)
        if DataIndex(i)-DataIndex(i-1) == 1
        else
            numIdx = [numIdx;DataIndex(i)];
        end
    end
    for i = 1:length(numIdx)
        CA = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(numIdx(i)),8);
        CB = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(numIdx(i)),9);
        CC = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(numIdx(i)),10);
        CD = (bitget(saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values(numIdx(i)),1)==0) && ...
            (bitget(saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values(numIdx(i)),2)==0);
        CE = saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmVecCtrlLnExistFlg.signals.values(numIdx(i),2);
        
        type_code = '';
        if CA == 1
            type_code = 'CA';
        elseif CB == 1
            type_code = 'CB';
        elseif CC == 1
            type_code = 'CC';
        elseif CD
            type_code = 'CD';
        elseif CE == 1
            type_code = 'CE';
        else
            type_code = 'Other';
        end
        
        switch type_code
            case 'CA'
                numIdxType(i,1) = '�p�^�[��A';
            case 'CB'
                numIdxType(i,1) = '�p�^�[��B';
            case 'CC'
                numIdxType(i,1) = '�p�^�[��C';
            case 'CD'
                numIdxType(i,1) = '�p�^�[��DEF';
            case 'CE'
                numIdxType(i,1) = '�p�^�[��DEF';
            case 'Other'
                numIdxType(i,1) = 'Other';
        end
    end
end
