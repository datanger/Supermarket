1. <fix>(LKASOFF):修复输出解析表时分类index错误的问题
