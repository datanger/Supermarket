screenSize = get(0, 'ScreenSize');
fig6=figure('name','6','Position',[0 0 screenSize(3:4)],'Visible',0);

lane_num = MpuMessage1.laneNum.signals.values;
ego_lane = MpuMessage1.egoLaneIndex.signals.values;

%% �p�����[�^
samples = length(MpuMessage1.elapsedTime.time);
LogTime = MpuMessage1.elapsedTime.time;
CP_operatePuase = 0.1; %�����Đ�/�`��X�V�����B���g���̊��ɍ��킹�ĕύX���Ă��������B

% �X���C�_�[�쐬
slider_obj = uicontrol('style','slider', 'Units','normalized',...
    'min',1, 'max',samples, 'Value',1, 'SliderStep',[1/samples 100/samples]);
slider_obj.Position = [0.01 0.01 0.49 0.05];
%���[���w��G�f�B�b�g�{�b�N�X����
laneEdit = uicontrol('Style','edit', 'Units','normalized' ,'Position',[.83 .05 .05 .03], 'String',lane_num(1), 'FontSize',10);
egoLaneEdit = uicontrol('Style','edit', 'Units','normalized' ,'Position',[.75 .05 .05 .03], 'String',lane_num(1), 'FontSize',10);
sidePointEdit = uicontrol('Style','edit', 'Units','normalized' ,'Position',[.67 .05 .05 .03], 'String',lane_num(1), 'FontSize',10);
%�\���͈͎w��G�f�B�b�g�{�b�N�X����
yNegative = uicontrol('Style','edit', 'Units','normalized' ,'Position',[.55 .01 .03 .03], 'String',xlimVLow, 'FontSize',10);
yPositive = uicontrol('Style','edit', 'Units','normalized' ,'Position',[.59 .01 .03 .03], 'String',xlimVHigh, 'FontSize',10);
xNegative = uicontrol('Style','edit', 'Units','normalized' ,'Position',[.63 .01 .03 .03], 'String',ylimVLow, 'FontSize',10);
xPositive = uicontrol('Style','edit', 'Units','normalized' ,'Position',[.67 .01 .03 .03], 'String',ylimVHigh, 'FontSize',10);
chkbox_fix_range = uicontrol('Style','checkbox','String','fix range','Units','normalized','FontSize',10,'Value',1,'Position',[.71 .01 .06 .03]); 
%�v���b�g�\���w��`�F�b�N�{�b�N�X����
chkbox_mpu_plot = uicontrol('Style','checkbox','String','mpu','Units','normalized','FontSize',10,'Value',1,'Position',[.01 .9 .03 .03]);
chkbox_left_plot = uicontrol('Style','checkbox','String','left','Units','normalized','FontSize',10,'Value',1,'Position',[.01 .84 .03 .03]);
chkbox_right_plot = uicontrol('Style','checkbox','String','right','Units','normalized','FontSize',10,'Value',1,'Position',[.01 .81 .03 .03]);
chkbox_border_left_plot = uicontrol('Style','checkbox','String','left border','Units','normalized','FontSize',10,'Value',0,'Position',[.01 .78 .05 .03]);
chkbox_border_right_plot = uicontrol('Style','checkbox','String','right border','Units','normalized','FontSize',10,'Value',0,'Position',[.06 .78 .05 .03]);
chkbox_mpu_join_plot = uicontrol('Style','checkbox','String','join','Units','normalized','FontSize',10,'Value',0,'Position',[.045 .9 .03 .03]);
chkbox_mpu_branch_plot = uicontrol('Style','checkbox','String','branch','Units','normalized','FontSize',10,'Value',0,'Position',[.08 .9 .03 .03]);
chkbox_left_join_plot = uicontrol('Style','checkbox','String','join','Units','normalized','FontSize',10,'Value',0,'Position',[.045 .84 .03 .03]);
chkbox_left_branch_plot = uicontrol('Style','checkbox','String','branch','Units','normalized','FontSize',10,'Value',0,'Position',[.08 .84 .03 .03]);
chkbox_right_join_plot = uicontrol('Style','checkbox','String','join','Units','normalized','FontSize',10,'Value',0,'Position',[.045 .81 .03 .03]);
chkbox_right_branch_plot = uicontrol('Style','checkbox','String','branch','Units','normalized','FontSize',10,'Value',0,'Position',[.08 .81 .03 .03]);
chkbox_lane_branch_attr_plot = uicontrol('Style','checkbox','String','lane branch','Units','normalized','FontSize',10,'Value',1,'Position',[.01 .27 .05 .03]);
chkbox_lane_join_attr_plot = uicontrol('Style','checkbox','String','lane join','Units','normalized','FontSize',10,'Value',1,'Position',[.07 .27 .05 .03]);
chkbox_left_line_near_plot = uicontrol('Style','checkbox','String','left near','Units','normalized','FontSize',10,'Value',0,'Position',[.01 .24 .05 .025]);
chkbox_right_line_near_plot = uicontrol('Style','checkbox','String','right near','Units','normalized','FontSize',10,'Value',0,'Position',[.06 .24 .05 .025]);

chkbox_center_side = uicontrol('Style','checkbox','String','center side','Units','normalized','FontSize',10,'Value',0,'Position',[.01 .75 .05 .03]);
chkbox_left_lane = uicontrol('Style','checkbox','String','left lane','Units','normalized','FontSize',10,'Value',0,'Position',[.01 .72 .05 .03]);
chkbox_right_lane = uicontrol('Style','checkbox','String','right lane','Units','normalized','FontSize',10,'Value',0,'Position',[.06 .72 .05 .03]);

chkbox_border_left_mul_lane = uicontrol('Style','checkbox','String','left bdr mul','Units','normalized','FontSize',10,'Value',0,'Position',[.01 .69 .05 .03]);
chkbox_border_right_mul_lane = uicontrol('Style','checkbox','String','right bdr mul','Units','normalized','FontSize',10,'Value',0,'Position',[.06 .69 .05 .03]);

chkbox_left_slow = uicontrol('Style','checkbox','String','left slow','Units','normalized','FontSize',10,'Value',0,'Position',[.01 .66 .05 .03]);
chkbox_right_slow = uicontrol('Style','checkbox','String','right slow','Units','normalized','FontSize',10,'Value',0,'Position',[.06 .66 .05 .03]);

chkbox_left_zebra = uicontrol('Style','checkbox','String','left zebra','Units','normalized','FontSize',10,'Value',0,'Position',[.01 .63 .05 .03]);
chkbox_right_zebra = uicontrol('Style','checkbox','String','right zebra','Units','normalized','FontSize',10,'Value',0,'Position',[.06 .63 .05 .03]);
chkbox_tollgate = uicontrol('Style','checkbox','String','tollgate','Units','normalized','FontSize',10,'Value',0,'Position',[.01 .20 .05 .03]);

%���[���v���b�g�w��
chkbox_lane0 = uicontrol('Style','checkbox','String','0','Units','normalized','FontSize',10,'Value',1,'Position',[.01 .6 .03 .02]);
chkbox_lane1 = uicontrol('Style','checkbox','String','1','Units','normalized','FontSize',10,'Value',1,'Position',[.04 .6 .03 .02]);
chkbox_lane2 = uicontrol('Style','checkbox','String','2','Units','normalized','FontSize',10,'Value',1,'Position',[.07 .6 .03 .02]);
chkbox_lane3 = uicontrol('Style','checkbox','String','3','Units','normalized','FontSize',10,'Value',1,'Position',[.10 .6 .03 .02]);
chkbox_lane4 = uicontrol('Style','checkbox','String','4','Units','normalized','FontSize',10,'Value',1,'Position',[.01 .57 .03 .02]);
chkbox_lane5 = uicontrol('Style','checkbox','String','5','Units','normalized','FontSize',10,'Value',1,'Position',[.04 .57 .03 .02]);
chkbox_lane6 = uicontrol('Style','checkbox','String','6','Units','normalized','FontSize',10,'Value',1,'Position',[.07 .57 .03 .02]);
chkbox_lane7 = uicontrol('Style','checkbox','String','7','Units','normalized','FontSize',10,'Value',1,'Position',[.10 .57 .03 .02]);
chkbox_lane8 = uicontrol('Style','checkbox','String','8','Units','normalized','FontSize',10,'Value',1,'Position',[.01 .54 .03 .02]);
chkbox_lane9 = uicontrol('Style','checkbox','String','9','Units','normalized','FontSize',10,'Value',1,'Position',[.04 .54 .03 .02]);
chkbox_lane10 = uicontrol('Style','checkbox','String','10','Units','normalized','FontSize',10,'Value',1,'Position',[.07 .54 .03 .02]);
chkbox_lane11 = uicontrol('Style','checkbox','String','11','Units','normalized','FontSize',10,'Value',1,'Position',[.10 .54 .03 .02]);
chkbox_lane12 = uicontrol('Style','checkbox','String','12','Units','normalized','FontSize',10,'Value',1,'Position',[.01 .51 .03 .02]);
chkbox_lane13 = uicontrol('Style','checkbox','String','13','Units','normalized','FontSize',10,'Value',1,'Position',[.04 .51 .03 .02]);
chkbox_lane14 = uicontrol('Style','checkbox','String','14','Units','normalized','FontSize',10,'Value',1,'Position',[.07 .51 .03 .02]);
chkbox_lane15 = uicontrol('Style','checkbox','String','15','Units','normalized','FontSize',10,'Value',1,'Position',[.10 .51 .03 .02]);

chkbox_virtual_line = uicontrol('Style','checkbox','String','virtual','Units','normalized','FontSize',10,'Value',0,'Position',[.01 .48 .03 .02]);
chkbox_line_type = uicontrol('Style','checkbox','String','line type','Units','normalized','FontSize',10,'Value',1,'Position',[.04 .48 .04 .02]);

%{
% ���ԉ��C���f�b�N�X�\���`�F�b�N�{�b�N�X����
for i = 1: 16
    side_index(i) = uicontrol('Style','edit', 'Units','normalized' ,'Position',[.01 .78 - (0.03 * i) .03 .03], 'String',0, 'FontSize',10);
end

% ego lane conf�\���`�F�b�N�{�b�N�X����
for i = 1: 16
    ego_conf(i) = uicontrol('Style','edit', 'Units','normalized' ,'Position',[.05 .78 - (0.03 * i) .03 .03], 'String',0, 'FontSize',10);
end
%}

%���ԕ\��
LogInfoPanel = uipanel('Position',[.0 .97 .5 .03]);
TimeInfoTextBox = annotation(LogInfoPanel, 'textbox', 'Position',[.02 .95 1. 0], 'LineStyle','none',...
    'String',sprintf('dummy'),...
    'FontSize',10);

CorrInfoTextBox = annotation(LogInfoPanel, 'textbox', 'Position',[.2 .95 5. 0], 'LineStyle','none',...
    'String',sprintf('dummy'),...
    'FontSize',10);

ax1 = subplot(1,2,1);
ax2 = subplot(1,2,2);
graghDefulatSet(ax1);
graghDefulatSet(ax2);

colors = {'ro-', 'bo-', 'go-', 'mo-', 'co-', 'ko-', 'yo-', 'r+-', 'b+-', 'g+-', 'm+-', 'c+-', 'k+-', 'y+-', 'r*-', 'b*-'};
colors_left = {'r.-', 'b.-', 'g.-', 'm.-', 'c.-', 'k.-', 'y.-', 'r.-', 'b.-', 'g.-', 'm.-', 'c.-', 'k.-', 'y.-', 'r.-', 'b.-'};
colors_right = {'rs-', 'bs-', 'gs-', 'ms-', 'cs-', 'ks-', 'ys-', 'rs-', 'bs-', 'gs-', 'ms-', 'cs-', 'ks-', 'ys-', 'rs-', 'bs-'};
colors_line = {'r-', 'b-', 'g-', 'm-', 'c-', 'k-', 'y-', 'r-', 'b-', 'g-', 'm-', 'c-', 'k-', 'y-', 'r-', 'b-'};
colors_only = {'r', 'b', 'g', 'm', 'c', 'k', 'y', 'r', 'b', 'g', 'm', 'c', 'k', 'y', 'r', 'b'};
colors_virtual = {'rs', 'bs', 'gs', 'ms', 'cs', 'ks', 'ys', 'rs', 'bs', 'gs', 'ms', 'cs', 'ks', 'ys', 'rs', 'bs'};
colors_solid = {'r-', 'b-', 'g-', 'm-', 'c-', 'k-', 'y-', 'r-', 'b-', 'g-', 'm-', 'c-', 'k-', 'y-', 'r-', 'b-'};
colors_dash = {'r--', 'b--', 'g--', 'm--', 'c--', 'k--', 'y--', 'r--', 'b--', 'g--', 'm--', 'c--', 'k--', 'y--', 'r--', 'b--'};
colors_other = {'rpentagram', 'bpentagram', 'gpentagram', 'mpentagram', 'cpentagram', 'kpentagram', 'ypentagram', 'rpentagram', 'bpentagram', 'gpentagram', 'mpentagram', 'cpentagram', 'kpentagram', 'ypentagram', 'rpentagram', 'bpentagram'};

%% ���C���`��
%zh_modify_start***********************************************************

% while(1)
%     i = floor(slider_obj.Value);    % ��t���[��
%     
%     cla(ax1);
%     cla(ax2);
%     
%     lane_plot = [chkbox_lane0.Value chkbox_lane1.Value chkbox_lane2.Value chkbox_lane3.Value ...
%         chkbox_lane4.Value chkbox_lane5.Value chkbox_lane6.Value chkbox_lane7.Value ...
%         chkbox_lane8.Value chkbox_lane9.Value chkbox_lane10.Value chkbox_lane11.Value ...
%         chkbox_lane12.Value chkbox_lane13.Value chkbox_lane14.Value chkbox_lane15.Value];
%     
%     if chkbox_mpu_plot.Value
%         end_index = 0;
%         for lane = 1:lane_num(i)
%             num = point_num(i, lane);
%             if num ~= 0
%                 begin_index = end_index + 1;
%                 end_index = end_index + num;
%                 if lane_plot(lane)
%                     plot(ax1, -mpu_y(i,begin_index:end_index), mpu_x(i,begin_index:end_index), colors{lane}); hold on;
%                     
%                     if chkbox_lane_join_attr_plot.Value
%                         tx = mpu_x(i, begin_index:end_index);
%                         ty = mpu_y(i, begin_index:end_index);
%                         aaa = mpu_attr(i, begin_index:end_index);
%                         tx(bitand(aaa, cast(0x1400, 'uint32'))==0) = NaN;
%                         ty(bitand(aaa, cast(0x1400, 'uint32'))==0) = NaN;
%                         plot(ax1, -ty, tx, 'rx', 'LineWidth', 3);
%                     end
%                     
%                     if chkbox_lane_branch_attr_plot.Value
%                         tx = mpu_x(i, begin_index:end_index);
%                         ty = mpu_y(i, begin_index:end_index);
%                         aaa = mpu_attr(i, begin_index:end_index);
%                         tx(bitand(aaa, cast(0xA00, 'uint32'))==0) = NaN;
%                         ty(bitand(aaa, cast(0xA00, 'uint32'))==0) = NaN;
%                         plot(ax1, -ty, tx, 'bx', 'LineWidth', 3);
%                     end
%                     
%                     if chkbox_tollgate.Value
%                         tx = mpu_x(i, begin_index:end_index);
%                         ty = mpu_y(i, begin_index:end_index);
%                         aaa = mpu_attr(i, begin_index:end_index);
%                         tx(bitand(aaa, cast(0x10000, 'uint32'))==0) = NaN;
%                         ty(bitand(aaa, cast(0x10000, 'uint32'))==0) = NaN;
%                         plot(ax1, -ty, tx, 'gx', 'LineWidth', 3);
%                     end
%                 end
%             else
%                 continue;
%             end
%                         
%             if chkbox_center_side.Value
%                 center_side = center_connection(i, (lane - 1) * 10 + 7);
%                 if center_side ~= 65535
%                     plot(ax1, -mpu_y(i, begin_index + center_side), mpu_x(i, begin_index + center_side), 'bx', 'LineWidth', 3);
%                 end
%             end
%             
%             if chkbox_left_lane.Value
%                 next_lane = -1;
%                 plot_tuple = [];
%                 before_lane = 65535;
%                 for point = begin_index:end_index
%                     aaa = mpu_left_lane(i, point);
%                     if aaa < 16 && before_lane == 65535
%                         first = point;
%                         next_lane = aaa;
%                     elseif aaa < 16 && aaa == before_lane
%                         % �������Ȃ� 
%                     elseif aaa < 16 && aaa ~= before_lane
%                         plot_tuple = [plot_tuple; first point - 1 next_lane];
%                         first = point;
%                         next_lane = aaa;
%                     else
%                         if next_lane >= 0
%                             plot_tuple = [plot_tuple; first point - 1 next_lane];
%                             next_lane = -1;
%                         end
%                     end
%                     before_lane = aaa;
%                 end
%                 if next_lane >= 0
%                     plot_tuple = [plot_tuple; first point next_lane];
%                 end
%                 if ~isempty(plot_tuple)
%                     for pt = 1:length(plot_tuple(:, 1))
%                         plot(ax1, -mpu_y(i, plot_tuple(pt, 1):plot_tuple(pt, 2)), mpu_x(i, plot_tuple(pt, 1):plot_tuple(pt, 2)), colors_line{plot_tuple(pt, 3) + 1}, 'LineWidth', 2);
%                     end
%                 end
%             end
%             
%             if chkbox_right_lane.Value
%                 next_lane = -1;
%                 plot_tuple = [];
%                 before_lane = 65535;
%                 for point = begin_index:end_index
%                     aaa = mpu_right_lane(i, point);
%                     if aaa < 16 && before_lane == 65535
%                         first = point;
%                         next_lane = aaa;
%                     elseif aaa < 16 && aaa == before_lane
%                         % �������Ȃ� 
%                     elseif aaa < 16 && aaa ~= before_lane
%                         plot_tuple = [plot_tuple; first point - 1 next_lane];
%                         first = point;
%                         next_lane = aaa;
%                     else
%                         if next_lane >= 0
%                             plot_tuple = [plot_tuple; first point - 1 next_lane];
%                             next_lane = -1;
%                         end
%                     end
%                     before_lane = aaa;
%                 end
%                 if next_lane >= 0
%                     plot_tuple = [plot_tuple; first point next_lane];
%                 end
%                 if ~isempty(plot_tuple)
%                     for pt = 1:length(plot_tuple(:, 1))
%                         plot(ax1, -mpu_y(i, plot_tuple(pt, 1):plot_tuple(pt, 2)), mpu_x(i, plot_tuple(pt, 1):plot_tuple(pt, 2)), colors_line{plot_tuple(pt, 3) + 1}, 'LineWidth', 2);
%                     end
%                 end
%             end
%             
%         end
%     end
%     
%     if ~chkbox_center_side.Value
%         plot(ax1, 0, 0, 'kx', 'LineWidth', 3);
%     end
%             
%     xlimVLow = str2double(yNegative.String);
%     xlimVHigh = str2double(yPositive.String);
%     ylimVLow = str2double(xNegative.String);
%     ylimVHigh = str2double(xPositive.String);
%     
%     if chkbox_fix_range.Value
%       ax1.XLim = [xlimVLow xlimVHigh];  
%       ax1.YLim = [ylimVLow ylimVHigh];
%       ax2.XLim = [-100 100];
%       % ax2.YLim = [-600 670];
%       ax2.YLim = [-5 600];
% %       ax2.YLim = [ylimVLow ylimVHigh];
%     end
%     
%     if exist('mpu_x_long', 'var')
%         end_index = 0;
%         for lane = 1:lane_num(i)
%             num = point_num_long(i, lane);
%             if num ~= 0
%                 begin_index = end_index + 1;
%                 end_index = end_index + num;
%                 plot(ax2, -mpu_y_long(i,begin_index:end_index), mpu_x_long(i,begin_index:end_index), colors{lane}); hold on;
%             end
%         end
%     end
%     
%     if exist('left_x', 'var')
%         if chkbox_left_plot.Value
%             end_index = 0;
%             for lane = 1:lane_num(i)
%                 num = left_point_num(i, lane);
%                 if num ~= 0
%                     begin_index = end_index + 1;
%                     end_index = end_index + num;
%                     if lane_plot(lane)
%                         if chkbox_left_zebra.Value
%                             tx = left_x(i, begin_index:end_index);
%                             ty = left_y(i, begin_index:end_index);
%                             tx(bitget(left_attr(i, begin_index:end_index), 19)==0) = NaN;
%                             ty(bitget(left_attr(i, begin_index:end_index), 19)==0) = NaN;
%                             plot(ax1, -ty, tx, 'kx', 'LineWidth', 3);
%                         end
%                         if chkbox_left_slow.Value
%                             tx = left_x(i, begin_index:end_index);
%                             ty = left_y(i, begin_index:end_index);
%                             tx(bitget(left_attr(i, begin_index:end_index), 20)==0) = NaN;
%                             ty(bitget(left_attr(i, begin_index:end_index), 20)==0) = NaN;
%                             plot(ax1, -ty, tx, 'gx', 'LineWidth', 3);
%                         end
%                         if chkbox_line_type.Value
%                             plot(ax1, -left_y_solid(i,begin_index:end_index), left_x_solid(i,begin_index:end_index), colors_solid{lane}, 'LineWidth', 2); hold on;
%                             plot(ax1, -left_y_dash(i,begin_index:end_index), left_x_dash(i,begin_index:end_index), colors_dash{lane}, 'LineWidth', 2); hold on;
%                             plot(ax1, -left_y_other(i,begin_index:end_index), left_x_other(i,begin_index:end_index), colors_other{lane}); hold on;
%                         else
%                             plot(ax1, -left_y(i,begin_index:end_index), left_x(i,begin_index:end_index), colors_left{lane}); hold on;
%                         end
%                         if chkbox_virtual_line.Value
%                             plot(ax1, -left_y2(i,begin_index:end_index), left_x2(i,begin_index:end_index), colors_virtual{lane}, 'MarkerFaceColor', colors_only{lane}, 'MarkerSize', 10); hold on;
%                         end
%                     end
%                 end
%             end
%         end
%     end
%     
%     if exist('left_x_long', 'var')
%         if chkbox_left_plot.Value
%             end_index = 0;
%             for lane = 1:lane_num(i)
%                 num = point_num_long(i, lane);
%                 if num ~= 0
%                     begin_index = end_index + 1;
%                     end_index = end_index + num;
%                     plot(ax2, -left_y_long(i,begin_index:end_index), left_x_long(i,begin_index:end_index), colors{lane}); hold on;
%                 end
%             end
%         end
%     end
%     
%     if exist('right_x', 'var')
%         if chkbox_right_plot.Value
%             end_index = 0;
%             for lane = 1:lane_num(i)
%                 num = right_point_num(i, lane);
%                 if num ~= 0
%                     begin_index = end_index + 1;
%                     end_index = end_index + num;
%                     if lane_plot(lane)
%                         if chkbox_right_zebra.Value
%                             tx = right_x(i, begin_index:end_index);
%                             ty = right_y(i, begin_index:end_index);
%                             tx(bitget(right_attr(i, begin_index:end_index), 19)==0) = NaN;
%                             ty(bitget(right_attr(i, begin_index:end_index), 19)==0) = NaN;
%                             plot(ax1, -ty, tx, 'kx', 'LineWidth', 3);
%                         end
%                         if chkbox_right_slow.Value
%                             tx = right_x(i, begin_index:end_index);
%                             ty = right_y(i, begin_index:end_index);
%                             tx(bitget(right_attr(i, begin_index:end_index), 20)==0) = NaN;
%                             ty(bitget(right_attr(i, begin_index:end_index), 20)==0) = NaN;
%                             plot(ax1, -ty, tx, 'gx', 'LineWidth', 3);
%                         end
%                         if chkbox_line_type.Value
%                             plot(ax1, -right_y_solid(i,begin_index:end_index), right_x_solid(i,begin_index:end_index), colors_solid{lane}, 'LineWidth', 2); hold on;
%                             plot(ax1, -right_y_dash(i,begin_index:end_index), right_x_dash(i,begin_index:end_index), colors_dash{lane}, 'LineWidth', 2); hold on;
%                             plot(ax1, -right_y_other(i,begin_index:end_index), right_x_other(i,begin_index:end_index), colors_other{lane}); hold on;
%                         else
%                             plot(ax1, -right_y(i,begin_index:end_index), right_x(i,begin_index:end_index), colors_right{lane}); hold on;
%                         end
%                         if chkbox_virtual_line.Value
%                             plot(ax1, -right_y2(i,begin_index:end_index), right_x2(i,begin_index:end_index), colors_virtual{lane}, 'MarkerFaceColor', colors_only{lane}, 'MarkerSize', 10); hold on;
%                         end
%                     end
%                 end
%             end
%         end
%     end
%     
%     if exist('right_x_long', 'var')
%         if chkbox_right_plot.Value
%             end_index = 0;
%             for lane = 1:lane_num(i)
%                 num = point_num_long(i, lane);
%                 if num ~= 0
%                     begin_index = end_index + 1;
%                     end_index = end_index + num;
%                     plot(ax2, -right_y_long(i,begin_index:end_index), right_x_long(i,begin_index:end_index), colors{lane}); hold on;
%                 end
%             end
%         end
%     end
%     
%     if exist('border_left_x', 'var')
%         if chkbox_border_left_plot.Value
%             end_index = 0;
%             for lane = 1:lane_num(i)
%                 num = border_left_point_num(i, lane);
%                 if num ~= 0
%                     begin_index = end_index + 1;
%                     end_index = end_index + num;
%                     if lane_plot(lane)
%                         plot(ax1, -border_left_y(i,begin_index:end_index), border_left_x(i,begin_index:end_index), colors_left{lane}); hold on;
%                     end
%                 end
%             end
%         end
%     end
%     
%     if chkbox_border_left_mul_lane.Value
%         end_index = 0;
%         for lane = 1:lane_num(i)
%             num = border_left_mul_num(i, lane);
%             if num ~= 0
%                 begin_index = end_index + 1;
%                 end_index = end_index + num;
%                 plot(ax1, -border_left_mul_y(i,begin_index:end_index), border_left_mul_x(i,begin_index:end_index), colors{lane}); hold on;
%             end
%         end
%     end
%     
%     if chkbox_border_right_mul_lane.Value
%         end_index = 0;
%         for lane = 1:lane_num(i)
%             num = border_right_mul_num(i, lane);
%             if num ~= 0
%                 begin_index = end_index + 1;
%                 end_index = end_index + num;
%                 plot(ax1, -border_right_mul_y(i,begin_index:end_index), border_right_mul_x(i,begin_index:end_index), colors{lane}); hold on;
%             end
%         end
%     end
%     
%     if exist('border_right_x', 'var')
%         if chkbox_border_right_plot.Value
%             end_index = 0;
%             for lane = 1:lane_num(i)
%                 num = border_right_point_num(i, lane);
%                 if num ~= 0
%                     begin_index = end_index + 1;
%                     end_index = end_index + num;
%                     if lane_plot(lane)
%                         plot(ax1, -border_right_y(i,begin_index:end_index), border_right_x(i,begin_index:end_index), colors_right{lane}); hold on;
%                     end
%                 end
%             end
%         end
%     end
%     
%     if chkbox_mpu_branch_plot.Value
%         for lane = 1:lane_num(i)
%             branch_lane = center_connection(i, (lane - 1) * 10 + 6);
%             branch_index = center_connection(i, (lane - 1) * 10 + 5);
%             if branch_lane ~= 65535 && branch_index ~= 65535
%                 offset = 0;
%                 if branch_lane ~= 0
%                     for temp = 0:branch_lane - 1
%                         offset = offset + point_num(i, temp + 1);
%                     end
%                 end
%                 branch_x = mpu_x(i, offset + branch_index + 1);
%                 branch_y = mpu_y(i, offset + branch_index + 1);
%                 plot(ax1, -branch_y, branch_x, 'kx','LineWidth', 3);
%             end
%         end
%     end
%     
%     if chkbox_mpu_join_plot.Value
%         for lane = 1:lane_num(i)
%             join_lane = center_connection(i, (lane - 1) * 10 + 4);
%             join_index = center_connection(i, (lane - 1) * 10 + 3);
%             if join_lane ~= 65535 && join_index ~= 65535
%                 offset = 0;
%                 if join_lane ~= 0
%                     for temp = 0:join_lane - 1
%                         offset = offset + point_num(i, temp + 1);
%                     end
%                 end
%                 join_x = mpu_x(i, offset + join_index + 1);
%                 join_y = mpu_y(i, offset + join_index + 1);
%                 plot(ax1, -join_y, join_x, 'rx','LineWidth', 3);
%             end
%         end
%     end
%     
%     if chkbox_left_branch_plot.Value
%         for lane = 1:lane_num(i)
%             branch_lane = left_connection(i, (lane - 1) * 10 + 6);
%             branch_index = left_connection(i, (lane - 1) * 10 + 5);
%             branch_line = left_connection(i, (lane - 1) * 10 + 9);
%             if branch_lane ~= 65535 && branch_index ~= 65535 && (branch_line == 1 || branch_line == 2)
%                 if branch_line == 1
%                     temp_num = left_point_num;
%                     temp_x = left_x;
%                     temp_y = left_y;
%                 else
%                     temp_num = right_point_num;
%                     temp_x = right_x;
%                     temp_y = right_y;
%                 end
%                 offset = 0;
%                 if branch_lane ~= 0
%                     for temp = 0:branch_lane - 1
%                         offset = offset + temp_num(i, temp + 1);
%                     end
%                 end
%                 branch_x = temp_x(i, offset + branch_index + 1);
%                 branch_y = temp_y(i, offset + branch_index + 1);
%                 plot(ax1, -branch_y, branch_x, 'kx','LineWidth', 3);
%             end
%         end
%     end
%     
%     if chkbox_left_join_plot.Value
%         for lane = 1:lane_num(i)
%             join_lane = left_connection(i, (lane - 1) * 10 + 4);
%             join_index = left_connection(i, (lane - 1) * 10 + 3);
%             join_line = left_connection(i, (lane - 1) * 10 + 8);
%             if join_lane ~= 65535 && join_index ~= 65535 && (join_line == 1 || join_line == 2)
%                 if join_line == 1
%                     temp_num = left_point_num;
%                     temp_x = left_x;
%                     temp_y = left_y;
%                 else
%                     temp_num = right_point_num;
%                     temp_x = right_x;
%                     temp_y = right_y;
%                 end
%                 offset = 0;
%                 if join_lane ~= 0
%                     for temp = 0:join_lane - 1
%                         offset = offset + temp_num(i, temp + 1);
%                     end
%                 end
%                 join_x = temp_x(i, offset + join_index + 1);
%                 join_y = temp_y(i, offset + join_index + 1);
%                 plot(ax1, -join_y, join_x, 'rx','LineWidth', 3);
%             end
%         end
%     end
%     
%     if chkbox_right_branch_plot.Value
%         for lane = 1:lane_num(i)
%             branch_lane = right_connection(i, (lane - 1) * 10 + 6);
%             branch_index = right_connection(i, (lane - 1) * 10 + 5);
%             branch_line = right_connection(i, (lane - 1) * 10 + 9);
%             if branch_lane ~= 65535 && branch_index ~= 65535 && (branch_line == 1 || branch_line == 2)
%                 if branch_line == 1
%                     temp_num = left_point_num;
%                     temp_x = left_x;
%                     temp_y = left_y;
%                 else
%                     temp_num = right_point_num;
%                     temp_x = right_x;
%                     temp_y = right_y;
%                 end
%                 offset = 0;
%                 if branch_lane ~= 0
%                     for temp = 0:branch_lane - 1
%                         offset = offset + temp_num(i, temp + 1);
%                     end
%                 end
%                 branch_x = temp_x(i, offset + branch_index + 1);
%                 branch_y = temp_y(i, offset + branch_index + 1);
%                 plot(ax1, -branch_y, branch_x, 'kx','LineWidth', 3);
%             end
%         end
%     end
%     
%     if chkbox_right_join_plot.Value
%         for lane = 1:lane_num(i)
%             join_lane = right_connection(i, (lane - 1) * 10 + 4);
%             join_index = right_connection(i, (lane - 1) * 10 + 3);
%             join_line = right_connection(i, (lane - 1) * 10 + 8);
%             if join_lane ~= 65535 && join_index ~= 65535 && (join_line == 1 || join_line == 2)
%                 if join_line == 1
%                     temp_num = left_point_num;
%                     temp_x = left_x;
%                     temp_y = left_y;
%                 else
%                     temp_num = right_point_num;
%                     temp_x = right_x;
%                     temp_y = right_y;
%                 end
%                 offset = 0;
%                 if join_lane ~= 0
%                     for temp = 0:join_lane - 1
%                         offset = offset + temp_num(i, temp + 1);
%                     end
%                 end
%                 join_x = temp_x(i, offset + join_index + 1);
%                 join_y = temp_y(i, offset + join_index + 1);
%                 plot(ax1, -join_y, join_x, 'rx','LineWidth', 3);
%             end
%         end
%     end
%     
%     if chkbox_left_line_near_plot.Value
%         end_index = 0;
%         line_end_index = 0;
%         for lane = 1:lane_num(i)
%             num = point_num(i, lane);
%             line_num = left_point_num(i, lane);
%             if num ~= 0 
%                 begin_index = end_index + 1;
%                 end_index = end_index + num;
%                 if line_num ~= 0
%                     line_begin_index = line_end_index + 1;
%                     line_end_index = line_end_index + line_num;
%                     for index = begin_index:10:end_index
%                         near = left_line_near(i, index);
%                         if near ~= 65535
%                             p1 = [-mpu_y(i, index), -left_y(i, near + line_begin_index)];
%                             p2 = [mpu_x(i, index), left_x(i, near + line_begin_index)];
%                             plot(ax1, p1, p2, 'k-', 'LineWidth', 3);
%                         end
%                     end
%                 end
%             end
%         end
%     end
%     
%     if chkbox_right_line_near_plot.Value
%         end_index = 0;
%         line_end_index = 0;
%         for lane = 1:lane_num(i)
%             num = point_num(i, lane);
%             line_num = right_point_num(i, lane);
%             if num ~= 0 
%                 begin_index = end_index + 1;
%                 end_index = end_index + num;
%                 if line_num ~= 0
%                     line_begin_index = line_end_index + 1;
%                     line_end_index = line_end_index + line_num;
%                     for index = begin_index:10:end_index
%                         near = right_line_near(i, index);
%                         if near ~= 65535
%                             p1 = [-mpu_y(i, index), -right_y(i, near + line_begin_index)];
%                             p2 = [mpu_x(i, index), right_x(i, near + line_begin_index)];
%                             plot(ax1, p1, p2, 'r-', 'LineWidth', 3);
%                         end
%                     end
%                 end
%             end
%         end
%     end
%                 
%     laneEdit.String = lane_num(i);
%     egoLaneEdit.String = ego_lane(i);
%     if ego_lane(i) < 16
%     % if exist('S_lmMapLnEgoIdx', 'var')
%         side_point_index = MpuMessage1.strLaneConnection.sigValue.signals.values(i, 10 * ego_lane(i) + 7);
%         sidePointEdit.String = side_point_index;
%         % sidePointEdit.String = S_lmMapLnEgoIdx.signals.values(i);
%     end
%            
%     %{
%     for j = 1:16
%         side_index(j).String = MpuMessage1.strLaneConnection.sigValue.signals.values(i, (j - 1) * 10 + 7);
%         ego_conf(j).String = MpuMessage1.strEgoLaneIndexConf.sigValue.signals.values(i, j);
%     end
%     %}
%     
%     TimeInfoTextBox.String = sprintf('Time = %.2fsec,',LogTime(i));
%     
%     if exist('ht_lat', 'var')
%         CorrInfoTextBox.String = sprintf('%f, %f', ht_lat(i), ht_lon(i));
%     end
%     
%     pause(CP_operatePuase);
% end
ReplotBEV_fig6;

%zh_modify_end*************************************************************

function graghDefulatSet(ax1)
ax1.NextPlot = 'add';
ax1.XGrid = 'on';
ax1.XMinorGrid='on';
ax1.YGrid = 'on';
ax1.YMinorGrid='on';
end
