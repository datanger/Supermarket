paraFolder = fullfile(currentDir,'ParaSave');
if ~exist(paraFolder)
    mkdir(paraFolder);
end
folderNamee = fullfile(paraFolder,folderName);
if ~exist(folderNamee)
    mkdir(folderNamee);
end
DataIndex = [];
for i = 1:length(eMap)
    conditionA = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(i),8) || ...
    bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(i),9) || ...
    bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(i),10);
    conditionB = saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmVecCtrlLnExistFlg.signals.values(i,2) == 0;
    if eMap(i) == 1 && (conditionA || conditionB)
        DataIndex = [DataIndex;i];
    end
end
if ~isempty(DataIndex)
    numIdx = DataIndex(1);
    for i = 2:length(DataIndex)
        if DataIndex(i)-DataIndex(i-1) == 1
        else
            numIdx = [numIdx;DataIndex(i)];
        end
    end
    numIdxType = "";
    for i = 1:length(numIdx)
        CA = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(numIdx(i)),8);
        CB = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(numIdx(i)),9);
        CC = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(numIdx(i)),10);
        CD = saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values(numIdx(i));
        CE = saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmVecCtrlLnExistFlg.signals.values(numIdx(i),2);
        if CA == 1
            numIdxType(i,1) = 'CA';
        else
            if CB == 1
                numIdxType(i,1) = 'CB';
            else
                if CC == 1
                    numIdxType(i,1) = 'CC';
                else
                    if CD
                        numIdxType(i,1) = 'CD';
                    else
                        if CE == 1
                            numIdxType(i,1) = 'CE';
                        else
                            numIdxType(i,1) = 'Other';
                        end
                    end
                end
            end
        end
    end
    timeBackPeriod = 20;
    timeForwardPeriod = 20;
    timeBackPeriodPLD = 20;
    timeForwardPeriodPLD = 20;     

%% C.  View Construction Loop Start %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for j = 1:length(numIdx)
        numIdx1 = numIdx(j);
        numIdxType1 = numIdxType(j);
        ZZ_pickUpIndex = [];
        ZZ_pickUpIndexType = [];
        for searchIndex=1:length(numIdx1)
            if numIdx1(searchIndex) - timeBackPeriod < 1
                if numIdx1(searchIndex) + timeForwardPeriod > length(eMap)
                    for tmpIndex=1:length(eMap)
                        ZZ_pickUpIndex = vertcat(ZZ_pickUpIndex,tmpIndex);
                        ZZ_pickUpIndexType = vertcat(ZZ_pickUpIndexType,numIdxType1(searchIndex));
                    end
                else
                    for tmpIndex=1:numIdx1(searchIndex)+timeForwardPeriod
                        ZZ_pickUpIndex = vertcat(ZZ_pickUpIndex,tmpIndex);
                        ZZ_pickUpIndexType = vertcat(ZZ_pickUpIndexType,numIdxType1(searchIndex));
                    end
                end
            elseif numIdx1(searchIndex) + timeForwardPeriod > length(eMap)
                if numIdx1(searchIndex) - timeBackPeriod < 1
                    for tmpIndex=1:length(eMap)
                        ZZ_pickUpIndex = vertcat(ZZ_pickUpIndex,tmpIndex);
                        ZZ_pickUpIndexType = vertcat(ZZ_pickUpIndexType,numIdxType1(searchIndex));
                    end
                else
                    for tmpIndex=numIdx1(searchIndex)-timeBackPeriod:length(eMap)
                        ZZ_pickUpIndex = vertcat(ZZ_pickUpIndex,tmpIndex);
                        ZZ_pickUpIndexType = vertcat(ZZ_pickUpIndexType,numIdxType1(searchIndex));
                    end
                end
            else
                for tmpIndex2=numIdx1(searchIndex)-timeBackPeriod:numIdx1(searchIndex)+timeForwardPeriod
                    if length(ZZ_pickUpIndex) >= 1
                        if ZZ_pickUpIndex(end) >= tmpIndex2
                        else
                        ZZ_pickUpIndex = vertcat(ZZ_pickUpIndex,tmpIndex2);
                        ZZ_pickUpIndexType = vertcat(ZZ_pickUpIndexType,numIdxType1(searchIndex));
                        end
                    else
                        ZZ_pickUpIndex = vertcat(ZZ_pickUpIndex,tmpIndex2);
                        ZZ_pickUpIndexType = vertcat(ZZ_pickUpIndexType,numIdxType1(searchIndex));
                    end
                end
            end
        end
        for i = 1:length(ZZ_pickUpIndex)
            ltmp = ZZ_pickUpIndex(i);
            switch ZZ_pickUpIndexType(i)
                case "CA"
                    paraSaveFolder = fullfile(folderNamee,'�p�^�[��A');
                    if ~exist(paraSaveFolder)
                        mkdir(paraSaveFolder);
                    end
                case "CB"
                    paraSaveFolder = fullfile(folderNamee,'�p�^�[��B');
                    if ~exist(paraSaveFolder)
                        mkdir(paraSaveFolder);
                    end
                case "CC"
                    paraSaveFolder = fullfile(folderNamee,'�p�^�[��C');
                    if ~exist(paraSaveFolder)
                        mkdir(paraSaveFolder);
                    end
                case "CD"
                    paraSaveFolder = fullfile(folderNamee,'�p�^�[��DEF');
                    if ~exist(paraSaveFolder)
                        mkdir(paraSaveFolder);
                    end
                case "CE"
                    paraSaveFolder = fullfile(folderNamee,'�p�^�[��DEF');
                    if ~exist(paraSaveFolder)
                        mkdir(paraSaveFolder);
                    end
                case "Other"
                    paraSaveFolder = fullfile(folderNamee,'Other');
                    if ~exist(paraSaveFolder)
                        mkdir(paraSaveFolder);
                    end
            end
            %% %%%%%%%%%%%%%%%%% S1: ����Ɖ摜�ۑ��p�̏����@�J�n��end %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% C.�`��loop��

             xlimVLow  = str2double(YlimLowerEdit.String);
             xlimVHigh = str2double(YlimUpperEdit.String);
             ylimVLow  = str2double(XlimLowerEdit.String);
             ylimVHigh = str2double(XlimUpperEdit.String);

             xlim(ax1,[xlimVLow,xlimVHigh]);
             ylim(ax1,[ylimVLow,ylimVHigh]);

             if jumpbutton_value
                 TimeJumperEdit.String = num2str(LogTime(ltmp));
                 jumpbutton_value = 0;
             end

            if isvalid(ax1)
                ax1.NextPlot = 'add';
                cla(ax1);
                hold(ax1, 'on');
            end

            % LM���Ȉʒu�x�[�X�n�}�����E���S��
            if chkbox_line_Map.Value
                for ln = 0:15
                    plotMapLaneFunc451(ax1,ltmp,ln,mapCtLmX,mapCtLmY);
                    plotMapLaneFunc451(ax1,ltmp,ln,mapLtLmX,mapLtLmY);
                    plotMapLaneFunc451(ax1,ltmp,ln,mapRtLmX,mapRtLmY);
                end
            end

            % Ctrl�Ԑ�
            if chkbox_CenterCtrl.Value

                for ln = 0:2
                    plotLmOutCtrlLaneFunc(ax1,ltmp,ln,lmCtrlX,lmCtrlY,1);
                end

%                    plot(ax1,saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntY.signals.values(ltmp,:),saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntX.signals.values(ltmp,:),"go") ;

                line105sec = yline(ax1,egoSpd(ltmp,1)*TargetSec1,'LineWidth',2);
                uistack(line105sec, 'bottom');
                line2sec = yline(ax1,egoSpd(ltmp,1)*TargetSec2,'LineWidth',2, 'Color','red');
                uistack(line2sec, 'bottom');
            end

            % �J����C0�O��
            plot(ax1,Ky(ltmp,:).*double(Kb(ltmp,:)>=2),Kx(ltmp,:).*double(Kb(ltmp,:)>=2) ,"*" ,'MarkerEdgeColor', [0.7 0.3 0.3]);
            plot(ax1,Ky(ltmp,:).*double(Kb(ltmp,:)==1),Kx(ltmp,:).*double(Kb(ltmp,:)==1) ,"*" ,'MarkerEdgeColor', [0.3 0.7 0.3]);
            plot(ax1,Ky(ltmp,:).*double(Kb(ltmp,:)==0),Kx(ltmp,:).*double(Kb(ltmp,:)==0) ,"*",'MarkerEdgeColor', [0.7 0.7 0.7]);

            if chkbox_line_cam.Value

                 try
                    plot(ax1, ClineYr(ltmp,:),ClineXr(ltmp,:),"+c");
                    plot(ax1, ClineYl(ltmp,:),ClineXl(ltmp,:),"+c");
                catch
                     plot(ax1,0,0,"*","MarkerFaceColor",[0.1,0.8,0.1]); 
                end

                if LMCMSignalExist
                   plot(ax1,CamY(ltmp,:),CamX(ltmp,:), "k.");
                   plot(ax1,CamY2(ltmp,:),CamX2(ltmp,:), "b.");
                else
                   plot(ax1,CamY(ltmp,:),CamX(ltmp,:), "ro");
                end


               

%                     plot(ax1,C0y(ltmp,:).*C0b(ltmp,:),C0x(ltmp,:).*C0b(ltmp,:) , "c*");
                plot(ax1,C0y2(ltmp,:).*C0b2(ltmp,:),C0x2(ltmp,:).*C0b2(ltmp,:) , "ro");
            end


            % �J�[�u�ȗ�
            if isvalid(ax814)
                ax814.NextPlot = 'replace';
            end
                plot(ax814,CurvatureX,lmVecMapEgoLnPntExCurvature(ltmp,:),"c.-");
                ax814.XGrid = 'on';
                ax814.XMinorGrid='on';
                ax814.YGrid = 'on';
                ax814.YMinorGrid='on';

            % ���W���v���b�g
            if swUseRawPF == 1
                if chkbox_Pf_Obj.Value
                    vecObsID = vecObsIDAll(ltmp,:);
                    vecObsX = vecObsXAll(ltmp,:);
                    vecObsY = vecObsYAll(ltmp,:);
                    vecObsL = vecObsLAll(ltmp,:);
                    vecObsW = vecObsWAll(ltmp,:);
                    vecObsYaw = vecObsYawAll(ltmp,:);
                    for obsIdx=1:min(length(vecObsID),length(vecObsYaw))
                        if vecObsID(obsIdx)~=0
                            id    = vecObsID(obsIdx);
                            x     = vecObsX(obsIdx);
                            y     = vecObsY(obsIdx);
                            L     = vecObsL(obsIdx);
                            w     = vecObsW(obsIdx);
                            theta = vecObsYaw(obsIdx);
                            costh = cos(theta);
                            sinth = sin(theta);
                            tl_x =  L*0.5;                          % ����x
                            tl_y =  w*0.5;                          % ����y
                            tr_x =  L*0.5;                          % �E��x
                            tr_y = -w*0.5;                          % �E��y
                            br_x = -L*0.5;                          % �E��x
                            br_y = -w*0.5;                          % �E��y
                            bl_x = -L*0.5;                          % ����x
                            bl_y =  w*0.5;                          % ����y
                            x1 = tl_x*costh - tl_y*sinth + x;       % ����x���W�ϊ�
                            y1 = tl_x*sinth + tl_y*costh + y;       % ����y���W�ϊ�
                            x2 = tr_x*costh - tr_y*sinth + x;       % �E��x���W�ϊ�
                            y2 = tr_x*sinth + tr_y*costh + y;       % �E��y���W�ϊ�
                            x3 = br_x*costh - br_y*sinth + x;       % �E��x���W�ϊ�
                            y3 = br_x*sinth + br_y*costh + y;       % �E��y���W�ϊ�
                            x4 = bl_x*costh - bl_y*sinth + x;       % ����x���W�ϊ�
                            y4 = bl_x*sinth + bl_y*costh + y;       % ����y���W�ϊ�
                            X = [x1 x2 x3 x4];                      % ���W�̒��_X
                            Y = [y1 y2 y3 y4];
                            obs(obsIdx) = patch(ax1, Y, X, 'yellow');
                            set(obs(obsIdx), 'FaceAlpha', 0.5);
                        else
                            obs(obsIdx) = patch(ax1, [0,0,0,0], [0,0,0,0], 'yellow');
                        end
                    end
                end

%                     �t���[�X�y�[�X���v���b�g
                if chkbox_Pf_Fsp.Value
                    plot(ax1,CamFsCalcY_sel(ltmp,:),CamFsCalcX_sel(ltmp,:),'m.');
                end
            end

            % PL����p�X
             plot(ax1, plVecPathY(ltmp,:), plVecPathX(ltmp,:), 'Color',[0.6 0.6 0.1],'LineWidth',3.2);

            TimeInfoTextBox.String = sprintf('Time = %.2fsec, PldCam : %s, lmptstt:%s, Pld %s Inh %s CamDiff %s mapDiff %s',...
                LogTimeCam(ltmp),...
                bitgets(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(ltmp)),...
                bitgets(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(ltmp,1)),...
                bitgets(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(ltmp)),...
                bitgets(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmInhStt.signals.values(ltmp)), ...
                bitgets(saTldMiBusOut_lmTldMapBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(ltmp,6)),...
                bitgets(saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmmMapDiffStt.signals.values(ltmp))...
                );
%                 LocBox.String = sprintf('%05f, %05f', S_lmVecMapLnPntExCurvature.signals.values(i,2),S_LMLoc_ORILATLON.signals.values(i,3));

            %% �E���v���b�g
            timeChartIndex = ltmp;

            ls = Group1Time(max(1, ltmp-100));
            le = Group1Time(min(ltmp+100, N));
            XLim = [ls, le];

            %% MAP 1
            ax511.YLim = [ 0 3 ];
            ax511.XLim = XLim;

            map1title.String = sprintf('\\color{red}eMap:%d \\color{blue}eYrm:%d \\color{green}mhStt:%d',...
                map1_eMap(timeChartIndex),...
                map1_eYrm(timeChartIndex),...
                map1_mhStt(timeChartIndex)...
                );


            %% MAP 2
            yticks( ax512, 0:100:600 );
            ax512.YLim = [ 0 600 ];
            ax512.XLim = XLim;
            map2title.String = sprintf('Radius:%.1f', map2_radius(timeChartIndex));                

            %% MAP 3
            ax513.YLim = [ 0 120 ];
            ax513.XLim = XLim;
            
            map3title.String = sprintf('egoSpd:%.1f', map3_egoSpd(timeChartIndex));

            %% MAP 4
            ax516.YLim = [ 0 5 ];
            ax516.XLim = XLim;
            
            map4title.String = sprintf('\\color{black}RightLineMatch:%d  \\color{red}LeftLineMatch:%d  \\color{blue}CameraBase:%d  \\color{magenta}MapBase:%d',...
                map4_rightLineMatch(timeChartIndex),...
                map4_leftLineMatch(timeChartIndex),...
                map4_cameraBase(timeChartIndex),...
                map4_mapBase(timeChartIndex)...
                );

            %% MAP 5
            ax517.YLim = ([0 2]);
            ax517.XLim = XLim;
                        
            map5title.String = sprintf('System Limit:%s', num2str(map5_pldON(timeChartIndex)));
            
            %% MAP 6
            ax518.YLim = ([0 2]);
            ax518.XLim = XLim;
            
            map6title.String = sprintf('\\color{black}LeftClinebFlg:%s \\color{red}RightClinebFlg:%s',...
                int2str(map6_leftClinebFlg(timeChartIndex)), int2str(map6_rightClinebFlg(timeChartIndex))...
                );
            
            %% MAP 7
            ax519.XLim = XLim;
            
            map7title.String = sprintf('\\color{blue}Gap value%.2fsec:%.3f \\color{magenta}Gap value%.1fsec:%.3f',...
                TargetSec1, map7_gapValue1(timeChartIndex),TargetSec2, map7_gapValue2(timeChartIndex)...
                );
            
            %% MAP 8
            if exist('ax520', 'var') && isgraphics(ax520)
                cla(ax520);
            else
                ax520 = subplot(9,4,35);
            end               
            set(ax520,'xtick',[]);
            set(ax520,'ytick',[]);
            set(ax520,'xcolor','w');
            set(ax520,'ycolor','w');               
            txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'mhStt', txtCommonOption{:});
            txt.String = sprintf('mhStt: %s', map8_mhStt{timeChartIndex});
            txt.Position= [0.01 1 0];
            
            txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmPldStt', txtCommonOption{:});
            txt.String = sprintf('lmPldStt: %s', map8_lmPldStt{timeChartIndex});
            txt.Position= [0.01 0.85 0];
            
            txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmInhStt',txtCommonOption{:});
            txt.String = sprintf('lmInhStt: %s', map8_lmInhStt{timeChartIndex});
            txt.Position= [0.01 0.70 0];
            
            txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmLnMode', txtCommonOption{:});
            txt.String = sprintf('lmLnMode: %s', map8_lmLnMode{timeChartIndex});
            txt.Position= [0.01 0.55 0];
            
            txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmmmMapDiffStt', txtCommonOption{:});
            txt.String = sprintf('lmmmMapDiffStt: %s', map8_lmmmMapDiffStt{timeChartIndex});
            txt.Position= [0.01 0.40 0];
            
            txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmmmCamDiffStt', txtCommonOption{:});
            txt.String = sprintf('lmmmCamDiffStt: %s', map8_lmmmCamDiffStt{timeChartIndex});
            txt.Position= [0.01 0.25 0];
            
            txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'ReserveUint7', txtCommonOption{:});
            txt.String = sprintf('ReserveUint7: %s', map8_ReserveUint7{timeChartIndex});
            txt.Position= [0.01 0.1 0];
            hold off;


            %% rankBTimeplot�i�E����`��Chart1�`6�j
            %% Chart 1
            ax611.YLim = [ 0 100 ];
            ax611.XLim = XLim;
            
            if LMCMSignalExist
                camchartidx = timeChartIndex;
            else
                camchartidx = ltmp;
            end
                
            chart1title.String = sprintf('\\color{red}LeftCamEndX:%s \\color{blue}RightCamEndX:%s',...
                num2str(chart1_leftCamEndX(ltmp)),...
                num2str(chart1_rightCamEndX(ltmp))...
                );
            
            %% Chart 2
            ax612.YLim = [ 0 1 ];
            ax612.XLim = XLim;
            
            chart2title.String = sprintf('\\color{red}LeftCLineProb:%s \\color{blue}RightCLineProb:%s',...
                num2str(chart2_leftCLineProb(ltmp)),...
                num2str(chart2_rightCLineProb(ltmp))...
                );
            
            %% Chart 3
            ax613.YLim = [ 0 3.2 ];
            ax613.XLim = XLim;
            
            chart3title.String = sprintf('\\color{red}LeftCLineQuality:%s \\color{blue}RightCLineQuality:%s',...
                num2str(chart3_leftCLineQuality(ltmp)),...
                num2str(chart3_rightCLineQuality(ltmp))...
                );
            
            %% Chart 4
            ax614.YLim = [ 0 11.5 ];
            ax614.XLim = XLim;
            
            chart4title.String = sprintf(...
                '\\color{black}typeL:%s \\color{red}typeR:%s\\color{blue}typeNL:%s\\color{magenta}typeNR:%s',...
                num2str(chart4_leftCLineType(ltmp)),...
                num2str(chart4_rightCLineType(ltmp)),...
                num2str(chart4_nextLeftCLineType(ltmp)),...
                num2str(chart4_nextRightCLineType(ltmp)));
            %% Chart 5
            ax615.YLim = [ 0 11.5 ];
            ax615.XLim = XLim;
            
            chart5title.String = sprintf(...
                '\\color{green}Lraw:%s \\color{cyan}Rraw:%s \\color{black}NLraw:%s \\color{black}NRraw:%s',...
                num2str(chart5_leftCLineTypeRaw(ltmp)),...
                num2str(chart5_rightCLineTypeRaw(ltmp)),...
                num2str(chart5_nextLeftCLineTypeRaw(ltmp)),...
                num2str(chart5_nextRightCLineTypeRaw(ltmp))...
                );
            %% Chart 5
%             ax615.YLim = [ 0 11.5 ];
%             ax615.XLim = XLim;
%             yticks( ax615, 0:2:11.5 );
            
            %% Chart 6
%             ax616.YLim = [ 0 11.5 ];
%             ax616.XLim = XLim;
%             yticks( ax616, 0:2:11.5 );
            
            %% Chart 7
            ax617.XLim = XLim;
            chart7title.String = sprintf('mpuTimeStamp1Diff:%s',...
                num2str(chart7_mpuTimeStamp1Diff(timeChartIndex)));
            %% vehicle 1
            try
            ax711.XLim = XLim;
            vehicle1title.String = sprintf('epsStrAngRad:%s',...
                num2str(vehicle1_epsStrAngRad(timeChartIndex)));
            catch
            end
            %% vehicle 1
            ax712.XLim = XLim;
            vehicle2title.String = sprintf('saEgoRateYaw:%s',...
                num2str(vehicle2_saEgoRateYaw(timeChartIndex)));
            %% vehicle 3
            ax713.XLim = XLim;
            vehicle3title.String = sprintf('lmTldMapCnt:%s',...
                    num2str(vehicle3_lmTldMapCnt(timeChartIndex)));

            %% frazki_add 1
            ax811.XLim = XLim;
            ax811.YLim = [ 0 4 ];

            %% frazki_add 2
            ax812.YLim = [ -4 4 ];
            ax812.XLim = XLim;
            frazkiAdd2title.String = sprintf('\\color{black}C0Left:%s  \\color{red}C0Right:%s  \\color{blue}C0Center:%s',...
                num2str(C0Left(ltmp)),...
                num2str(C0Right(ltmp)),...
                num2str(C0Center(ltmp)) ...
                );

            %% frazki_add 3
            ax813.XLim = XLim;
            ax813.YLim = [ -2.5 2.5 ];

            try
            frazkiAdd3title.String = sprintf('StrTrq:%s',...
                    num2str(epsVecStrTrq(ltmp)));
            catch
            end

            %% frazki_add 4
            frazkiAdd4title = title(ax814,'Curvature[1/m], �E:�{,��:�[');

             %% frazki_add 5
            ax815.XLim = XLim;
            ax815.YLim = [ -0.5 3.5 ];
            frazkiLnModeTitle.String = sprintf('lmLaneExistFlg \\color{red}camera:%s  \\color{blue}frontCar:%s  \\color{green}caravailable:%s',...
            num2str((LnModeCamCenter(ltmp))),...
            num2str((LnModeFrontCarTrace(ltmp))),...
            num2str((CarAvailable(ltmp))));

            ax816.XLim = XLim;
            frazkiCDiff.String = sprintf('\\color{red}C1Diff:%s  \\color{blue}C2Diff:%s  \\color{green}C3Diff:%s',...
            num2str((cC1Diff(ltmp))),...
            num2str((cC2Diff(ltmp))),...
            num2str((cC3Diff(ltmp))));

            ax817.XLim = XLim;
            frazkiCDiffQ.String = sprintf('impt:%s',...
            string(bitgets(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(ltmp,1))));

            ax818.XLim = XLim;
            frazkiCDiffQ.String = sprintf('pldcam:%s',...
            string(bitgets(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(ltmp))));


            %% ����
            if exist('xlines', 'var')
                delete(xlines);
            end
            
            xlines = [...
                xline(ax511, Group1Time(timeChartIndex)),...
                xline(ax512, Group1Time(timeChartIndex)),...
                xline(ax513, Group1Time(timeChartIndex)),...
                xline(ax516, Group1Time(timeChartIndex)),...
                xline(ax517, Group1Time(timeChartIndex)),...
                xline(ax518, Group1Time(timeChartIndex)),...
                xline(ax519, Group1Time(timeChartIndex)),...
                xline(ax611, Group1Time(timeChartIndex)),...
                xline(ax612, Group1Time(timeChartIndex)),...
                xline(ax613, Group1Time(timeChartIndex)),...
                xline(ax614, Group1Time(timeChartIndex)),...
                xline(ax615, Group1Time(timeChartIndex)),...
                xline(ax617, Group1Time(timeChartIndex))...
                xline(ax711, Group1Time(timeChartIndex))...
                xline(ax712, Group1Time(timeChartIndex))...
                xline(ax713, Group1Time(timeChartIndex))...
                xline(ax811, Group1Time(timeChartIndex))...
                xline(ax812, Group1Time(timeChartIndex))...
                xline(ax813, Group1Time(timeChartIndex))...
                xline(ax815, Group1Time(timeChartIndex))...
                xline(ax816, Group1Time(timeChartIndex))...
                xline(ax817, Group1Time(timeChartIndex))...
                ];
            drawnow;
            picName = sprintf('\\time_%0.2f[sec].png',LogTimeCam(ltmp)); 
            frame = getframe(gcf);
            image_data = frame.cdata;
            imwrite(image_data, strcat(paraSaveFolder,picName));
            try
                Apara = strcat('parapara:All:',string(j),'/',string(length(numIdx)),'-------',string(i),'/',string(length(ZZ_pickUpIndex)));
                disp(Apara)
            catch
            end
        end
    end
end

function plotMapLaneFunc451(ax1,smpl,ln,X,Y)
    lnPntNumMax = 451;
    if ln == 0
        color = 'r.';
    elseif ln == 1
        color = 'b.';
    elseif ln == 2
        color = 'g.';
    elseif ln == 3
        color = 'm.';
    elseif ln == 4
        color = 'c.';
    elseif ln == 5
        color = 'k.';
    elseif ln == 6
        color = 'r+';
    elseif ln == 7
        color = 'b+';
    elseif ln == 8
        color = 'g+';
    elseif ln == 9
        color = 'm+';
    elseif ln == 10
        color = 'c+';
    elseif ln == 11
        color = 'k+';
    elseif ln == 12
        color = 'ro';
    elseif ln == 13
        color = 'bo';
    elseif ln == 14
        color = 'go';
    elseif ln == 15
        color = 'mo';
    end
    plot(ax1,Y(smpl,lnPntNumMax*ln+1:lnPntNumMax*ln+451),X(smpl,lnPntNumMax*ln+1:lnPntNumMax*ln+451),color); hold on;
end


function plotLmOutCtrlLaneFunc(ax1,smpl,ln,lnX,lnY,sw)
    
    lnPntNum = 451;

    % ctrl�Ԑ��͍��Ԑ��E���Ԑ��E�E�Ԑ��̏��ɔz�񉻂���Ă��邽�߁Aln=0(1�Ԑ�)�̂Ƃ���452�`902�z����Q�Ƃ���
    if ln == 0
        ln = 1;
    elseif ln == 1
        ln = 0;
    end

    if sw == 1 && ln == 1
        color = 'bp';
    else
        if sw == 1
            color = 'bo';
        elseif sw == 2
            color = 'co';
        elseif sw == 3
            color = 'ko';
        elseif sw == 101
            color = 'g+';
        elseif sw == 102
            color = 'm+';
        elseif sw == 103
            color = 'k+';
        end
    end
    plot(ax1,lnY(smpl,lnPntNum*ln+1:lnPntNum*ln+451),lnX(smpl,lnPntNum*ln+1:lnPntNum*ln+451),color,"MarkerSize",7); hold on;
end


function A= bitgets(a)
    k = "";
    for i=1:32
        b = bitget(a,i);
        if b==1
            k=k+string(i-1)+",";
        end
    end
    A = k;
end