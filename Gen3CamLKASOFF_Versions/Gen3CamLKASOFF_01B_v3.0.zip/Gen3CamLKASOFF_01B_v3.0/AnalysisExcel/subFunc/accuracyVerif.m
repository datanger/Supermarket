%% LM���Ȉʒu�̏c�ʒu���x�����؂���(C0�O�Ղ�LM���H���r����)
% �ڕW�P�F���ԑO��**m��̑��H��C0�O�Ղ̉��ʒu�������n��Ńv���b�g����
% �ڕW�Q�F�Q��resim���ʂ��r���Ăǂ���̌��ʂ̕����c�ʒu���x���ǂ���(C0�O�Ղ�LM���H�̈�v����������)����������

%%
% C0�O�Ռv�Z
if exist( "TransClineCPosX" ) == 0 % C0�O�Ռ`��f�[�^�����łɃ��[�N�X�y�[�X�ɂ���ꍇ�͎��ԒZ�k�̂���C0�O�Ռv�Z���Ȃ�
    if swC0Stt
        c0ValidFlg = boolean(laneConfidence >= 0.1) .* boolean(laneQuality == 3) .* boolean(laneType ~= 0) .* boolean(laneType ~= 3) .* boolean(laneType ~= 6) .* boolean(laneType ~= 7) .* boolean(laneType ~= 8) .* boolean(laneType ~= 9);
    else
        c0ValidFlg = 0;
    end
    [ TransClineCPosX, TransClineCPosY, TransClineLPosX, TransClineLPosY, TransClineRPosX, TransClineRPosY, TransClineLStt, TransClineRStt, TransClineCStt ] = makeC0Trace( EgoMovX, EgoMovY, EgoRot, lmCamY, C0LngSmpl, swC0Stt, c0ValidFlg );
end

if swIgnTgtDfY == 0
% if exist( "tgtDiffy" ) == 0 % ���H�덷�ʃf�[�^�����łɃ��[�N�X�y�[�X�ɂ���ꍇ�͎��ԒZ�k�̂��ߌv�Z���Ȃ�
    % ������
    tgtDiff = zeros(samples,1);
    tgtDiffy = zeros(samples,1);
    if swComp
        for dc = 1:compDataNum
            tgtDiffyOrg{dc} = zeros(samples,1);
        end
    end
    tgtExcludedStt = zeros(samples,1);

    ipSum = 0;
    ipSttSum = 0;

    % LC�O��̑��H�덷�𖳌��l�ɂ���Idx���Z�o����
    iii = 1;
    inValidIdx = zeros(size(samples));
    if swComp
        for dc = 1:compDataNum
            inValidIdxOrg{dc} = zeros(size(samples));
        end
    end
    if swLcAccInvalid == 1
        lc_flg = xor(S_lmslLeftLcFlg.signals.values, S_lmslRightLcFlg.signals.values);
        bfCntL = 1; bfCntR = 1; onFlg = 0;
        for i=1:samples
            % Ctrl�Ԑ���LC�𔻒�
            if i > lc_invalid_sample
                b = i - lc_invalid_sample;
            else
                b = 1;
            end
            if i + lc_invalid_sample <= samples
                e = i + lc_invalid_sample;
            else
                e = samples;
            end
            if lc_flg(i)
                inValidIdx(iii:iii+e-b) = b:e;
                iii = iii+e-b + 1;
                continue;
            end
            % Ctrl�Ԑ���existFlg=0�̂Ƃ���inValidIdx�ɒǉ�����
            if cOutFlg(i,2) == 0
                inValidIdx(iii) = i;
                iii = iii + 1;
                continue;
            end
                
            % C0�O�Ղ�LC�𔻒�
            if i > 1
                if TransClineLStt(i,201)
                    if TransClineLStt(i-bfCntL,201)
                        C0DiffL = abs(TransClineLPosY(i,201) - TransClineLPosY(i-bfCntL,201));
                        if C0DiffL > 3
                            inValidIdx(iii:iii+e-b) = b:e;
                            iii = iii+e-b + 1;
                            onFlg = 1;
                        end
                    end
                    bfCntL = 1;
                    if onFlg
                        onFlg = 0;
                        continue;
                    end
                else
                    bfCntL = bfCntL + 1;
                end
                if TransClineRStt(i,201)
                    if TransClineRStt(i-bfCntR,201)
                        C0DiffR = abs(TransClineRPosY(i,201) - TransClineRPosY(i-bfCntR,201));
                        if C0DiffR > 3
                            inValidIdx(iii:iii+e-b) = b:e;
                            iii = iii+e-b + 1;
                            onFlg = 1;
                        end
                    end
                    bfCntR = 1;
                    if onFlg
                        onFlg = 0;
                        continue;
                    end
                else
                    bfCntR = bfCntR + 1;
                end
            end
        end
    end
    if swComp && swLcAccInvalidComp == 1
        for dc = 1:compDataNum
            iii = 1;
            lc_flg = xor(leftLcFlgOrg{dc}, rightLcFlgOrg{dc});
            for i=1:samples
                if lc_flg(i)
                    if i > lc_invalid_sample
                        b = i - lc_invalid_sample;
                    else
                        b = 1;
                    end
                    if i + lc_invalid_sample <= samples
                        e = i + lc_invalid_sample;
                    else
                        e = samples;
                    end
                    inValidIdxOrg{dc}(iii:iii+e-b) = b:e;
                    iii = iii+e-b + 1;
                end
            end
        end
    end

    if swIgnTgtDfY == 0
        % �ڕW�Ƃ���ʒu�ł�C0�O�Ղ�LM���H�ʒu�����Z�o
        c0IdxFl = ones(size(time)); c0IdxCe = ones(size(time));
        for i=1:samples
            if ( any(i == inValidIdx) && (swComp == 0) )
                tgtDiffy(i) = NaN;
                continue;
            else
                if swComp
                    for dc = 1:compDataNum
                        compInvalidFlgPart(dc) = any(i == inValidIdxOrg{dc});
                    end
                    compInvalidFlg = any(compInvalidFlgPart);
                    if any(i == inValidIdx) && compInvalidFlg
                        tgtDiffy(i) = NaN;
                        tgtDiffyOrg{dc}(i) = NaN;
                        continue;
                    end
                end
                swTgtPos = 1;   % tgtPos���ԑ��ˑ��ł����1, �Œ�l�ł����0����͂��邱��
                tgtPos = egoSpd(i,1)*ts;    % C0�O�Ղ�LM���H�ʒu�������Z�o����ʒu�����߂�

                % C0�O�Ճ��T���v�����O
%                     [pC_rs(:,1), pC_rs(:,2), bwIdxC] = interPoC0(TransClineCPosX(i,:), TransClineCPosY(i,:), X');

                if swTgtPos || swWidth
                    ceilTgtPos = int16(ceil(tgtPos));
                    if ceilTgtPos <= 0
                        floorTgtPos = 0;
                        roundTgtPos = 0;
                        ceilTgtPos = 0;
                    else
                        floorTgtPos = int16(floor(tgtPos));
                        roundTgtPos = int16(round(tgtPos));
                    end
                else
                    roundTgtPos = int16(tgtPos);
                end

                %%%%%%%%%%%%% C0�O�Փ_���o %%%%%%%%%%%%%
                if swTgtPos
                    flFlg = 0; ceFlg = 0; tgtC0Flg = 0;
                    for c0Idx = 201:length(TransClineCPosX(i,:))
                        if ( TransClineCPosX(i,c0Idx) < tgtPos )
                            if ( swC0InVld && TransClineCStt(i,c0Idx) ) || ( swC0InVld==0 )
                                c0IdxFl(i) = c0Idx;
                                flFlg = 1;
                            end
                        end
                        if ( TransClineCPosX(i,c0Idx) >= tgtPos )
                            if ( swC0InVld && TransClineCStt(i,c0Idx) ) || ( swC0InVld==0 )
                                c0IdxCe(i) = c0Idx;
                                ceFlg = 1;
%                                     break;
                            end
                        end
                        if flFlg && ceFlg
                            tgtC0Flg = 1;
                            break;
                        end
                        if flFlg
                           distC0 = sqrt( ( TransClineCPosX(i,c0IdxFl(i)) - TransClineCPosX(i,c0Idx) )^2 + ( TransClineCPosY(i,c0IdxFl(i)) - TransClineCPosY(i,c0Idx) )^2 );
                           if (1/abs(curv(i,2))) < 200
                               distC0Tld = distC0TldSmCv;
                           end
                           if distC0 > distC0Tld
                               break;
                           end
                        end
                    end
                    
                    if tgtC0Flg
                        tgtC0XC(i) = tgtPos;
                        tgtC0YC(i) = TransClineCPosY(i,c0IdxFl(i)) + ( TransClineCPosY(i,c0IdxCe(i)) - TransClineCPosY(i,c0IdxFl(i)) ) * ( tgtPos - TransClineCPosX(i,c0IdxFl(i)) ) / ( TransClineCPosX(i,c0IdxCe(i)) - TransClineCPosX(i,c0IdxFl(i)) );
                    else
                        tgtC0XC(i) = NaN;
                        tgtC0YC(i) = NaN;
                    end
                else            
                    tgtC0XC(i) = pC_rs(tgtPos+1,1);
                    tgtC0YC(i) = pC_rs(tgtPos+1,2);
                end
                %%%%%%%%%%%%% C0�O�Փ_���o %%%%%%%%%%%%%

                %%%%%%%%%%%%% LM���H�ʒu���o %%%%%%%%%%%%%
                % LM���H�ʒu���o        
                if swTgtPos
                    tgtCtrlX(i) = tgtPos;
                    tgtCtrlY(i) = lmCtrlY(i,151+451+floorTgtPos) + ( lmCtrlY(i,151+451+ceilTgtPos) - lmCtrlY(i,151+451+floorTgtPos) ) * ( tgtPos - lmCtrlX(i,151+451+floorTgtPos) ) / ( lmCtrlX(i,151+451+ceilTgtPos) - lmCtrlX(i,151+451+floorTgtPos) );
                else
                    tgtCtrlX(i) = lmCtrlX(i,151+451+tgtPos);
                    tgtCtrlY(i) = lmCtrlY(i,151+451+tgtPos);
                end
                tgtCtrlX(i) = tgtPos;
                tgtCtrlY(i) = lmCtrlY(i,151+451+floorTgtPos) + ( lmCtrlY(i,151+451+ceilTgtPos) - lmCtrlY(i,151+451+floorTgtPos) ) * ( tgtPos - lmCtrlX(i,151+451+floorTgtPos) ) / ( lmCtrlX(i,151+451+ceilTgtPos) - lmCtrlX(i,151+451+floorTgtPos) );
                %%%%%%%%%%%%% LM���H�ʒu���o %%%%%%%%%%%%%

                %%%%%%%%%%%%% LM���H�ʒu���o(�ǉ��@�\�p) %%%%%%%%%%%%%
                if swTgtPos
                    if swAntLoc
                        tgtCtrlXMpu(i) = tgtPos;   tgtCtrlYMpu(i) = lmCtrlYBsMpuLoc(i,151+floorTgtPos) + ( lmCtrlYBsMpuLoc(i,151+ceilTgtPos) - lmCtrlYBsMpuLoc(i,151+floorTgtPos) ) * ( tgtPos - lmCtrlXBsMpuLoc(i,151+floorTgtPos) ) / ( lmCtrlXBsMpuLoc(i,151+ceilTgtPos) - lmCtrlXBsMpuLoc(i,151+floorTgtPos) );
                        tgtCtrlXYrm(i) = tgtPos;   tgtCtrlYYrm(i) = lmCtrlYBsYrmLoc(i,151+floorTgtPos) + ( lmCtrlYBsYrmLoc(i,151+ceilTgtPos) - lmCtrlYBsYrmLoc(i,151+floorTgtPos) ) * ( tgtPos - lmCtrlXBsYrmLoc(i,151+floorTgtPos) ) / ( lmCtrlXBsYrmLoc(i,151+ceilTgtPos) - lmCtrlXBsYrmLoc(i,151+floorTgtPos) );
                        tgtCtrlXDr(i) = tgtPos;   tgtCtrlYDr(i) = lmCtrlYBsDrLoc(i,151+floorTgtPos) + ( lmCtrlYBsDrLoc(i,151+ceilTgtPos) - lmCtrlYBsDrLoc(i,151+floorTgtPos) ) * ( tgtPos - lmCtrlXBsDrLoc(i,151+floorTgtPos) ) / ( lmCtrlXBsDrLoc(i,151+ceilTgtPos) - lmCtrlXBsDrLoc(i,151+floorTgtPos) );
                    end
                else
                    if swAntLoc
                        tgtCtrlXMpu(i) = lmCtrlXBsMpuLoc(i,151+tgtPos4Ctrl(tgt));   tgtCtrlYMpu(i) = lmCtrlYBsMpuLoc(i,151+tgtPos4Ctrl(tgt));
                        tgtCtrlXYrm(i) = lmCtrlXBsYrmLoc(i,151+tgtPos4Ctrl(tgt));   tgtCtrlYYrm(i) = lmCtrlYBsYrmLoc(i,151+tgtPos4Ctrl(tgt));
                        tgtCtrlXDr(i) = lmCtrlXBsDrLoc(i,151+tgtPos4Ctrl(tgt));   tgtCtrlYDr(i) = lmCtrlYBsDrLoc(i,151+tgtPos4Ctrl(tgt));
                    end
                end
                %%%%%%%%%%%%% LM���H�ʒu���o(�ǉ��@�\�p) %%%%%%%%%%%%%

                %%%%%%%%%%%%% LM���H�ʒu���o(��r���f�[�^�p) %%%%%%%%%%%%%
                if swComp
                    for dc = 1:compDataNum
                        if swTgtPos
                            tgtCtrlXOrg{dc}(i) = tgtPos;
                            tgtCtrlYOrg{dc}(i) = lmCtrlYOrg{dc}(i,151+451+floorTgtPos) + ( lmCtrlYOrg{dc}(i,151+451+ceilTgtPos) - lmCtrlYOrg{dc}(i,151+451+floorTgtPos) ) * ( tgtPos - lmCtrlXOrg{dc}(i,151+451+floorTgtPos) ) / ( lmCtrlXOrg{dc}(i,151+451+ceilTgtPos) - lmCtrlXOrg{dc}(i,151+451+floorTgtPos) );
                        else
                            tgtCtrlXOrg{dc}(i) = lmCtrlXOrg{dc}(i,151+451+tgtPos);   tgtCtrlYOrg{dc}(i) = lmCtrlYOrg{dc}(i,151+451+tgtPos);
                        end
                    end
                end
                %%%%%%%%%%%%% LM���H�ʒu���o(��r���f�[�^�p) %%%%%%%%%%%%%


                %%%%%%%%%%%%% �ڕW�Ƃ���ʒu�ł�C0�O�ՂƂ�y���� %%%%%%%%%%%%%
                tgtDiffy(i) = tgtCtrlY(i) - tgtC0YC(i);

                %%%%%%%%%%%%% �ڕW�Ƃ���ʒu�ł�C0�O�ՂƂ�y����(�ǉ��@�\�p) %%%%%%%%%%%%%
                if swAntLoc
                    tgtDiffyMpu(i) = tgtCtrlYMpu(i) - tgtC0YC(i);
                    tgtDiffyYrm(i) = tgtCtrlYYrm(i) - tgtC0YC(i);
                    tgtDiffyDr(i) = tgtCtrlYDr(i) - tgtC0YC(i);
                end
                %%%%%%%%%%%%% �ڕW�Ƃ���ʒu�ł�C0�O�ՂƂ�y����(�ǉ��@�\�p) %%%%%%%%%%%%%

                %%%%%%%%%%%%% �ڕW�Ƃ���ʒu�ł�C0�O�ՂƂ�y����(��r���f�[�^�p) %%%%%%%%%%%%%
                if swComp
                    for dc = 1:compDataNum
                           tgtDiffyOrg{dc}(i) = tgtCtrlYOrg{dc}(i) - tgtC0YC(i);
                    end
                end
                %%%%%%%%%%%%% �ڕW�Ƃ���ʒu�ł�C0�O�ՂƂ�y����(��r���f�[�^�p) %%%%%%%%%%%%%
            end
        end
    end
end

    


function [ReturndataX, ReturndataY, CenterIdx] = interPoC0(tClineX, tClineY, SourceL)
%���͂����l��Idx�����@�����琳
%20191224�쐬�f�[�^�͈͂��S�ĕ��̍ۂɈ�ԑ傫�Ȓl���ςȒl�ƂȂ�o�O���C��

% �O����
c0TraceX = tClineX;
c0TraceY = tClineY;
if isempty(c0TraceX) || isempty(c0TraceY) || (length(c0TraceX) < 3) || (length(c0TraceY) < 3) || (sum(~isnan(c0TraceX)) <= 1)
    ReturndataX = zeros(101,1);
    ReturndataY = zeros(101,1);
    CenterIdx = 0;
    return;
end
tf1L = isfinite(c0TraceX(1,:));  

%�f�[�^�^���킹
SourceX = squeeze(c0TraceX(tf1L));
SourceY = squeeze(c0TraceY(tf1L));
SourceL = squeeze(SourceL);
PointX = zeros(length(SourceL),1);
PointY = zeros(length(SourceL),1);

%�@X,Y�̃f�[�^���Ⴂ�Ή�
if length(SourceX) < (SourceY)
    LengthData = length(SourceX);
else
    LengthData = length(SourceY);
end

RangeDetected = 0;

%%����f�[�^�n�_�ԍ�����
for cnt1 = 1 : length(SourceL)
    if SourceL(cnt1) == 0
        ReturnCenterIdx = cnt1;
        rangeDetected = 1; % Range��0�_������
        break;
    elseif SourceL(cnt1) > 0
        ReturnCenterIdx = cnt1;
        rangeDetected = 2; % Range���S�Đ�
        break;
    else
        ReturnCenterIdx = length(SourceL);
        rangeDetected = 3; % Range���S�ĕ�
    end
end
% ReturnCenterIdxTmp = ReturnCenterIdx;
% rangeDetectedTmp = rangeDetected;

%%�����ʒu�v�Z
SeppenId = 1;
detected = 0;
%0�_���ׂ��_���������T��
for cnt1 = 2:LengthData
    if SourceX(cnt1 - 1) < 0 && 0 <= SourceX(cnt1)
        SeppenId =cnt1;
        detected =1;
    end
end
% tmp1 = SeppenId;
% tmp2 = detected;

%�ׂ��Ȃ��p�^�[�� -> X>0�Ő�����0���牓������ꍇ�͏������֌v�Z/X<0�Ő�����0�֋߂Â��ꍇ�͋t�����ց@����ȊO�͍l�����Ȃ�
if detected == 0
    if (SourceX(1) < 0) && hypot(SourceX(1),SourceY(1)) > hypot(SourceX(end),SourceY(end))
        SeppenId = LengthData;
    end
    
end
% tmp1 = SeppenId;
% tmp2 = detected;

%%�ؕЌv�Z
if SeppenId == 1
    SeppenX = 0;
    SeppenY = SourceY(1) - (SourceY(2) - SourceY(1)) / (SourceX(2) - SourceX(1)) * SourceX(1);
elseif  SeppenId == LengthData
    SeppenX = 0;
    SeppenY = SourceY(SeppenId) - (SourceY(SeppenId) - SourceY(SeppenId - 1)) / (SourceX(SeppenId) - SourceX(SeppenId - 1)) * SourceX(SeppenId);
else
    SeppenX = 0;
    SeppenY = SourceY(SeppenId) - (SourceY(SeppenId) - SourceY(SeppenId - 1)) / (SourceX(SeppenId) - SourceX(SeppenId - 1)) * SourceX(SeppenId);
end
% tmp1 = SeppenX;
% tmp2 = SeppenY;

%�w��Ԋu�̃p�^�[��������

cnt2 = 1;
if rangeDetected == 1
PointX(ReturnCenterIdx,1) = SeppenX;
PointY(ReturnCenterIdx,1) = SeppenY;
elseif rangeDetected == 3
ReturnCenterIdx = ReturnCenterIdx + 1;
end
% tmp1 = PointY;
% tmp2 = ReturnCenterIdx;
% tmp1 = PointX;
% tmp2 = PointY;

%�������쐬
tempX = SeppenX;
tempY = SeppenY;
tempL = 0;
cntId = SeppenId;

for cnt2 = ReturnCenterIdx : length(SourceL)
    detectedFlg = 0;
    
    while(cntId <= LengthData && cntId > 0)
        if hypot(tempX - SourceX(cntId), tempY - SourceY(cntId)) >= abs(SourceL(cnt2) - tempL) && hypot(tempX - SourceX(cntId), tempY - SourceY(cntId)) ~= 0
            PointX(cnt2,1) = cos(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempX;
            PointY(cnt2,1) = sin(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempY;
            detectedFlg = 1;
            break;
        else
            cntId = cntId + 1;
        end
    end
    if detectedFlg
        tempX = PointX(cnt2,1);
        tempY = PointY(cnt2,1);
    else
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end
    
    if detected ~=1 && cntId == SeppenId
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end
    
    
    tempL = SourceL(cnt2);
end
tmp1 = PointX;
tmp2 = PointY;

%�t�����쐬
if detected
cntId = SeppenId - 1;
else
cntId = SeppenId;
end    
tempX = SeppenX;
tempY = SeppenY;
tempL = 0;

for cnt2 = ReturnCenterIdx - 1 : -1 : 1
    detectedFlg = 0;
    
    while(cntId <= LengthData && cntId > 0)
        if hypot(tempX - SourceX(cntId), tempY - SourceY(cntId)) >= abs(SourceL(cnt2) - tempL) && hypot(tempX - SourceX(cntId), tempY - SourceY(cntId)) ~= 0
            PointX(cnt2,1) = cos(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempX;
            PointY(cnt2,1) = sin(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempY;
            detectedFlg = 1;
            break;
        else
            cntId = cntId -1;
        end
    end
    if detectedFlg
        tempX = PointX(cnt2,1);
        tempY = PointY(cnt2,1);
    else
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end
    
    if detected ~=1 && cntId == SeppenId
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end
    
    tempL = SourceL(cnt2);
    
end


ReturndataX = PointX;
ReturndataY = PointY;
CenterIdx = SeppenId;

end
