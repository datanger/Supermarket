clc,clear,close all;
dataFolder = uigetdir('','please select data folder');
currentDir = pwd;
onlyMF4DataName = dir(strcat(dataFolder,'\*\*_ACore_XCP_remap.mat'));
parapara = 1;
exportExcel = 1;
for k = 1:length(onlyMF4DataName)
    vars = who;
    simResName = strrep(onlyMF4DataName(k).name,'.mat','');
    folderName = split(onlyMF4DataName(k).folder,'\');
    dataDate = char(folderName(end));
    dataDate = string(dataDate(1:8));
    folderName = string(folderName(end));
    dirName = strrep(onlyMF4DataName(k).folder,folderName,'');
    PlusName = string(regexp(folderName,'_Plus\d+','match'));
    onlyMF4DataNamePath = fullfile(onlyMF4DataName(k).folder,onlyMF4DataName(k).name);
    load(onlyMF4DataNamePath);
    signalsTimeSync;
    ViewerMF4_FromMF4ConvertedDataFrazki;
    if parapara
        CreateParapra;
    end
    if exportExcel
        ExportToExcel;
    end
    cmd = 'clearvars -except ';
    cmd = [cmd, strjoin(vars, ' ')];
    eval(cmd);
end
