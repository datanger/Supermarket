%�e�T�u�v���b�g��`
plotGyo = 9; plotRetsu = 12;

% XY�v���b�g�p
ax = [];
webCamPix = 8; % webCam�摜or�ǉ��f�[�^������ꏊ���ĉE�[���牽�ڂ̏ꏊ����ɂ��邩
if swXcorr == 0
    bottomGyo = 0; % BEV�̉��ɐV�Kwindow�����s������邩��ݒ肷��
else
    bottomGyo = 2; % BEV�̉��ɐV�Kwindow�����s������邩��ݒ肷��
end
bevGyo = plotGyo - bottomGyo;
setdiffEle = zeros(webCamPix,length(plotRetsu:plotRetsu:bevGyo*bevGyo));
endIdxPre = 0;
for i = 1:webCamPix
    retsuNo = plotRetsu - i + 1;
    endIdx = length(retsuNo:plotRetsu:retsuNo+plotRetsu*(bevGyo-1));
    setdiffEle(i,endIdxPre+1:endIdxPre+endIdx) = retsuNo:plotRetsu:retsuNo+plotRetsu*(bevGyo-1);
    endIdxPre = endIdx;
end
ax3 = subplot(plotGyo,plotRetsu,setdiff(1:bevGyo*plotRetsu,sort(setdiffEle)));
hold on;grid on;
ax3.XDir ='reverse';
ax = horzcat( ax, ax3 );

endIdxPre = 0;
if swXcorr == 0
    webCamRetsu = 4;
    webCamGyo = 4;
else
    webCamRetsu = 2;
    webCamGyo = 3;
end
webEle = zeros(1,webCamGyo*webCamRetsu);
for i = 1:webCamRetsu
    webEle(endIdxPre+1:endIdxPre+webCamGyo) = [plotRetsu-webCamPix+i : plotRetsu : webCamRetsu-webCamPix+plotRetsu*webCamGyo];
    endIdxPre = endIdxPre+webCamGyo;
end
if swXcorr == 0
    if swWebCam
        ax4 = subplot(plotGyo,plotRetsu,webEle);
        ax4.XDir ='reverse';
        hold on;grid on;
    else
        exCnt = 0;
        for exIdx = 1:4
            if mod(exIdx,2) == 1
                exCnt = exCnt + 1;
                eval( sprintf( "axTimeEx1( %d ) = subplot( %d, %d, [ %d %d %d %d] );", exCnt, plotGyo, plotRetsu, plotRetsu * exIdx - webCamPix + 1, plotRetsu * exIdx - webCamPix + 2, plotRetsu * (exIdx + 1) - webCamPix + 1, plotRetsu * (exIdx + 1) - webCamPix + 2 ) );
                hold on; grid on;
            end
            eval( sprintf( "axTimeEx2( %d ) = subplot( %d, %d, [ %d %d ] );", exIdx, plotGyo, plotRetsu, plotRetsu * exIdx - webCamPix + 3, plotRetsu * exIdx - webCamPix + 4 ) );
            hold on; grid on;
        end
    end
    endIdxPreInit = webEle(end)-webCamRetsu+plotRetsu;
    endIdxPre = 0;
    bevEle = zeros(1,(plotGyo-webCamGyo)*webCamRetsu);
    for i = 1:webCamRetsu
        bevEle(endIdxPre+1:endIdxPre+plotGyo-webCamGyo) = [endIdxPreInit+i : plotRetsu : endIdxPreInit+webCamRetsu+plotRetsu*(plotGyo-webCamGyo-1)];
        endIdxPre = endIdxPre+plotGyo-webCamGyo;
    end
    ax5 = subplot(plotGyo,plotRetsu,bevEle);
    hold on;grid on;
    ax5.XDir ='reverse';
    ax = horzcat( ax, ax5 );
%         linkaxes( ax );
else
    ax4 = subplot(plotGyo,plotRetsu,webEle);
    ax4.XDir ='reverse';
    hold on;grid on;
    ax5 = subplot(plotGyo,plotRetsu,webEle+2);
    ax5.XDir ='reverse';
    hold on;grid on;
    
    endIdxPre = 0;
    xcorrGyo = 3;
    xcorrRetsu = 4;
    xcorrEle = zeros(1,xcorrGyo*xcorrRetsu);
    for i = 1:xcorrRetsu
        xcorrEle(endIdxPre+1:endIdxPre+xcorrGyo) = [webEle(webCamGyo)+plotRetsu+i-1 : plotRetsu : webEle(webCamGyo)+plotRetsu-1+xcorrRetsu-webCamPix+plotRetsu*xcorrGyo];
        endIdxPre = endIdxPre+webCamGyo;
    end
    ax6 = subplot(plotGyo,plotRetsu,xcorrEle);
    hold on;grid on;
    endIdxPre = 0;
    xcorrEle2 = zeros(1,xcorrGyo*xcorrRetsu);
    for i = 1:xcorrRetsu
        xcorrEle2(endIdxPre+1:endIdxPre+xcorrGyo) = [xcorrEle(xcorrGyo)+plotRetsu+i-1 : plotRetsu : xcorrEle(xcorrGyo)+plotRetsu-1+xcorrRetsu-webCamPix+plotRetsu*xcorrGyo];
        endIdxPre = endIdxPre+webCamGyo;
    end
    ax7 = subplot(plotGyo,plotRetsu,xcorrEle2);
    hold on;grid on;
    ax8 = subplot(plotGyo,plotRetsu,[bevGyo*plotRetsu+1:bevGyo*plotRetsu+4 (bevGyo+1)*plotRetsu+1:(bevGyo+1)*plotRetsu+4]);
    hold on;grid on;
end

% ���n��v���b�g�p
clear axTime;
for i = 1:plotGyo
    eval( sprintf( "axTime( %d ) = subplot( %d, %d, [ %d %d ] );", i, plotGyo, plotRetsu, plotRetsu * i - 3, plotRetsu * i - 2 ) );
    hold on; grid on;
    if i >= (plotGyo-3) % 2�i���g���ăv���b�g������͓̂��ʏ���
        if i == (plotGyo-3)
            eval( sprintf( "axTime( %d ) = subplot( %d, %d, [ %d %d %d %d ] );", i+plotGyo, plotGyo, plotRetsu, plotRetsu * i - 1, plotRetsu * i, plotRetsu * i - 1 + plotRetsu, plotRetsu * i + plotRetsu ) );
        elseif i == (plotGyo-1)
            eval( sprintf( "axTime( %d ) = subplot( %d, %d, [ %d %d %d %d ] );", i+plotGyo-1, plotGyo, plotRetsu, plotRetsu * i - 1, plotRetsu * i, plotRetsu * i - 1 + plotRetsu, plotRetsu * i + plotRetsu ) );
        end
    else
        eval( sprintf( "axTime( %d ) = subplot( %d, %d, [ %d %d ] );", i+plotGyo, plotGyo, plotRetsu, plotRetsu * i - 1, plotRetsu * i ) );
    end
    hold on; grid on;
end

