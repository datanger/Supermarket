clc,clear,close all;

run_all_parapara = 0;

dataFolder = uigetdir('','please select mat_data folder');
blf_dataFolder = uigetdir('','please select blf_data folder');
[mf4_info_filename, mf4_info_path] = uigetfile('*.mat', 'please select mf4_info.mat file');
mf4_file_list = fullfile(mf4_info_path,mf4_info_filename);
soft_ver = input('please input your software version: ',"s");

isblf_avi = dir(fullfile(dataFolder,'*\*.avi'));
if ~isempty(isblf_avi)
    max_videotime = 0;
    for i = 1:length(isblf_avi)
        aviPath = fullfile(isblf_avi(i).folder,isblf_avi(i).name);
        v = VideoReader(aviPath); 
        videotime = v.Duration; 
        if v.Duration > max_videotime
            max_videotime = v.Duration;
        end
    end

    VideoTimeInterval = round(max_videotime/100)*100;
end

currentDir = pwd;
onlyMF4DataName = dir(strcat(dataFolder,'\*\*_ACore_XCP_remap.mat'));
parapara = 1;
exportExcel = 1;
for k = 1:length(onlyMF4DataName)
    vars = who;
    simResName = strrep(onlyMF4DataName(k).name,'.mat','');
    folderName = split(onlyMF4DataName(k).folder,'\');
    dataDate = char(folderName(end));
    dataDate = string(dataDate(1:8));
    folderName = string(folderName(end));
    dirName = strrep(onlyMF4DataName(k).folder,folderName,'');
    PlusName = string(regexp(folderName,'_Plus\d+','match'));
    onlyMF4DataNamePath = fullfile(onlyMF4DataName(k).folder,onlyMF4DataName(k).name);
    load(onlyMF4DataNamePath);
    signalsTimeSync;
    ViewerMF4_FromMF4ConvertedDataFrazki;
    if exportExcel
        ExportToExcel;
    end
    if parapara
        CreateParapra;
    end
    cmd = 'clearvars -except dataDate run_all_parapara ';
    cmd = [cmd, strjoin(vars, ' ')];
    eval(cmd);
end

export_excel;
