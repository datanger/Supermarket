import os
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed

script_dir = os.path.dirname(os.path.realpath(__file__))
SOURCE_PATH = script_dir.replace('/', '\\') + "\\LogMF4"

EXE_PATH = os.path.join(os.path.dirname(__file__), "mf4conv_all.exe")
EXE_PATH = EXE_PATH.replace('/', '\\')

REMAP_PATH = os.path.join(os.path.dirname(__file__), "LogRemap")
REMAP_PATH = REMAP_PATH.replace('/', '\\')
os.makedirs(REMAP_PATH, exist_ok=True)


CONVERT_LOG_PATH = os.path.join(os.path.dirname(__file__), "ConvertLog")
CONVERT_LOG_PATH = CONVERT_LOG_PATH.replace('/', '\\')
os.makedirs(CONVERT_LOG_PATH, exist_ok=True)

os.makedirs(CONVERT_LOG_PATH, exist_ok=True)

file_list = []
for root, dirs, files in os.walk(SOURCE_PATH):
    for file in files:
        if "_XCP" in file:
            file_list.append(os.path.join(root, file))


def run_command(file_path):
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    log_file = os.path.join(CONVERT_LOG_PATH, f"{file_name}_convert.log")

    command = f"{EXE_PATH} {file_path} {REMAP_PATH} > {log_file}"

    try:
        subprocess.run(command, shell=True, check=True)
        print(f"转换完�?�：{file_path}")
    except subprocess.CalledProcessError as e:
        print(f"转换失败?��{file_path}?��错误?��{e}")


def main(file_list, max_threads=4):
    with ThreadPoolExecutor(max_workers=max_threads) as executor:
        futures = [executor.submit(run_command, file) for file in file_list]
        for future in as_completed(futures):
            future.result()


if __name__ == "__main__":
    main(file_list)