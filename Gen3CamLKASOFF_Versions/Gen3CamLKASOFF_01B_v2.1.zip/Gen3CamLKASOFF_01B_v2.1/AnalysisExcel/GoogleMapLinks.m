% try
    if sw_DataType == 1
        ACoreTime = MpuMessage3.elapsedTime.time;
    else
        ACoreTime = MpuMessage3.elapsedTime.time;
    end
    
%     for oi = 1:length(ACoreTime)
%         if abs(ACoreTime(oi)-point)<0.1
%             break;
%         end
%     end
    [~, oi] = min(abs(ACoreTime - point));
    if sw_DataType == 1
        longitude = MpuMessage3.htLongitude.signals.values;
        latitude = MpuMessage3.htLatitude.signals.values;
    else
        longitude = MpuMessage3.htLongitude.signals.values;
        latitude = MpuMessage3.htLatitude.signals.values;
    end

    GoogleMapLink = strcat("https://maps.google.com/maps?q=",num2str(latitude(oi),'%.20g')," ",num2str(longitude(oi),'%.20g'));
    displayLink = strcat("'",num2str(latitude(oi),'%.20g'),',',num2str(longitude(oi),'%.20g'));
% catch
% end