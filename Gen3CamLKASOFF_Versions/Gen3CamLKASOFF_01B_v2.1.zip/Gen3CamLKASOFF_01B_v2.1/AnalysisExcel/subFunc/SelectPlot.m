rectangle(ax,'Position',[-veclWidth/2 -veclLength/2 veclWidth veclLength],'FaceColor','y');
for i = 1:length(swDispCont)
    if swDispCont(i) == 2 || swDispCont(i) == 3 || swDispCont(i) == 5
        for ln = 0:15
            if mapLaneNum(l) > ln
                lnPntNum = 451;
                if ln == 0,      color = 'r'; marker = '.';
                elseif ln == 1,  color = 'b'; marker = '.';
                elseif ln == 2,  color = 'g'; marker = '.';
                elseif ln == 3,  color = 'm'; marker = '.';
                elseif ln == 4,  color = 'c'; marker = '.';
                elseif ln == 5,  color = '#EDB120'; marker = '.'; % �I�����W
                elseif ln == 6,  color = '#7E2F8E'; marker = '.'; % ��
                elseif ln == 7,  color = '#A2142F'; marker = '.'; % ��
                elseif ln == 8,  color = 'r'; marker = '+';
                elseif ln == 9,  color = 'b'; marker = '+';
                elseif ln == 10, color = 'g'; marker = '+';
                elseif ln == 11, color = 'm'; marker = '+';
                elseif ln == 12, color = 'c'; marker = '+';
                elseif ln == 13, color = '#EDB120'; marker = '+'; % �I�����W
                elseif ln == 14, color = '#7E2F8E'; marker = '+'; % ��
                elseif ln == 15, color = '#A2142F'; marker = '+'; % ��
                end
                % ��M���ԍ��킹�������Ȉʒu�x�[�X�n�}�����E���S��
                if swDispCont(i) == 2
                    if chkbox_MapLane.Value
                        plotMapLaneFunc(ax,l,ln,mapCtMpuX,mapCtMpuY,mapLanePntNum(l,:),color,marker,swLmmlMapMinimize);
                    end
                    if chkbox_MapLine.Value
                        plotMapLaneFunc(ax,l,ln,mapLtMpuX,mapLtMpuY,mapLtLinePntNum(l,:),color,marker,swLmmlMapMinimize);
                        plotMapLaneFunc(ax,l,ln,mapRtMpuX,mapRtMpuY,mapRtLinePntNum(l,:),color,marker,swLmmlMapMinimize);
                    end
                end
                % LM���Ȉʒu�x�[�X�n�}�����E���S��
                if swDispCont(i) == 3
                    if chkbox_MapLane.Value
                        plotMapLaneFunc(ax,l,ln,mapCtLmX,mapCtLmY,mapLanePntNum(l,:),color,marker,swLmmlMapMinimize);
                    end
                    if chkbox_MapLine.Value
                        plotMapLaneFunc(ax,l,ln,mapLtLmX,mapLtLmY,mapLtLinePntNum(l,:),color,marker,swLmmlMapMinimize);
                        plotMapLaneFunc(ax,l,ln,mapRtLmX,mapRtLmY,mapRtLinePntNum(l,:),color,marker,swLmmlMapMinimize);
                    end
                end
                % LM�o�͒n�}�����E���S��
                if swDispCont(i) == 5
                    if chkbox_MapLane.Value
                        plotLmOutMapLaneFunc(ax,l,ln,cMpXOut,cMpYOut,cMpStartIdxOut,cMpEndIdxOut,cMpCtClass(l,:),color,marker,0);
                        if swMapClass
                            plotLmOutMapLaneCtClassFunc(ax,l,ln,cMpXOut,cMpYOut,cMpStartIdxOut,cMpEndIdxOut,cMpCtClass(l,:),color);
                        end
                    end
                    if chkbox_MapLine.Value
                        if swMapClass
                            plotLmOutMapLineClassFunc(ax,l,ln,cMpXOut,cMpLtYOut,cMpStartIdxOut,cMpEndIdxOut,cMpLtClassOut(l,:),color);
                            plotLmOutMapLineClassFunc(ax,l,ln,cMpXOut,cMpRtYOut,cMpStartIdxOut,cMpEndIdxOut,cMpRtClassOut(l,:),color);
                        else
                            plotLmOutMapLaneFunc(ax,l,ln,cMpXOut,cMpLtYOut,cMpStartIdxOut,cMpEndIdxOut,cMpLtClassOut(l,:),color,marker,1);
                            plotLmOutMapLaneFunc(ax,l,ln,cMpXOut,cMpRtYOut,cMpStartIdxOut,cMpEndIdxOut,cMpRtClassOut(l,:),color,marker,1);
                        end
                    end
				    if chkbox_MapBdr.Value && swMapBnd
                        plotLmOutMapLaneFunc(ax,l,ln,cMpXOut,cBndLtYOut,cMpStartIdxOut,cMpEndIdxOut,ones(size(cMpXOut)),color,marker,1);
                        plotLmOutMapLaneFunc(ax,l,ln,cMpXOut,cBndRtYOut,cMpStartIdxOut,cMpEndIdxOut,ones(size(cMpXOut)),color,marker,1);
				    end
                end
            else
                break;
            end
        end
    end

    % Ctrl�Ԑ�    
    if swDispCont(i) == 4
        if chkbox_Ctrl.Value
            if cOutNum(l) ~= 0
                for ln = 0:cOutNum(l)-1
                    plotLmOutCtrlLaneFunc(ax,l,ln,lmCtrlX,lmCtrlY,cOutStartIdx,cOutEndIdx,1);
                    if swComp && (chkbox_Comp1.Value || chkbox_Comp2.Value)
                        for dc = 1:compDataNum
                            plotLmOutCtrlLaneFunc(ax,l,ln,ctrlXOrg{dc},ctrlYOrg{dc},cOutStartIdxOrg{dc},cOutEndIdxOrg{dc},dc+1);
                        end
                    end
                end
                ln = 1;
                if chkbox_MpuBs.Value
                    plotLmOutCtrlLaneFunc(ax,l,ln,lmCtrlXBsMpuLoc,lmCtrlYBsMpuLoc,cOutStartIdx(:,2),cOutEndIdx(:,2),101); hold on;
                end
                if chkbox_YrmBs.Value
                    plotLmOutCtrlLaneFunc(ax,l,ln,lmCtrlXBsYrmLoc,lmCtrlYBsYrmLoc,cOutStartIdx(:,2),cOutEndIdx(:,2),102); hold on; 
                end
                if chkbox_DrBs.Value
                    plotLmOutCtrlLaneFunc(ax,l,ln,lmCtrlXBsDrLoc,lmCtrlYBsDrLoc,cOutStartIdx(:,2),cOutEndIdx(:,2),103); hold on;
                end
            end
        end
    end

    % �J����C0�O��
    if (swDispCont(i) == 6) || (swDispCont(i) == 61)
        if chkbox_camC0Trace.Value
            plotCamC0TraceFunc(ax,l,TransClineLPosX,TransClineLPosY,TransClineRPosX,TransClineRPosY,TransClineCPosX,TransClineCPosY,swC0Stt,TransClineLStt, TransClineRStt, TransClineCStt, swDispCont(i));
            % ���H�덷�ʂ��Z�o����C0�O�Ղ�2�_��ΐF�Ńv���b�g����ꍇ�A���L2���̃R�����g�A�E�g���O��
%             plot(ax,TransClineCPosY(l,c0IdxFl(l)),TransClineCPosX(l,c0IdxFl(l)),'go','MarkerFaceColor','g'); hold on;
%             plot(ax,TransClineCPosY(l,c0IdxCe(l)),TransClineCPosX(l,c0IdxCe(l)),'go','MarkerFaceColor','g'); hold on;
        end
    end

    % LM�o�̓J��������    
    if swDispCont(i) == 7
        if chkbox_camLine.Value
            plotCamLineFunc(ax,l,lmCamX,lmCamY );
        end
    end

    % PLpath�`��  
    if swDispCont(i) == 8
        plot(ax,S_plPathY.signals.values(l,:),S_plPathX.signals.values(l,:),'ko');
    end
end

function plotCamC0TraceFunc(ax,smpl,c0LX,c0LY,c0RX,c0RY,c0CX,c0CY,swC0Stt,c0SttL,c0SttR,c0SttC,swDisp)
    if swC0Stt
        plot(ax,c0LY(smpl,boolean(c0SttL(smpl,:))),c0LX(smpl,boolean(c0SttL(smpl,:))),'ro','MarkerFaceColor','r'); hold on;
        plot(ax,c0LY(smpl,boolean(~c0SttL(smpl,:))),c0LX(smpl,boolean(~c0SttL(smpl,:))),'o','MarkerEdgeColor','#808080','MarkerFaceColor','#808080'); hold on;
        plot(ax,c0RY(smpl,boolean(c0SttR(smpl,:))),c0RX(smpl,boolean(c0SttR(smpl,:))),'ro','MarkerFaceColor','r'); hold on;
        plot(ax,c0RY(smpl,boolean(~c0SttR(smpl,:))),c0RX(smpl,boolean(~c0SttR(smpl,:))),'o','MarkerEdgeColor','#808080','MarkerFaceColor','#808080'); hold on;
        if swDisp == 6
            plot(ax,c0CY(smpl,boolean(c0SttC(smpl,:))),c0CX(smpl,boolean(c0SttC(smpl,:))),'ro','MarkerFaceColor','r'); hold on;
            plot(ax,c0CY(smpl,boolean(~c0SttC(smpl,:))),c0CX(smpl,boolean(~c0SttC(smpl,:))),'o','MarkerEdgeColor','#808080','MarkerFaceColor','#808080'); hold on;
        end
    else
        plot(ax,c0LY(smpl,:),c0LX(smpl,:),'ro','MarkerFaceColor','r'); hold on;
        plot(ax,c0RY(smpl,:),c0RX(smpl,:),'ro','MarkerFaceColor','r'); hold on;
        if swDisp == 6
            plot(ax,c0CY(smpl,:),c0CX(smpl,:),'ro','MarkerFaceColor','r'); hold on;
        end
    end
end

function plotCamLineFunc(ax,smpl,camX,camY)
    len = length( camY( smpl, : ) );
    leftCamX = camX( smpl, 1:len/4 );
    rightCamX = camX( smpl, len/4+1:len*2/4 );
    leftOutCamX = camX( smpl, len*2/4+1:len*3/4 );
    rightOutCamX = camX( smpl, len*3/4+1:len*4/4 );
    
    leftCamY = camY( smpl, 1:len/4 );
    rightCamY = camY( smpl, len/4+1:len*2/4 );
    leftOutCamY = camY( smpl, len*2/4+1:len*3/4 );
    rightOutCamY = camY( smpl, len*3/4+1:len*4/4 );
    
    leftIndex = leftCamY ~= 0 | leftCamX ~= 0;
    rightIndex = rightCamX ~= 0 \ rightCamY ~= 0;
    leftOutIndex = leftOutCamX ~= 0 | leftOutCamY ~= 0;
    rightOutIndex = rightOutCamY ~= 0 | rightOutCamX ~= 0;
    
    plot(ax,leftCamY( leftIndex ),leftCamX( leftIndex ),'k.' ); hold on;
    plot(ax,rightCamY( rightIndex ),rightCamX( rightIndex ),'k.' ); hold on;
    plot(ax,leftOutCamY( leftOutIndex ),leftOutCamX( leftOutIndex ),'.', "Color", [ 0.5 0.5 0.5 ] ); hold on;
    plot(ax,rightOutCamY( rightOutIndex ),rightOutCamX( rightOutIndex ),'.', "Color", [ 0.5 0.5 0.5 ] ); hold on;

end

function plotLmOutCtrlLaneFunc(ax,smpl,ln,lnX,lnY,startIdx,endIdx,sw)
    lnPntNum = 451;
    % ctrl�Ԑ��͍��Ԑ��E���Ԑ��E�E�Ԑ��̏��ɔz�񉻂���Ă��邽�߁Aln=0(1�Ԑ�)�̂Ƃ���452�`902�z����Q�Ƃ���
    if ln == 0
        ln = 1;
    elseif ln == 1
        ln = 0;
    end
    
    if sw == 1 && ln == 1
        color = 'bp';
    else
        if sw == 1
            color = 'bo';
        elseif sw == 2
            color = 'co';
        elseif sw == 3
            color = 'ko';
        elseif sw == 101
            color = 'g+';
        elseif sw == 102
            color = 'm+';
        elseif sw == 103
            color = 'k+';
        end
    end
    
    if startIdx(smpl,ln+1) ~= -1 && endIdx(smpl,ln+1) ~= -1
        plot(ax,lnY(smpl,lnPntNum*ln+startIdx(smpl,ln+1) + 1:lnPntNum*ln+endIdx(smpl,ln+1)+1),lnX(smpl,lnPntNum*ln+startIdx(smpl,ln+1) + 1:lnPntNum*ln+endIdx(smpl,ln+1)+1),color); hold on;
    end
end

function plotLmOutMapLaneFunc(ax,smpl,ln,lnX,lnY,startIdx,endIdx,class,color,marker,swLine)
% swLine�͓��̓f�[�^�������Ȃ��1, ���S���Ȃ��0������
    lnPntNum = 451;
    if startIdx(smpl,ln+1) ~= -1 && endIdx(smpl,ln+1)+1 ~= -1
        idxDir = lnPntNum*ln+startIdx(smpl,ln+1)+1:lnPntNum*ln+endIdx(smpl,ln+1)+1;
        y = lnY(smpl,idxDir);
        x = lnX(smpl,idxDir);
        if swLine
            validBit = (bitget(class(idxDir),1)==0); % �L���t���O
        else
            validBit = (bitget(class(idxDir),1)~=0); % �L���t���O
        end
        plot(ax,y(validBit),x(validBit),'Color',color,'Marker',marker,'LineStyle','none'); hold on;
    end
end

function plotLmOutMapLineClassFunc(ax,smpl,ln,lnX,lnY,startIdx,endIdx,class,color)
    % �n�}�����e�r�b�g��`
    % 0bit       ���Ȃ�
    % 1bit       ������
    % 2bit�@�@�@ ���j��
    % 3bit�@�@�@ ������
    % 4bit�@�@�@ �ׂ����t���O
    % 5bit�@�@�@ ���z���t���O
    lnPntNum = 451;
    if startIdx(smpl,ln+1) ~= -1 && endIdx(smpl,ln+1)+1 ~= -1
        idxDir = lnPntNum*ln+startIdx(smpl,ln+1)+1:lnPntNum*ln+endIdx(smpl,ln+1)+1;
        idxDirItrVl = [idxDir(1):20:idxDir(end)-20 idxDir(end)];
        y = lnY(smpl,idxDir);
        x = lnX(smpl,idxDir);
        classBitDs = (bitget(class(idxDir),3)~=0);                                  % �j��
        classBitSl = ((bitget(class(idxDir),2)+bitget(class(idxDir),4))~=0);        % ��&������
        classBitMtg = (bitget(class(idxDirItrVl),5)~=0);                            % �ׂ���
        classBitVtl = (bitget(class(idxDirItrVl),6)~=0);                            % ���z����
        plot(ax,y(classBitDs),x(classBitDs),'Color',color,'LineStyle','--'); hold on;
        plot(ax,y(classBitSl),x(classBitSl),'Color',color,'LineStyle','-'); hold on;
        plot(ax,y(classBitMtg),x(classBitMtg),'Color',color,'Marker','*','MarkerSize',10); hold on;
        plot(ax,y(classBitVtl),x(classBitVtl),'Color',color,'MarkerFaceColor',color,'Marker','square','MarkerSize',10); hold on;
    end
end

function plotLmOutMapLaneCtClassFunc(ax,smpl,ln,lnX,lnY,startIdx,endIdx,class,color)
    % �n�}�����e�r�b�g��`
    % 0bit       �L��/�����t���O(�O�}�_�͖���)
    % 1bit       ���s�Ԑ��t���O
    % 2bit       �ǉz�Ԑ��t���O
    % 3bit       �ޔ��Ԑ��t���O
    % 4bit       �o�X��p���s�H�t���O
    % 5bit       �䂸��Ԑ��t���O
    % 6bit       �o��Ԑ��t���O
    % 7-8bit     ��
    % 9bit�@     �����
    % 10bit      ������
    % 11bit      �Ԑ�������
    % 12bit      �Ԑ�������
    % 13bit      �E�Ԑ��ύX�\�t���O
    % 14bit      ���Ԑ��ύX�\�t���O
    % 15bit�@�@  �g���l����ԃt���O
    % 16bit      �������t���O
    % 17bit      Baidu���L����E�Ԑ�����
    % 18bit      Baidu���L�����E�Ԑ�����
    % 19bit      HOV���[���t���O
    % 20bit      �^�N�V�[���[���t���O
    % 21bit      �Ŋ֎ԗ���p�Ԑ��t���O(�\��:7.0�ɂėL��)
    lnPntNum = 451;
    if startIdx(smpl,ln+1) ~= -1 && endIdx(smpl,ln+1)+1 ~= -1
        idxDirTmp = lnPntNum*ln+startIdx(smpl,ln+1)+1:lnPntNum*ln+endIdx(smpl,ln+1)+1;
        idxDir = [idxDirTmp(1):20:idxDirTmp(end)-20 idxDirTmp(end)];
        y = lnY(smpl,idxDir);
        x = lnX(smpl,idxDir);
        tonnelBit = (bitget(class(idxDir),16)~=0);                          % �g���l�����
        HovBit = (bitget(class(idxDir),20)~=0);                             % HOV���[��
        sepBit = (bitget(class(idxDir),10)~=0);                             % ����
        merBit = (bitget(class(idxDir),11)~=0);                             % ����
        lnUpBit = (bitget(class(idxDir),12)~=0);                            % �Ԑ�����
        lnDownBit = (bitget(class(idxDir),13)~=0);                          % �Ԑ�����
        plot(ax,y(tonnelBit),x(tonnelBit),'Color',color,'Marker','_','MarkerSize',15); hold on;
        plot(ax,y(HovBit),x(HovBit),'Color',color,'MarkerFaceColor',color,'Marker','diamond','MarkerSize',8); hold on;
        plot(ax,y(sepBit),x(sepBit),'Color',color,'MarkerFaceColor',color,'Marker','^','MarkerSize',8); hold on;
        plot(ax,y(merBit),x(merBit),'Color',color,'MarkerFaceColor',color,'Marker','v','MarkerSize',8); hold on;
        plot(ax,y(lnUpBit),x(lnUpBit),'Color',color,'Marker','*','MarkerSize',15); hold on;
        plot(ax,y(lnDownBit),x(lnDownBit),'Color',color,'Marker','x','MarkerSize',15); hold on;
    end
end

function plotMapLaneFunc(ax,smpl,ln,X,Y,lnPntNum,color,marker,swMin)
    if swMin
        if ln == 0
            lnPntNumMax = 0;
        else
            lnPntNumMax = sum(lnPntNum(ln:-1:1));
        end
    else
        lnPntNumMax = 650*ln;
    end
    plot(ax,Y(smpl,lnPntNumMax+1:lnPntNumMax+lnPntNum(ln+1)),X(smpl,lnPntNumMax+1:lnPntNumMax+lnPntNum(ln+1)),'Color',color,'Marker',marker); hold on;
%     plot(ax,Y(smpl,:),X(smpl,:),'r.-'); hold on;
end
