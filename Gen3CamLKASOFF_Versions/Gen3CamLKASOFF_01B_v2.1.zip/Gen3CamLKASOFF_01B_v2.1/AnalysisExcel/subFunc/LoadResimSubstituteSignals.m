S_lmVecClineQuality = S_lmVecClineQuality_Cam;
S_lmVecClineType = S_lmcmVecCLineType;