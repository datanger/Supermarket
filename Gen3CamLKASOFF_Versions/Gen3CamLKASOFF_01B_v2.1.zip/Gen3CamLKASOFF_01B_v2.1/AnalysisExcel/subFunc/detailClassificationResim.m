switch PLDListCnt
    % 724
    case 1
        if bitget(S_lmmmMapDiffStt.signals.values(l),5)
            classification = "AngleDifference";
        elseif bitget(S_lmmmMapDiffStt.signals.values(l),6)
            classification = "AngleDifferenceInDecelerationLine";
        elseif bitget(S_lmmmMapDiffStt.signals.values(l),7)
            classification = "LowAccuracyOfMapPointSequence";
        elseif bitget(S_lmmmMapDiffStt.signals.values(l),8)
            classification = "LaneWidthDifference";
        elseif bitget(S_lmmmMapDiffStt.signals.values(l),17)
            classification = "CenterLineOfForwardMapIsBroken";
        elseif bitget(S_lmmmMapDiffStt.signals.values(l),12)
            classification = "OneSideMismatch[MatchSideLost]";
        elseif bitget(S_lmmmMapDiffStt.signals.values(l),13)
            classification = "OneSideMismatch[BothSideMismatch]";
        elseif bitget(S_lmmmMapDiffStt.signals.values(l),15)
            classification = "MapCentersLineDistortion";
        elseif bitget(S_lmmmMapDiffStt.signals.values(l),16)
            classification = "MapCenterlineOffset";
        elseif bitget(S_lmmmMapDiffStt.signals.values(l),11)
            classification = "IntersectionAtFront";
        else
            classification = "Other";
        end
    % 711
    case 3
        if bitget(S_lmmmCamDiffStt.signals.values(l),10)
            classification = "OneSideIsLost";
        elseif bitget(S_lmmmCamDiffStt.signals.values(l),8)
            classification = "CameraErrorDuringLaneChange";
        elseif bitget(S_lmmmCamDiffStt.signals.values(l),9)
            classification = "AngleErrorDuringLaneChange";
        else
            classification = "Other";
        end
    % 731
    case 5
        if bitget(S_lmmmCamDiffStt.signals.values(l),16)
            classification = "PrecedingCar’sTraj";
        elseif bitget(S_lmmmWDRStt.signals.values(l),4)
            classification = "SpdAndCurvLimit";
        elseif bitget(S_lmmmWDRStt.signals.values(l),5)
            classification = "ICPAngleDeviation";
        elseif bitget(S_lmmmWDRStt.signals.values(l),6)
            classification = "DRLimit";
        elseif bitget(S_lmmmWDRStt.signals.values(l),7)
            classification = "LowCameraProb";
        else
            classification = "Other";
        end
    % 732
    case 6
        if bitget(S_lmslErrDRStt.signals.values(l),8)
            classification = "EgoJump";
        elseif bitget(S_lmslErrDRStt.signals.values(l),7)
            classification = "ErrPos";
        elseif bitget(S_lmslErrDRStt.signals.values(l),3)
            classification = "DrOverLmt";
        else
            classification = "Other";
        end
end