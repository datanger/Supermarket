base1 = 'A':'Z';
single1 = cellstr(base1(:));
[ten, one] = ndgrid(base1, base1);
double1 = cellstr([one(:) ten(:)]);
ExcelTable = transpose(string([single1; double1]));
Excel = actxserver('Excel.Application');
set(Excel,'Visible',1);
set(Excel,'DisplayAlerts',0);
Workbooks = Excel.Workbooks;
OnlyMF4BExcelfolder = fullfile(currentDir,'issueList');
if ~exist(OnlyMF4BExcelfolder,'dir')
    mkdir(OnlyMF4BExcelfolder);
end
OnlyMF4LKASExcel = strcat(OnlyMF4BExcelfolder,'\',char(excelFileDate(1:8)),'_LKASOFF.xlsx');
if isfile(OnlyMF4LKASExcel)
    Workbook = Workbooks.Open(OnlyMF4LKASExcel);
    [~,~,subsetA] = xlsread(OnlyMF4LKASExcel,'Sheet1');
    subsetA = string(subsetA);
    [~,A_length] = size(subsetA);
    excelNum = A_length + 1;
else
    Workbook = Workbooks.Add;
    excelNum = 1;
end
Sheets = Excel.ActiveWorkBook.Sheets;
Sheet = get(Sheets,'Item',1);
Sheet.Activate;
A3i = 1;
if sliceData
    dataName = dataDate;
else
    dataName = folderName;
end
A1 = ExcelTable(1,excelNum) + "1";
Sheet.Range(A1).value = dataName;
A2 = ExcelTable(1,excelNum) + "2";
if sliceData
    Sheet.Range(A2).value = strcat(dataDate,'_ACore_XCP_remap.mat');
else
    Sheet.Range(A2).value = strcat(strrep(folderName,PlusName,''),'_ACore_XCP_remap.mat');
end
fprintf(1,'LogFileName = %s\n',dataName);
time = Group1Time;

if ~isempty(numIdx)
    for i = 1:length(numIdx)
        ltmp = numIdx(i);
        A3 = ExcelTable(1,excelNum) + string(2+A3i);
        A3i = A3i + 1;
        speed = string(sprintf('%.1f',Spd(ltmp)*20*3.6));
        if sliceData
            mf4_file_name = dataDate;
        else
            mf4_file_name = '';
        end
        if mf4_file_list ~= 0
            load(mf4_file_list);
            dateTime = string(regexprep(dataName, '_Plus\d+', ''));
            for n = 1:length(Blf_date_list)
                if Blf_date_list(n) == dateTime
                    num = ceil(LogTimeCam(ltmp)/VideoTimeInterval);
                    mf4_file_name = string(Blf_date_list(n+num-1));
                    break;
                end
            end
        elseif blf_dataFolder ~= 0
            all_acore = dir(fullfile(blf_dataFolder,'*ACore_XCP.mf4'));
            for ii = 1:length(all_acore)
                if contains(all_acore(ii).name,regexprep(dataName, '_Plus\d+', ''))
                    mf4_file_name = all_acore(ii+floor(LogTimeCam(ltmp)/VideoTimeInterval)).name;
                    mf4_result = regexp(mf4_file_name, '^\d+_\d+', 'match');
                    mf4_extracted = result{1};
                    mf4_file_name = string(mf4_extracted);
                    break
                end
            end
        end
        
        if isempty(mf4_file_name)
            error("mf4_info error: plus %s time %f", dataName, LogTimeCam(ltmp))
        end
        
%             A3value = strcat(speed,'#',numIdxType(i),'#',"time_", string(round(LogTimeCam(ltmp),2)),"[sec].png", '#', mf4_file_name);
        A3value = strcat(speed,'#',numIdxType(i),'#',sprintf("time_%0.2f", mod(LogTimeCam(ltmp),VideoTimeInterval)),"[sec].png", '#', mf4_file_name,'#',num2str(expresswayFlg(ltmp)));
        Sheet.Range(A3).value = A3value;
    end
end
Workbook.SaveAs(OnlyMF4LKASExcel);
Excel.Quit;
Excel.delete;