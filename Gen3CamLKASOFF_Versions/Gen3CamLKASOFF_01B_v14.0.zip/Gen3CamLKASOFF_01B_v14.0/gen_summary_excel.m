close all;
clear all; clc;
summaryStartTime = clock;

global ReverseMemoSum;
global currentRow;
global MemoSumlist;

isQuick = "0";
dataType = "1";
dataLocation = input('please input data location japan/LA/OH :',"s");
if dataType == "0"
    sw_DataType = 0; % 0:OldData_US
    resimMatType = '\MAPvcl_*.mat';
else
    sw_DataType = 1; % 1:JP/NewData_US
    resimMatType = '\2YCkai_*.mat';
end
writeMatType = input('Car No.:',"s");

selPath = uigetdir('',' Please select Folder (single day or multiple days)');

fileAttr = dir(selPath);
isMultiDay = false;

subFolders = fileAttr([fileAttr.isdir] & ~ismember({fileAttr.name}, {'.', '..'}));

if ~isempty(subFolders)
    for i = 1:length(subFolders)
        subFolderPath = fullfile(selPath, subFolders(i).name);
        subFolderContents = dir(subFolderPath);
        
        hasLKAS = any(contains({subFolderContents.name}, '�p�^�[��') & ...
                    contains({subFolderContents.name}, '.xlsx'));
        
        if hasLKAS
            isMultiDay = true;
            break;
        end
    end
    
    if ~isMultiDay
        hasLKASInCurrent = any(contains({fileAttr.name}, '�p�^�[��') & ...
                              contains({fileAttr.name}, '.xlsx'));
        isMultiDay = false; 
    end
else
    hasLKASInCurrent = any(contains({fileAttr.name}, '�p�^�[��') & ...
                          contains({fileAttr.name}, '.xlsx'));
    isMultiDay = false;
end

fprintf('Detected mode: %s\n', ifelse(isMultiDay, 'Multi-day folder', 'Single-day folder'));

TemplateFormPath = fullfile(pwd,'[LKASOFF]�J����LKASOFF���Summary.xlsx');
if exist(fullfile(pwd,'�J����LKASOFF���Summary.xlsx'),'file')
    error(strcat("Error Already exists ",fullfile(pwd,'�J����LKASOFF���Summary.xlsx'),' Please delete �J����LKASOFF���Summary.xlsx'));
else
    result = copyfile(TemplateFormPath,fullfile(pwd,'�J����LKASOFF���Summary.xlsx'));
end
TemplateFormPath = fullfile(pwd,'�J����LKASOFF���Summary.xlsx');

% ���n��Excel
Excel = actxserver('Excel.Application');
Workbooks = Excel.Workbook;
excelFile = Workbooks.Open(TemplateFormPath);
set(Excel,'Visible',1);
Sheets = Excel.ActiveWorkBook.Sheets;
Sheet1 = get(Sheets,'Item',1);
Sheet1.Activate;

ReverseMemoSum = [];
MemoSumlist = [];
currentRow = 7; 
chkFlgNameList = ["�p�^�[��A","�p�^�[��B","�p�^�[��C","�p�^�[��DEF","Other"];

if isMultiDay
    fprintf('Processing multiple day folders...\n');
    
    for folderIdx = 1:length(subFolders)
        currentFolder = fullfile(selPath, subFolders(folderIdx).name);
        fprintf('Processing folder: %s\n', currentFolder);
        
        processFolderData(currentFolder, chkFlgNameList);
    end
else
    fprintf('Processing single day folder...\n');
    processFolderData(selPath, chkFlgNameList);
end

if ~isempty(ReverseMemoSum)
    processExcelData(Sheet1, dataLocation, writeMatType);
else
    fprintf('No LKAS data found in the selected folder(s).\n');
end

excelFile.Save;
Excel.Quit;
Excel.delete;

summaryEndTime = clock;
elapsed_time = etime(summaryEndTime, summaryStartTime);
fprintf('total processing time�F%.1f[s]\n', elapsed_time);

function processFolderData(folderPath, chkFlgNameList)
    global ReverseMemoSum;
    
    filePathDir = dir(folderPath);
    
    LKAS = false;
    for i = 1:length(filePathDir)
        if contains(filePathDir(i).name, '�p�^�[��') && contains(filePathDir(i).name, '.xlsx')
            LKAS = true;
            break;
        end
    end
    
    if LKAS
        for i = 1:length(chkFlgNameList)
            excelFilePath = strcat(chkFlgNameList(i), '.xlsx');
            excelName = fullfile(folderPath, excelFilePath);
            
            if isfile(excelName)
                try
                    sheets = sheetnames(excelName);
                    for j = 1:length(sheets)
                        [~, ~, DataDetail] = xlsread(excelName, j, 'AB2:AC25');
                        if ~isempty(DataDetail)
                            AnalysisMemo = DataDetail(:,2);
                            if isempty(ReverseMemoSum)
                                ReverseMemoSum = {AnalysisMemo};
                            else
                                ReverseMemoSum = [ReverseMemoSum, {AnalysisMemo}];
                            end
                        end
                    end
                catch ME
                    fprintf('Error processing file %s: %s\n', excelName, ME.message);
                end
            end
        end
    end
end

function processExcelData(Sheet1, dataLocation, writeMatType)
    global ReverseMemoSum dataLocation writeMatType currentRow MemoSumlist;
    
    if iscell(ReverseMemoSum) && ~isempty(ReverseMemoSum)
        if iscell(ReverseMemoSum{1}) && size(ReverseMemoSum{1}, 1) >= 1
            firstColumn = ReverseMemoSum{1}(:,1);
        else
            firstColumn = {'����';'�f�[�^���';'�f�[�^��';'MF4�t�@�C����';'MF4����[s]';...
                          '�\�t�gVer';'�ԑ�[km/h]';'�V�C';'�C�x���g���P';'�C�x���g���2';...
                          '�C�x���g���3';'�H�ʏ��1';'�H�ʏ��2';'�ԗ��󋵂P';'�ԗ���2';...
                          '���W�󋵂P';'���W��2';'�������';'�����F';'�������';'GNSS�ʒu';...
                          '���ޔԍ�';'���l';'�f�[�^����'};
        end
        
        allData = firstColumn;
        for k = 1:length(ReverseMemoSum)
            if iscell(ReverseMemoSum{k}) && size(ReverseMemoSum{k}, 1) == size(firstColumn, 1)
                allData = [allData, ReverseMemoSum{k}(:,1)];
            end
        end
        
        for k = 1:size(allData, 2)
            MemoSum = reshape(allData(:,k),1,[]);
            MemoSumlist = [MemoSumlist; MemoSum];
        end
    end
    
    for i = 1:size(MemoSumlist, 1)
        for j = 1:size(MemoSumlist, 2)
            if iscell(MemoSumlist{i,j}) && any(cellfun(@(x) any(isnan(x)), MemoSumlist(i,j)))
                MemoSumlist{i,j} = "";
            elseif isnumeric(MemoSumlist{i,j}) && any(isnan(MemoSumlist{i,j}))
                MemoSumlist{i,j} = "";
            end
        end
    end
    
    MemoSumlist = string(MemoSumlist);
    
    % �ʓ�Excel
    [row2, ~] = size(MemoSumlist);
    for i = 2:row2
        rowStr = num2str(currentRow);
        LALinfo = split(MemoSumlist(i,20),',');
        Longitude = LALinfo(2,1);
        Latitude = LALinfo(1,1);
        GoogleMapLink = strcat("https://maps.google.com/maps?q=",num2str(Latitude,'%.20g')," ",num2str(Longitude,'%.20g'));
        displayLink = strcat(num2str(Latitude,'%.20g'),",",num2str(Longitude,'%.20g'));
        
        % Location
        Sheet1.Range(strcat('C',rowStr)).value = dataLocation;
        % ���ޔԍ�
        Sheet1.Range(strcat("D",rowStr)).value = MemoSumlist(i,21);
        formula = sprintf('=VLOOKUP(D%d,���X�g�ꗗ!$C$4:$D$26,2,FALSE)', currentRow);        
        Sheet1.Range(strcat("G",rowStr)).Formula = formula;
        % �\�t�gVer
        Sheet1.Range(strcat("J",rowStr)).value = MemoSumlist(i,5);
        % GNSS�ܓx�o�x(GoogleMap�����N)
        obj = Sheet1.Range(strcat('K',rowStr));
        obj.Hyperlinks.Add(obj, GoogleMapLink,"","",displayLink);
        % �������H����
        Sheet1.Range(strcat("L",rowStr)).value = strcat("'", MemoSumlist(i,24));
        % �f�[�^����
        Sheet1.Range(strcat("M",rowStr)).value = MemoSumlist(i,23);
        % �ԗ�No.
        Sheet1.Range(strcat("N",rowStr)).value = writeMatType;
        formula2 = sprintf('=LEFT(P%d,6)', currentRow);
        Sheet1.Range(strcat("O",rowStr)).Formula = formula2;
        % MF4�f�[�^��� �t�@�C����
        Sheet1.Range(strcat("P",rowStr)).value = MemoSumlist(i,3);
        % MF4�f�[�^��� ����[s]
        Sheet1.Range(strcat("Q",rowStr)).value = MemoSumlist(i,4);

        % �ԑ�[km/h]
        Sheet1.Range(strcat("R",rowStr)).value = MemoSumlist(i,6);
        % �V�C
        Sheet1.Range(strcat("S",rowStr)).value = MemoSumlist(i,7);
        % �C�x���g���P
        Sheet1.Range(strcat("T",rowStr)).value = MemoSumlist(i,8);
        % �C�x���g���2
        Sheet1.Range(strcat("U",rowStr)).value = MemoSumlist(i,9);
        % �C�x���g���3
        Sheet1.Range(strcat("V",rowStr)).value = MemoSumlist(i,10);
        % �H�ʏ��1
        Sheet1.Range(strcat("W",rowStr)).value = MemoSumlist(i,11);
        % �H�ʏ��2
        Sheet1.Range(strcat("X",rowStr)).value = MemoSumlist(i,12);
        % �ԗ��󋵂P
        Sheet1.Range(strcat("Y",rowStr)).value = MemoSumlist(i,13);
        % �ԗ���2
        Sheet1.Range(strcat("Z",rowStr)).value = MemoSumlist(i,14);
        % ���W�󋵂P
        Sheet1.Range(strcat("AA",rowStr)).value = MemoSumlist(i,15);
        % ���W��2
        Sheet1.Range(strcat("AB",rowStr)).value = MemoSumlist(i,16);
        % �������
        Sheet1.Range(strcat("AC",rowStr)).value = MemoSumlist(i,17);
        % �����F
        Sheet1.Range(strcat("AD",rowStr)).value = MemoSumlist(i,18);
        % �������
        Sheet1.Range(strcat("AE",rowStr)).value = MemoSumlist(i,19);
        % ���l
        Sheet1.Range(strcat("AG",rowStr)).value = MemoSumlist(i,22);

        currentRow = currentRow + 1;
    end
end

function result = ifelse(condition, trueValue, falseValue)
    if condition
        result = trueValue;
    else
        result = falseValue;
    end
end