samples = length(time);
if swCANape == 0
    Group1Time = S_Group1Time.signals.values;
end

% LM�����M���i�[
lmInhStt = S_lmInhStt.signals.values;
eMap = bitget( lmInhStt, 3 );
eYRM = bitget( lmInhStt, 5 );
% ���H�I�����
lmLnMode = S_lmLnMode.signals.values;
selectedCtrlStt = bitget( lmLnMode, 17 ) | bitget( lmLnMode, 18 ) | bitget( lmLnMode, 19 ) | bitget( lmLnMode, 20 );

% LM�o��Ctrl�Ԑ�
% �_��ʒuX, Y
lmCtrlX = S_lmVecCtrlLnPntX.signals.values;
lmCtrlY = S_lmVecCtrlLnPntY.signals.values;
% �Ԑ��L���t���O
cOutFlg = S_lmCtrlLnExistFlg.signals.values;
% �L���Ԑ������Z�o
for i = 1:length(cOutFlg)
    cOutNum(i,1) = sum(uint16(cOutFlg(i,:)));
end
% �n�_�C���f�b�N�X
cOutStartIdx = S_CtrlRangeStartIdx.signals.values;
% �I�_�C���f�b�N�X
cOutEndIdx = S_CtrlRangeEndIdx.signals.values;

% LM�o�͂̃J��������
lmCamX = S_lmVecClinePointPosX.signals.values;
lmCamY = S_lmVecClinePointPosY.signals.values;

egoSpd = S_egoSpd.signals.values;

% ���H�ȗ�
curv(:,1) = S_lmVecCtrlLnPntCurvature.signals.values(:,151);
curv(:,2) = S_lmVecCtrlLnPntCurvature.signals.values(:,151+451);
curv(:,3) = S_lmVecCtrlLnPntCurvature.signals.values(:,151+451*2);

if swSN == 0
    %LMMI���
    mpuDiffTime = S_lmMpuRvudiffTime.signals.values;
    
    % LMLD���
    mpuLnFlg = S_lmldVecLatFlg.signals.values(:,6);
    tolGateFlg = S_lmldVecLatFlg.signals.values(:,7);
    laneResetFlg = S_lmldVecLatFlg.signals.values(:,5);
    initLnStt = S_lmldVecLatPnt.signals.values(:,3); % 1:��ӂɓ��� 2:���ߑł�
    
    % ���[������֘A�M��
    mpuLnLoc = S_lmldVecLatPnt.signals.values(:,4);
    for i = 1:length(mpuLnLoc)
        if mpuLnLoc(i,:) == 255
            mpuLnLoc(i,:) = -1;
        end
    end
    
    laneLocType = S_lmldVecLatPnt.signals.values(:,5);
    laneLocNL = S_lmldVecLatPnt.signals.values(:,6);
    initLaneLoc = S_lmldVecLatPnt.signals.values(:,2);
    laneLoc = S_lmldVecLaneLocMinus1.signals.values(:,1);

    % ���Ԑ��n�}�Ԑ�
    lmMapEgoX = S_lmVecMapEgoLnPntX.signals.values;
    lmMapEgoY = S_lmVecMapEgoLnPntY.signals.values;
    
    lmPldStt = S_lmPldStt.signals.values;
    mhStt = S_mhStatus.signals.values;
    xcorrDx = S_lmmlXcorrDx.signals.values;
    xcorrDy = S_lmmlXcorrDy.signals.values;
    xcorrDyaw = S_lmmlXcorrDyaw.signals.values;
    lmCorrDx = S_lmmlYrmLocX.signals.values;
    lmCorrDy = S_lmmlYrmLocY.signals.values;
    lmCorrDyaw = S_lmmlYrmLocOri.signals.values;
    camC0 = S_MElaneDistanceY.signals.values;
    camEndX = S_lmVecClineEndX.signals.values;
    % �n�}�L���Ԑ���
    mapLaneNum = uint16(S_lmMapLnNum.signals.values);

    % �n�}�L���Ԑ��_��
    mapLanePntNum = S_lmmiLanePntNum.signals.values;
    mapLtLinePntNum = S_lmmiLtLinePntNum.signals.values;
    mapRtLinePntNum = S_lmmiRtLinePntNum.signals.values;

    % LM�o�͒n�}���
    % �n�}���S��
    cMpXOut = S_lmVecMapLnPntX.signals.values;
    cMpYOut = S_lmVecMapLnPntY.signals.values;

    % LM�o�͒n�}�����ʒu(�Ԑ����S����̋���)
    cMpDistLtOut = S_lmVecMapLnPntDistToLineL.signals.values;
    cMpDistRtOut = S_lmVecMapLnPntDistToLineR.signals.values;

    % LM�o�͒n�}�����ʒu(�A�o�E�g���ԍ��W�ʒu)
    cMpYOut(cMpYOut == 0) = NaN;
    cMpLtYOut = cMpYOut + cMpDistLtOut;
    cMpRtYOut = cMpYOut + cMpDistRtOut;

    % LM�o�͒n�}�n�_�E�I�_�C���f�b�N�X
    cMpStartIdxOut = S_lmVecMapLnStartIdx.signals.values;
    cMpEndIdxOut = S_lmVecMapLnEndIdx.signals.values;
    
    % LM�o�͒n�}�������
    cMpLtClassOut = S_lmVecMapLnPntLineClassL.signals.values;
    cMpRtClassOut = S_lmVecMapLnPntLineClassR.signals.values;
    cMpClassOut = S_lmVecMapLnPntLineClassL.signals.values;
    tempClass = cMpClassOut;
%         ValidBit = and(tempClass ~= 0 , tempClass ~= 1);
    ValidBit = tempClass ~= 0;
    cMpLtYOut(ValidBit == 0) = NaN;

    cMpClassOut = S_lmVecMapLnPntLineClassR.signals.values;
    tempClass = cMpClassOut;
%         ValidBit = and(tempClass ~= 0 , tempClass ~= 1);
    ValidBit = tempClass ~= 0;
    cMpRtYOut(ValidBit == 0) = NaN;

    cMpCtClass = S_lmVecMapLnPntClass.signals.values;

    if swMapBnd
        % LM�o�͒n�}���E���ʒu(�Ԑ����S����̋���)
        cBndDistLtOut = S_lmVecMapLnPntDistToBndL.signals.values;
        cBndDistRtOut = S_lmVecMapLnPntDistToBndR.signals.values;
        % LM�o�͒n�}���E���ʒu(�A�o�E�g���ԍ��W�ʒu)
        cBndLtYOut = cMpYOut + cBndDistLtOut;
        cBndRtYOut = cMpYOut + cBndDistRtOut;
        cMpClassOut = S_lmVecMapLnPntBndClassL.signals.values;
        tempClass = cMpClassOut;
        ValidBit = and(tempClass ~= 0 , tempClass ~= 1);
        cBndLtYOut(ValidBit == 0) = NaN;
        cMpClassOut = S_lmVecMapLnPntBndClassR.signals.values;
        tempClass = cMpClassOut;
        ValidBit = and(tempClass ~= 0 , tempClass ~= 1);
        cBndRtYOut(ValidBit == 0) = NaN;
    end

    if swCANape == 0
		if exist('S_swLmmlMapMinimize', 'var')
            swLmmlMapMinimize = S_swLmmlMapMinimize;
        else
            swLmmlMapMinimize = 0;
        end
		% 1�ł��ϐ�������Ȃ瑼�̕ϐ�������͂�
		% �n�}�����E���S��(LM���Ȉʒu���_)
		mapCtLmX = S_mapLmCtX.signals.values;
		mapCtLmY = S_mapLmCtY.signals.values;
		mapLtLmX = S_mapLmLtX.signals.values;
		mapLtLmY = S_mapLmLtY.signals.values;
		mapRtLmX = S_mapLmRtX.signals.values;
		mapRtLmY = S_mapLmRtY.signals.values;
        sizeLmmlMap = size(S_mapLmCtY.signals.values);
		
		if any(swDispContRt == 2)
		    % �n�}�����E���S��(�M����M�^�C�~���O���킹�����Ȉʒu���_)
		    % LM���Ȉʒu���_����t�ϊ��ŎZ�o����
		    lmLocX = S_lmmlLmLocX.signals.values;
		    lmLocY = S_lmmlLmLocY.signals.values;
		    lmLocR = S_lmmlLmLocOri.signals.values;
		    [mapCtMpuX, mapCtMpuY] = ReverseRctfFunc(mapCtLmX, mapCtLmY, mapLanePntNum, lmLocX, lmLocY, lmLocR, time, sizeLmmlMap(2),swLmmlMapMinimize);
		    [mapLtMpuX, mapLtMpuY] = ReverseRctfFunc(mapLtLmX, mapLtLmY, mapLtLinePntNum, lmLocX, lmLocY, lmLocR, time, sizeLmmlMap(2),swLmmlMapMinimize);
		    [mapRtMpuX, mapRtMpuY] = ReverseRctfFunc(mapRtLmX, mapRtLmY, mapRtLinePntNum, lmLocX, lmLocY, lmLocR, time, sizeLmmlMap(2),swLmmlMapMinimize);
        end

        % �c�ʒu�␳�Ɏg�p����J�����ƒn�}����
        xcorrDxDlt = S_lmmlXcorrIcpCorrDlt.signals.values(:,2);
        xcorrDyDlt = S_lmmlXcorrIcpCorrDlt.signals.values(:,3);
        xcorrDyawDlt = S_lmmlXcorrIcpCorrDlt.signals.values(:,1);
    
        if exist('S_lmmlXCorrCamLX', 'var')
            % 1�ł��ϐ�������Ȃ瑼�̕ϐ�������͂�
            xcorrCamLX = S_lmmlXCorrCamLX.signals.values;
            xcorrCamLY = S_lmmlXCorrCamLY.signals.values;
            xcorrCamRX = S_lmmlXCorrCamRX.signals.values;
            xcorrCamRY = S_lmmlXCorrCamRY.signals.values;
            xcorrCamLB = S_lmmlXCorrCamLB.signals.values;
            xcorrCamRB = S_lmmlXCorrCamRB.signals.values;
            
            xcorrBfrMapCX = S_lmmlXCorrMCX.signals.values;
            xcorrBfrMapCY = S_lmmlXCorrMCY.signals.values;
            xcorrCB = S_lmmlXCorrMCB.signals.values;
            xcorrBfrMapLX = S_lmmlXCorrMLX.signals.values;
            xcorrBfrMapLY = S_lmmlXCorrMLY.signals.values;
            xcorrBfrMapRX = S_lmmlXCorrMRX.signals.values;
            xcorrBfrMapRY = S_lmmlXCorrMRY.signals.values;
            xcorrLB = S_lmmlXCorrMLB.signals.values;
            xcorrRB = S_lmmlXCorrMRB.signals.values;
            
            % deltaY�̎Z�o
            [xcorrCamDltLX, xcorrCamDltLY, xcorrCamDltLB] = ...
                CalcDeltay(samples, xcorrCamLX, xcorrCamLY, xcorrCamLB, 1050);
            [xcorrCamDltRX, xcorrCamDltRY, xcorrCamDltRB] = ...
                CalcDeltay(samples, xcorrCamRX, xcorrCamRY, xcorrCamRB, 1050);
            [xcorrBfrMapDltLX, xcorrBfrMapDltLY, xcorrDltLB] = ...
                CalcDeltay(samples, xcorrBfrMapLX, xcorrBfrMapLY, xcorrLB, 1100);
            [xcorrBfrMapDltRX, xcorrBfrMapDltRY, xcorrDltRB] = ...
                CalcDeltay(samples, xcorrBfrMapRX, xcorrBfrMapRY, xcorrRB, 1100);

            % �c�ʒu�␳�ȗ��v�Z
            xcorrMCR = zeros(size(xcorrBfrMapCX));
            [rowxcorrBfrMapCX,~] = size(xcorrBfrMapCX);
            for i = 1:rowxcorrBfrMapCX
                xcorrMCR(i,:) = calcRadius(xcorrBfrMapCX(i,:), xcorrBfrMapCY(i,:), 1, 1100, 30);
            end

        else
            % Gen3 �ł͕ϐ���ۑ����Ă��Ȃ����Ƃ�����̂ŁA���̏ꍇ�A0���߂���
            xcorrCamLX = zeros(samples, 1050);
            xcorrCamLY = zeros(samples, 1050);
            xcorrCamRX = zeros(samples, 1050);
            xcorrCamRY = zeros(samples, 1050);
            xcorrCamLB = zeros(samples, 1050);
            xcorrCamRB = zeros(samples, 1050);
            
            xcorrCamDltLX = zeros(samples, 1050);
            xcorrCamDltLY = zeros(samples, 1050);
            xcorrCamDltRX = zeros(samples, 1050);
            xcorrCamDltRY = zeros(samples, 1050);
            xcorrCamDltLB = zeros(samples, 1050);
            xcorrCamDltRB = zeros(samples, 1050);
            
            xcorrBfrMapDltLX = zeros(samples, 1100);
            xcorrBfrMapDltLY = zeros(samples, 1100);
            xcorrBfrMapDltRX = zeros(samples, 1100);
            xcorrBfrMapDltRY = zeros(samples, 1100);
            xcorrDltLB = zeros(samples, 1100);
            xcorrDltRB = zeros(samples, 1100);
            
            xcorrBfrMapCX = zeros(samples, 1100);
            xcorrBfrMapCY = zeros(samples, 1100);
            xcorrCB = zeros(samples, 1100);
            xcorrBfrMapLX = zeros(samples, 1100);
            xcorrBfrMapLY = zeros(samples, 1100);
            xcorrBfrMapRX = zeros(samples, 1100);
            xcorrBfrMapRY = zeros(samples, 1100);
            xcorrLB = zeros(samples, 1100);
            xcorrRB = zeros(samples, 1100);
        end
        [a,~] = size(xcorrCamLB);
        for i = 1:a
            xcorrCamLNum(i) = sum(xcorrCamLB(i,1:1000));
            xcorrCamRNum(i) = sum(xcorrCamRB(i,1:1000));
        end

        % �c�ʒu�␳��̒n�}����
        pntNum = 1100;
        [xcorrAftCX, xcorrAftCY] = RctfFunc(xcorrBfrMapCX, xcorrBfrMapCY, xcorrCB, pntNum, lmCorrDx, lmCorrDy, lmCorrDyaw);
        [xcorrAftLX, xcorrAftLY] = RctfFunc(xcorrBfrMapLX, xcorrBfrMapLY, xcorrLB, pntNum, lmCorrDx, lmCorrDy, lmCorrDyaw);
        [xcorrAftRX, xcorrAftRY] = RctfFunc(xcorrBfrMapRX, xcorrBfrMapRY, xcorrRB, pntNum, lmCorrDx, lmCorrDy, lmCorrDyaw);
        [xcorrAftDltLX, xcorrAftDltLY] = RctfFunc(xcorrBfrMapDltLX, xcorrBfrMapDltLY, xcorrDltLB, pntNum, xcorrDxDlt, xcorrDyDlt, xcorrDyawDlt);
        [xcorrAftDltRX, xcorrAftDltRY] = RctfFunc(xcorrBfrMapDltRX, xcorrBfrMapDltRY, xcorrDltRB, pntNum, xcorrDxDlt, xcorrDyDlt, xcorrDyawDlt);
        [a,~] = size(xcorrCamLB);
        for i = 1:a
            xcorrLNum(i) = sum(xcorrLB(i,1:1000));
            xcorrRNum(i) = sum(xcorrRB(i,1:1000));
        end

        perrMin = S_lmmlXcorrIcpPerrMin.signals.values;
        icpDist = S_lmmlXcorrIcpVecDist.signals.values;
        xcorrIdxMinDistCnv = S_lmmlXcorrIdxMin.signals.values - 30;
        idxIcpCamLt = min(icpDist(:,1:204)+1001,1050);
        idxIcpCamRt = min(icpDist(:,205:408)+1001,1050);
        idxIcpMapLt = min(icpDist(:,1:204)+1001+xcorrIdxMinDistCnv(:,:),1100);
        idxIcpMapRt = min(icpDist(:,205:408)+1001+xcorrIdxMinDistCnv(:,:),1100);

        ycorrDxy = S_lmmlMatchT.signals.values;
        ycorrDyaw = S_lmmlMatchR.signals.values;

        % �n�}�}�b�`���O�Ɏg�p����J�����ƒn�}����
        matchCamX = S_lmmlBfrMatchLine.signals.values(:,1:100);
        matchCamY = S_lmmlBfrMatchLine.signals.values(:,401:500);
        matchMapX = S_lmmlBfrMatchLine.signals.values(:,201:300);
        matchMapY = S_lmmlBfrMatchLine.signals.values(:,301:400);

        % �n�}�}�b�`���O��̒n�}����
        pntNum = 100;
        [matchAftMapX, matchAftMapY] = RctfFunc(matchMapX, matchMapY, ones(size(matchMapY)), pntNum, ycorrDxy(:,1), ycorrDxy(:,2), asin(ycorrDyaw(:,2)));
        matchAftMapXLt = matchAftMapX(:,1:50);
        matchAftMapYLt = matchAftMapY(:,1:50);
        matchAftMapXRt = matchAftMapX(:,51:100);
        matchAftMapYRt = matchAftMapY(:,51:100);

        % �J���������`��
        lmCamXRaw = S_lineCamXMe.signals.values;
        lmCamYRaw = S_lineCamYMe.signals.values;

    %     fltStt = S_lmmlFltStt.signals.values(:,1);
    %     tcGain = S_lmmlFltTc.signals.values(:,1);
    %     tcFilterOrt = S_lmmlFltTc.signals.values(:,2);
    %     tcFilter = S_lmmlFltTc.signals.values(:,3);
    end
    
    xcorrIcpErrStt = S_lmmlXcorrIcpErrStt.signals.values;
    xcorrIcpErr = S_lmmlXcorrIcpErr.signals.values;
    yrmStt = S_lmmlYrmStt.signals.values;
    % gnssGAxis = S_gnssGAxis.signals.values;
    gnssGAxis = S_mpuGnssOriLatLon.signals.values;
    linebFlg = S_lmVecClinebFlg.signals.values;

    % Ctrl�Ԑ��`��]���M���v�Z
    DiffRangeAll(:,1:451) = ((lmCtrlX(:,451+1:451+451)-lmMapEgoX(:,1:451)).^2+(lmCtrlY(:,451+1:451+451)-lmMapEgoY(:,1:451)).^2).^(1/2);
    maxDiffRangeAll = max(DiffRangeAll,[],[2]);
    YawAngleData(:,1:450) = atan2(lmCtrlY(:,451+2:451+451)-lmCtrlY(:,451+1:451+450),lmCtrlX(:,451+2:451+451)-lmCtrlX(:,451+1:451+450));
    YawAngleDataDiffTmp(:,1:449) = abs(YawAngleData(:,2:450) - YawAngleData(:,1:449));
    YawAngleDataDiff(:,1:448) = abs(YawAngleDataDiffTmp(:,2:449) - YawAngleDataDiffTmp(:,1:448));
    maxYawAngleDataDiff = max(YawAngleDataDiff,[],[2]);
%     YawAngleDataMap(:,1:450) = atan2(lmMapEgoY(:,2:451)-lmMapEgoY(:,1:450),lmMapEgoX(:,2:451)-lmMapEgoX(:,1:450));
%     YawAngleDataDiffMapTmp(:,1:449) = abs(YawAngleDataMap(:,2:450) - YawAngleDataMap(:,1:449));
%     YawAngleDataDiffMap(:,1:448) = abs(YawAngleDataDiffMapTmp(:,2:449) - YawAngleDataDiffMapTmp(:,1:448));
end

xcorrStt = S_lmmlXcorrStt.signals.values;

% ���ԉ��_�X�e�[�^�X
laneConfidence = S_MElaneExistenceProb.signals.values(:,1:4);   % �G���[���p�X�N���v�g
laneQuality = S_MElaneQuality.signals.values(:,1:4);                    % �G���[���p�X�N���v�g
laneType = S_MElaneType.signals.values(:,1:4);                          % �G���[���p�X�N���v�g

if sw3dOdo
    if exist('S_lmodEgoMov3DX', 'var')
        EgoMovX = S_lmodEgoMov3DX.signals.values(:,1);
        EgoMovY = S_lmodEgoMov3DY.signals.values(:,1);
        EgoRot = S_lmodEgo3DR.signals.values(:,1);
    else
        fprintf(1,'\n2�����I�h���g������ώ�����ECU����ɍ��킹�ăI�h���g���ʂ̌v�Z���J�n���܂��B\n');
        EgoMovX = modmov(S_lmodEgoMovX.signals.values(:,1),time,0.05,0);
        EgoMovY = modmov(S_lmodEgoMovY.signals.values(:,1),time,0.05,0);
        EgoRot = modmov(S_lmodEgoRot.signals.values(:,1),time,0.05,0);
    end
else
    EgoMovX = S_lmodEgoMovX.signals.values(:,1);
    EgoMovY = S_lmodEgoMovY.signals.values(:,1);
    EgoRot = S_lmodEgoRot.signals.values(:,1);
end
if swCANape
%     yawR = S_YawR.signals.values(:,1);
    strAgl = S_StrAgl.signals.values(:,1);
end

% LM���Ȉʒu�덷
if swAntLoc
    pntNum = 451;
    % MPU���Ȉʒu(���ԕ␳��)���_��LM���H�`����Z�o
    [lmCtrlXBsMpuLoc, lmCtrlYBsMpuLoc] = RctfFuncA(lmCtrlX(:,452:902), lmCtrlY(:,452:902), ones(size(lmCtrlY(:,452:902))), pntNum, S_lmmlLmLocX.signals.values, S_lmmlLmLocY.signals.values, S_lmmlLmLocOri.signals.values);
    % �n�}�}�b�`���O���Ȉʒu���_��LM���H�`����Z�o
    [lmCtrlXBsYrmLoc, lmCtrlYBsYrmLoc] = RctfFunc(lmCtrlXBsMpuLoc, lmCtrlYBsMpuLoc, ones(size(lmCtrlYBsMpuLoc)), pntNum, lmCorrDx, lmCorrDy, lmCorrDyaw);
    % �f�b�h���R���Ȉʒu���_��LM���H�`����Z�o
    [lmCtrlXBsDrLoc, lmCtrlYBsDrLoc] = RctfFunc(lmCtrlXBsMpuLoc, lmCtrlYBsMpuLoc, ones(size(lmCtrlYBsMpuLoc)), pntNum, S_lmmlDrLocX.signals.values, S_lmmlDrLocY.signals.values, S_lmmlDrLocOri.signals.values);
end

if swPerrALL
    %%% �J�����ƒn�}�̃�Y�����l���Z�o
    xcorrLB = double(xcorrDltLB);
    xcorrRB = double(xcorrDltRB);
    pntNum = 1100;
    [xcorrAftLXDlt, xcorrAftLYDlt] = RctfFuncVec(xcorrBfrMapDltLX, xcorrBfrMapDltLY, xcorrLB, pntNum, xcorrDxDlt, xcorrDyDlt, xcorrDyawDlt);
    [xcorrAftRXDlt, xcorrAftRYDlt] = RctfFuncVec(xcorrBfrMapDltRX, xcorrBfrMapDltRY, xcorrRB, pntNum, xcorrDxDlt, xcorrDyDlt, xcorrDyawDlt);

    % �J����������Y
    xcorrCamLB = double(S_lmmlXCorrCamDltLB.signals.values);
    xcorrCamRB = double(S_lmmlXCorrCamDltRB.signals.values);

    % �n�}�ƃJ�����̃�Y�����l���Z�o����
    mapIdx = S_lmmlXcorrIdxMin.signals.values(:,:)-30;
    %     perrL = (dltCamLY - xcorrAftLYDlt(:,1:1050)) .* xcorrLB(:,1:1050) .* xcorrCamLB;
    %     perrR = (dltCamRY - xcorrAftRYDlt(:,1:1050)) .* xcorrRB(:,1:1050) .* xcorrCamRB;
    perrL = zeros(size(xcorrCamDltLY));
    perrR = zeros(size(xcorrCamDltRY));
    for i = 1:length(xcorrCamDltLX)
        if mapIdx(i) >= 0
            perrL(i,:) = (xcorrCamDltLY(i,:) - xcorrAftLYDlt(i,1+mapIdx(i):1050+mapIdx(i))) .* xcorrLB(i,1+mapIdx(i):1050+mapIdx(i)) .* xcorrCamLB(i,:);
            perrR(i,:) = (xcorrCamDltRY(i,:) - xcorrAftRYDlt(i,1+mapIdx(i):1050+mapIdx(i))) .* xcorrRB(i,1+mapIdx(i):1050+mapIdx(i)) .* xcorrCamRB(i,:);
        else
            perrL(i,1:1050+mapIdx(i)) = (xcorrCamDltLY(i,1-mapIdx(i):1050) - xcorrAftLYDlt(i,1:1050+mapIdx(i))) .* xcorrLB(i,1:1050+mapIdx(i)) .* xcorrCamLB(i,1-mapIdx(i):1050);
            perrR(i,1:1050+mapIdx(i)) = (xcorrCamDltRY(i,1-mapIdx(i):1050) - xcorrAftRYDlt(i,1:1050+mapIdx(i))) .* xcorrRB(i,1:1050+mapIdx(i)) .* xcorrCamRB(i,1-mapIdx(i):1050);
        end
    end
end

if swMmLine
    mmLtIdx = S_lmmlMmLineId.signals.values(:,1);
    mmRtIdx = S_lmmlMmLineId.signals.values(:,2);
    egoLaneIdx = int16(S_lmldVecLaneLocMinus1.signals.values(:,1));
    nextLtLaneIdx = int16(S_lmldVecLaneLocMinus1.signals.values(:,2));
    nextRtLaneIdx = int16(S_lmldVecLaneLocMinus1.signals.values(:,3));
    egoLaneLtLineX = zeros(length(time),650);
    egoLaneLtLineY = zeros(length(time),650);
    egoLaneRtLineX = zeros(length(time),650);
    egoLaneRtLineY = zeros(length(time),650);
    for cntIdx = 1:length(time)
        if mmLtIdx(cntIdx) == 1 && egoLaneIdx(cntIdx) ~= -1
            egoLaneLtLineX(cntIdx,:) = mapLtMpuX(cntIdx,egoLaneIdx(cntIdx)*650+1:(egoLaneIdx(cntIdx)+1)*650);
            egoLaneLtLineY(cntIdx,:) = mapLtMpuY(cntIdx,egoLaneIdx(cntIdx)*650+1:(egoLaneIdx(cntIdx)+1)*650);
        elseif mmLtIdx(cntIdx) == 3 && nextLtLaneIdx(cntIdx) ~= -1
            egoLaneLtLineX(cntIdx,:) = mapLtMpuX(cntIdx,nextLtLaneIdx(cntIdx)*650+1:(nextLtLaneIdx(cntIdx)+1)*650);
            egoLaneLtLineY(cntIdx,:) = mapLtMpuY(cntIdx,nextLtLaneIdx(cntIdx)*650+1:(nextLtLaneIdx(cntIdx)+1)*650);
        elseif mmLtIdx(cntIdx) == 5 && nextRtLaneIdx(cntIdx) ~= -1
            egoLaneLtLineX(cntIdx,:) = mapLtMpuX(cntIdx,nextRtLaneIdx(cntIdx)*650+1:(nextRtLaneIdx(cntIdx)+1)*650);
            egoLaneLtLineY(cntIdx,:) = mapLtMpuY(cntIdx,nextRtLaneIdx(cntIdx)*650+1:(nextRtLaneIdx(cntIdx)+1)*650);
        else
            egoLaneLtLineX(cntIdx,:) = zeros(1,650);
            egoLaneLtLineY(cntIdx,:) = zeros(1,650);
        end
        if mmRtIdx(cntIdx) == 2 && egoLaneIdx(cntIdx) ~= -1
            egoLaneRtLineX(cntIdx,:) = mapRtMpuX(cntIdx,egoLaneIdx(cntIdx)*650+1:(egoLaneIdx(cntIdx)+1)*650);
            egoLaneRtLineY(cntIdx,:) = mapRtMpuY(cntIdx,egoLaneIdx(cntIdx)*650+1:(egoLaneIdx(cntIdx)+1)*650);
        elseif mmRtIdx(cntIdx) == 4 && nextLtLaneIdx(cntIdx) ~= -1
            egoLaneRtLineX(cntIdx,:) = mapRtMpuX(cntIdx,nextLtLaneIdx(cntIdx)*650+1:(nextLtLaneIdx(cntIdx)+1)*650);
            egoLaneRtLineY(cntIdx,:) = mapRtMpuY(cntIdx,nextLtLaneIdx(cntIdx)*650+1:(nextLtLaneIdx(cntIdx)+1)*650);
        elseif mmRtIdx(cntIdx) == 6 && nextRtLaneIdx(cntIdx) ~= -1
            egoLaneRtLineX(cntIdx,:) = mapRtMpuX(cntIdx,nextRtLaneIdx(cntIdx)*650+1:(nextRtLaneIdx(cntIdx)+1)*650);
            egoLaneRtLineY(cntIdx,:) = mapRtMpuY(cntIdx,nextRtLaneIdx(cntIdx)*650+1:(nextRtLaneIdx(cntIdx)+1)*650);
        else
            egoLaneRtLineX(cntIdx,:) = zeros(1,650);
            egoLaneRtLineY(cntIdx,:) = zeros(1,650);
        end
    end
end
if swSN == 0
    clear S_mapLm*t* S_lineCam*Me S_lmVecClinePointPos* S_lmmlXCorrCam* S_lmmlXCorrM*;
end
%% Comp�f�[�^�p
if swComp
    for dc = 1:compDataNum
        lmInhSttOrg{dc} = ORG{dc}.S_lmInhStt.signals.values;
        if swSN == 0
            mhSttOrg{dc} = ORG{dc}.S_mhStatus.signals.values;
        end
        lmInhSttOrg{dc} = ORG{dc}.S_lmInhStt.signals.values;
        eMapOrg{dc} = bitget( lmInhSttOrg{dc}, 3 );
        eYRMOrg{dc} = bitget( lmInhSttOrg{dc}, 5 );

        % ���H�I�����
        lmLnModeOrg{dc} = ORG{dc}.S_lmLnMode.signals.values;
        selectedCtrlSttOrg{dc} = bitget( lmLnModeOrg{dc}, 19 ) | bitget( lmLnModeOrg{dc}, 20 );

        % LM�o��Ctrl�Ԑ��i��r���j
        ctrlXOrg{dc} = ORG{dc}.S_lmVecCtrlLnPntX.signals.values;
        ctrlYOrg{dc} = ORG{dc}.S_lmVecCtrlLnPntY.signals.values;
        cOutFlgOrg{dc} = ORG{dc}.S_lmCtrlLnExistFlg.signals.values;
        for i = 1:length(cOutFlgOrg{dc})
            cOutNumOrg{dc}(i,1) = sum(uint16(cOutFlgOrg{dc}(i,:)));
        end
        cOutStartIdxOrg{dc} = ORG{dc}.S_CtrlRangeStartIdx.signals.values;
        cOutEndIdxOrg{dc} = ORG{dc}.S_CtrlRangeEndIdx.signals.values;

        lmCtrlXOrg{dc} = ctrlXOrg{dc};
        lmCtrlYOrg{dc} = ctrlYOrg{dc};
        lmCtrlXOrg{dc} = ORG{dc}.S_lmVecCtrlLnPntX.signals.values;
        lmCtrlYOrg{dc} = ORG{dc}.S_lmVecCtrlLnPntY.signals.values;

        if swSN == 0
            xcorrIcpErrOrg{dc} = ORG{dc}.S_lmmlXcorrIcpErr.signals.values;
            xcorrIcpErrSttOrg{dc} = ORG{dc}.S_lmmlXcorrIcpErrStt.signals.values;
    
            initLnSttOrg{dc} = ORG{dc}.S_lmldVecLatPnt.signals.values(:,3); % 1:��ӂɓ��� 2:���ߑł�
            lmPldSttOrg{dc} = ORG{dc}.S_lmPldStt.signals.values;
            yrmSttOrg{dc} = ORG{dc}.S_lmmlYrmStt.signals.values;
            
            xcorrDxOrg{dc} = ORG{dc}.S_lmmlXcorrDx.signals.values;
            xcorrDyOrg{dc} = ORG{dc}.S_lmmlXcorrDy.signals.values;
            xcorrDyawOrg{dc} = ORG{dc}.S_lmmlXcorrDyaw.signals.values;
            lmCorrDxOrg{dc} = ORG{dc}.S_lmmlYrmLocX.signals.values;
            lmCorrDyOrg{dc} = ORG{dc}.S_lmmlYrmLocY.signals.values;
            lmCorrDyawOrg{dc} = ORG{dc}.S_lmmlYrmLocOri.signals.values;

            xcorrCamLXOrg{dc} = ORG{dc}.S_lmmlXCorrCamLX.signals.values;
            xcorrCamLYOrg{dc} = ORG{dc}.S_lmmlXCorrCamLY.signals.values;
            xcorrCamRXOrg{dc} = ORG{dc}.S_lmmlXCorrCamRX.signals.values;
            xcorrCamRYOrg{dc} = ORG{dc}.S_lmmlXCorrCamRY.signals.values;

            xcorrBfrMapLXOrg{dc} = ORG{dc}.S_lmmlXCorrMLX.signals.values;
            xcorrBfrMapLYOrg{dc} = ORG{dc}.S_lmmlXCorrMLY.signals.values;
            xcorrBfrMapRXOrg{dc} = ORG{dc}.S_lmmlXCorrMRX.signals.values;
            xcorrBfrMapRYOrg{dc} = ORG{dc}.S_lmmlXCorrMRY.signals.values;

            xcorrCamLBOrg{dc} = ORG{dc}.S_lmmlXCorrCamLB.signals.values;
            xcorrCamRBOrg{dc} = ORG{dc}.S_lmmlXCorrCamRB.signals.values;
            
            xcorrLBOrg{dc} = ORG{dc}.S_lmmlXCorrMLB.signals.values;
            xcorrRBOrg{dc} = ORG{dc}.S_lmmlXCorrMRB.signals.values;
            
            % deltaY�̎Z�o
            [xcorrCamDltLXOrg{dc}, xcorrCamDltLYOrg{dc}, xcorrCamDltLBOrg{dc}] = ...
                CalcDeltay(samples, xcorrCamLXOrg{dc}, ...
                    xcorrCamLYOrg{dc}, xcorrCamLBOrg{dc}, 1050);
            [xcorrCamDltRXOrg{dc}, xcorrCamDltRYOrg{dc}, xcorrCamDltRBOrg{dc}] = ...
                CalcDeltay(samples, xcorrCamRXOrg{dc}, ...
                    xcorrCamRYOrg{dc}, xcorrCamRBOrg{dc}, 1050);
            [xcorrBfrMapDltLXOrg{dc}, xcorrBfrMapDltLYOrg{dc}, xcorrDltLBOrg{dc}] = ...
                CalcDeltay(samples, xcorrBfrMapLXOrg{dc}, ...
                    xcorrBfrMapLYOrg{dc}, xcorrLBOrg{dc}, 1100);
            [xcorrBfrMapDltRXOrg{dc}, xcorrBfrMapDltRYOrg{dc}, xcorrDltRBOrg{dc}] = ...
                CalcDeltay(samples, xcorrBfrMapRXOrg{dc}, ...
                    xcorrBfrMapRYOrg{dc}, xcorrRBOrg{dc}, 1100);
            
            xcorrDxDltOrg{dc} = ORG{dc}.S_lmmlXcorrIcpCorrDlt.signals.values(:,2);
            xcorrDyDltOrg{dc} = ORG{dc}.S_lmmlXcorrIcpCorrDlt.signals.values(:,3);
            xcorrDyawDltOrg{dc} = ORG{dc}.S_lmmlXcorrIcpCorrDlt.signals.values(:,1);
            icpDistOrg{dc} = ORG{dc}.S_lmmlXcorrIcpVecDist.signals.values;
            xcorrIdxMinDistCnvOrg{dc} = ORG{dc}.S_lmmlXcorrIdxMin.signals.values - 30;
            for j = 1:length(xcorrCamLBOrg{dc})
                xcorrCamLNumOrg{dc}(j) = sum(xcorrCamLBOrg{dc}(j,1:1000));
                xcorrCamRNumOrg{dc}(j) = sum(xcorrCamRBOrg{dc}(j,1:1000));
            end

            laneLocOrg{dc} = ORG{dc}.S_lmldVecLaneLocMinus1.signals.values(:,1);
            perrMinOrg{dc} = ORG{dc}.S_lmmlXcorrIcpPerrMin.signals.values;
            idxIcpCamLtOrg{dc} = min(icpDistOrg{dc}(:,1:204)+1001,1050);
            idxIcpCamRtOrg{dc} = min(icpDistOrg{dc}(:,205:408)+1001,1050);
            idxIcpMapLtOrg{dc} = min(icpDistOrg{dc}(:,1:204)+1001+xcorrIdxMinDistCnvOrg{dc}(:,:),1100);
            idxIcpMapRtOrg{dc} = min(icpDistOrg{dc}(:,205:408)+1001+xcorrIdxMinDistCnvOrg{dc}(:,:),1100);

            pntNum = 1100;
            [xcorrAftLXOrg{dc}, xcorrAftLYOrg{dc}] = RctfFunc(xcorrBfrMapLXOrg{dc}, xcorrBfrMapLYOrg{dc}, xcorrLBOrg{dc}, pntNum, lmCorrDxOrg{dc}, lmCorrDyOrg{dc}, lmCorrDyawOrg{dc});
            [xcorrAftRXOrg{dc}, xcorrAftRYOrg{dc}] = RctfFunc(xcorrBfrMapRXOrg{dc}, xcorrBfrMapRYOrg{dc}, xcorrRBOrg{dc}, pntNum, lmCorrDxOrg{dc}, lmCorrDyOrg{dc}, lmCorrDyawOrg{dc});
            [xcorrAftDltLXOrg{dc}, xcorrAftDltLYOrg{dc}] = RctfFunc(xcorrBfrMapDltLXOrg{dc}, xcorrBfrMapDltLYOrg{dc}, xcorrDltLBOrg{dc}, pntNum, xcorrDxDltOrg{dc}, xcorrDyDltOrg{dc}, xcorrDyawDltOrg{dc});
            [xcorrAftDltRXOrg{dc}, xcorrAftDltRYOrg{dc}] = RctfFunc(xcorrBfrMapDltRXOrg{dc}, xcorrBfrMapDltRYOrg{dc}, xcorrDltRBOrg{dc}, pntNum, xcorrDxDltOrg{dc}, xcorrDyDltOrg{dc}, xcorrDyawDltOrg{dc});
            for j = 1:length(xcorrLBOrg{dc})
                xcorrLNumOrg{dc}(j) = sum(xcorrLBOrg{dc}(j,1:1000));
                xcorrRNumOrg{dc}(j) = sum(xcorrRBOrg{dc}(j,1:1000));
            end

            ycorrDxyOrg{dc} = ORG{dc}.S_lmmlMatchT.signals.values;
            ycorrDyawOrg{dc} = ORG{dc}.S_lmmlMatchR.signals.values;

            matchCamXOrg{dc} = ORG{dc}.S_lmmlBfrMatchLine.signals.values(:,1:100);
            matchCamYOrg{dc} = ORG{dc}.S_lmmlBfrMatchLine.signals.values(:,401:500);
            matchMapXOrg{dc} = ORG{dc}.S_lmmlBfrMatchLine.signals.values(:,201:300);
            matchMapYOrg{dc} = ORG{dc}.S_lmmlBfrMatchLine.signals.values(:,301:400);
            pntNum = 100;
            [matchAftMapXOrg{dc}, matchAftMapYOrg{dc}] = RctfFunc(matchMapXOrg{dc}, matchMapYOrg{dc}, ones(size(matchMapYOrg{dc})), pntNum, ycorrDxyOrg{dc}(:,1), ycorrDxyOrg{dc}(:,2), asin(ycorrDyawOrg{dc}(:,2)));
            matchAftMapXLtOrg{dc} = matchAftMapXOrg{dc}(:,1:50);
            matchAftMapYLtOrg{dc} = matchAftMapYOrg{dc}(:,1:50);
            matchAftMapXRtOrg{dc} = matchAftMapXOrg{dc}(:,51:100);
            matchAftMapYRtOrg{dc} = matchAftMapYOrg{dc}(:,51:100);
            lmCamXRawOrg{dc} = ORG{dc}.S_lineCamXMe.signals.values;
            lmCamYRawOrg{dc} = ORG{dc}.S_lineCamYMe.signals.values;
            linebFlgOrg{dc} = ORG{dc}.S_lmVecClinebFlg.signals.values;
%             fltSttOrg{dc} = ORG{dc}.S_lmmlFltStt.signals.values(:,1);
%             tcGainOrg{dc} = ORG{dc}.S_lmmlFltTc.signals.values(:,1);
%             tcFilterOrtOrg{dc} = ORG{dc}.S_lmmlFltTc.signals.values(:,2);
%             tcFilterOrg{dc} = ORG{dc}.S_lmmlFltTc.signals.values(:,3);
            xcorrSttOrg{dc} = ORG{dc}.S_lmmlXcorrStt.signals.values;
            xcorrDxOrg{dc} = ORG{dc}.S_lmmlXcorrDx.signals.values;
            xcorrIcpDxOrg{dc} = ORG{dc}.S_lmmlXcorrIcpDx.signals.values;
        end

        lmCamXOrg{dc} = ORG{dc}.S_lmVecClinePointPosX.signals.values;
        lmCamYOrg{dc} = ORG{dc}.S_lmVecClinePointPosY.signals.values;
        laneConfidenceOrg{dc} = ORG{dc}.S_MElaneExistenceProb.signals.values;
        laneQualityOrg{dc} = ORG{dc}.S_MElaneQuality.signals.values;

        curvOrg{dc}(:,1) = ORG{dc}.S_lmVecCtrlLnPntCurvature.signals.values(:,151);
        curvOrg{dc}(:,2) = ORG{dc}.S_lmVecCtrlLnPntCurvature.signals.values(:,151+451);
        curvOrg{dc}(:,3) = ORG{dc}.S_lmVecCtrlLnPntCurvature.signals.values(:,151+451*2);

        leftLcFlgOrg{dc} = ORG{dc}.S_lmslLeftLcFlg.signals.values;
        rightLcFlgOrg{dc} = ORG{dc}.S_lmslRightLcFlg.signals.values;
    end
    if swSN == 0
        clear ORG;
    end
end

%% ���W�ϊ��֐�
function [xe, ye] =  RctfFunc(xm, ym, bm, pntNum, x, y, ori)
    for xIdx = 1:pntNum
        xe(:,xIdx) = ( (xm(:,xIdx) - x) .* cos(ori) + (ym(:,xIdx) - y) .* sin(ori) ) .* bm(:,xIdx);
        ye(:,xIdx) = ( (ym(:,xIdx) - y) .* cos(ori) - (xm(:,xIdx) - x) .* sin(ori) ) .* bm(:,xIdx);
    end
end

function [xe, ye] =  RctfFuncA(xm, ym, bm, pntNum, x, y, ori)
    for xIdx = 1:pntNum
        xe(:,xIdx) = (x + xm(:,xIdx) .* cos(ori) - ym(:,xIdx) .* sin(ori) ) .* bm(:,xIdx);
        ye(:,xIdx) = (y + xm(:,xIdx) .* sin(ori) + ym(:,xIdx) .* cos(ori) ) .* bm(:,xIdx);
    end
end

function [xe, ye] =  RctfFuncVec(xm, ym, bm, pntNum, x, y, ori)
    xe = zeros(length(x),pntNum);
    ye = zeros(length(x),pntNum);
    for xIdx = 1:pntNum
        xe(:,xIdx) = ( (xm(:,xIdx) - x) .* cos(ori) + (ym(:,xIdx) - y) .* sin(ori) ) .* bm(:,xIdx);
        ye(:,xIdx) = ( (ym(:,xIdx) - y) .* cos(ori) - (xm(:,xIdx) - x) .* sin(ori) ) .* bm(:,xIdx);
    end
end

function [xe, ye] = ReverseRctfFunc(x, y, num, dx, dy, dr, time, sizeCol, swMin)
    xe = zeros(length(time), sizeCol, 'single');
    ye = zeros(length(time), sizeCol, 'single');
    x = cast(x, 'double');
    y = cast(y, 'double');
    for t = 1:length(time)
        for lane = 1:16
            if num(t, lane) == 0 || num(t, lane) > 650
                continue;
            end
            if swMin
                if lane == 1
                    b = 1;
                else
                    b = b + num(t, lane-1);
                end
            else
                b = (lane - 1) * 650 + 1;
            end
            e = b + num(t, lane) - 1;
            xe(t, b:e) = cast(x(t, b:e) * cos(dr(t)) - y(t, b:e) * sin(dr(t)) + dx(t), 'single');
            ye(t, b:e) = cast(x(t, b:e) * sin(dr(t)) + y(t, b:e) * cos(dr(t)) + dy(t), 'single');
        end
    end
end

%% �c�ʒu�␳�p����deltaY�Z�o�֐�
function [deltax, deltay, deltab] = CalcDeltay(samples, linex, liney, lineb, num)
    interval = 50;
    deltax = zeros(samples, num);
    deltay = zeros(samples, num);
    deltab = zeros(samples, num);
    for t = 1:samples
        deltax(t, :) = -1000:num-1001;
        for i = 1:num - interval * 2
            if lineb(t, i) == 0 || lineb(t, i + interval) == 0 || lineb(t, i + interval * 2) == 0
                continue;
            end

            deltab(t, i) = 1;
            deltay(t, i) = CalcVerticalLength(...
                linex(t, i + interval * 2), liney(t, i + interval * 2), ...
                linex(t, i), liney(t, i), ...
                linex(t, i + interval), liney(t, i + interval));
        end
    end
end

function h = CalcVerticalLength(ppx, ppy, pax, pay, pbx, pby)
    abx = pbx - pax;
    aby = pby - pay;
    apx = ppx - pax;
    apy = ppy - pay;

    outer = abx * apy - apx * aby;
    diffx = pax - pbx;
    diffy = pay - pby;
    l = sqrt(diffx * diffx + diffy * diffy);
    if l < 1.0e-6
        l = 1.0e-6;
    end

    h = outer / l;
end

%% C0�O�Ռ`�����萳�m�ɂ��邽�߂̏���
function mov = modmov(movraw,time,unitsec,mode)
    tmp = movraw;

    if size(time,1) == 1
        difftime = [0 diff(time)];
    else
        difftime = [0;diff(time)];
    end
    for i = 2:length(movraw)
        if difftime(i) > unitsec
            if mode ==0
                tmp(i) = (movraw(i)*(difftime(i)+ unitsec)   + movraw(i-1)*(difftime(i)-unitsec))/(2*unitsec);
            else
                tmp(i) = movraw(i)*(difftime(i)/unitsec);
            end
        end
    end
    mov = tmp;
end

% �c�ʒu�␳�p�n�}���S���̋ȗ��v�Z
function r = calcRadius(x, y, s, e, interval)
    r = NaN(1,e-s+1);
    for i = s + interval:e-interval
        x1 = x(i - interval);
        x2 = x(i);
        x3 = x(i + interval);
        y1 = y(i - interval);
        y2 = y(i);
        y3 = y(i + interval);
     
        t1 = y1 - y2;
        t2 = x3 * x3 - x1 * x1 + y3 * y3 - y1 * y1;
        t3 = y1 - y3;
        t4 = x2 * x2 - x1 * x1 + y2 * y2 - y1 * y1;
        t5 = x1 - x2;
        t6 = y1 - y3;
        t7 = x1 - x3;
        t8 = y1 - y2;
        xp = (t1 * t2 - t3 * t4) / (2 * t5 * t6 - 2 * t7 * t8);
     
        t1 = x1 - x3;
        t2 = x2 * x2 - x1 * x1 + y2 * y2 - y1 * y1;
        t3 = x1 - x2;
        t4 = x3 * x3 - x1 * x1 + y3 * y3 - y1 * y1;
        t5 = x1 - x2;
        t6 = y1 - y3;
        t7 = x1 - x3;
        t8 = y1 - y2;
        yp = (t1 * t2 - t3 * t4) / (2 * t5 * t6 - 2 * t7 * t8);
        r(i) = sqrt((xp - x1) * (xp - x1) + (yp - y1) * (yp - y1));
    end
end