function PlotMpuLine(curPoint,folPath)
    mpuNameDir = dir(fullfile(folPath,'*MPU_message12*.mat'));
    mpuPath = fullfile(mpuNameDir.folder,mpuNameDir.name);
%     load(fullfile(folPath,curInputNAME));
    load(mpuPath);

    mpu_x = MpuMessage1.strLanePointPosX.sigValue.signals.values;
    mpu_y = MpuMessage1.strLanePointPosY.sigValue.signals.values;
    point_num_max = 650;
    point_num = MpuMessage1.strLanePointNum.sigValue.signals.values;
    center_connection = MpuMessage1.strLaneConnection.sigValue.signals.values;
    mpu_attr = MpuMessage1.strLanePointType.sigValue.signals.values;
    mpu_left_lane = MpuMessage1.strLanePointLindex.sigValue.signals.values;
    mpu_right_lane = MpuMessage1.strLanePointRindex.sigValue.signals.values;

    mpu_x_long = MpuMessage1.strLanePointPosXLong.sigValue.signals.values;
    mpu_y_long = MpuMessage1.strLanePointPosYLong.sigValue.signals.values;
    point_num_long = MpuMessage1.strLanePointNum2.sigValue.signals.values;

    left_x = MpuMessage1.strLineLeftPointPosX.sigValue.signals.values;
    left_y = MpuMessage1.strLineLeftPointPosY.sigValue.signals.values;
    left_connection = MpuMessage1.strLineLeftConnection.sigValue.signals.values;
    left_attr = MpuMessage1.strLineLeftAttribute.sigValue.signals.values;
    left_point_num = MpuMessage1.strLeftLinePointNum.sigValue.signals.values;
    left_x2 = left_x;
    left_y2 = left_y;
    left_x_solid = left_x;
    left_y_solid = left_y;
    left_x_dash = left_x;
    left_y_dash = left_y;
    left_x_other = left_x;
    left_y_other = left_y;
    left_x_zebra = left_x;
    left_y_zebra = left_y;
    left_valid = cast(bitget(left_attr, 1), 'single');
    left_x = left_x .* left_valid;
    left_y = left_y .* left_valid;
    left_x2(left_valid == 0) = NaN;
    left_y2(left_valid == 0) = NaN;
    left_attr2 = bitand(cast(left_attr, 'uint32'), cast(0x3E, 'uint32'));
    left_x2(left_attr2 ~= 0) = NaN;
    left_y2(left_attr2 ~= 0) = NaN;
    left_attr2 = bitshift(left_attr2, -1);
    is_solid = or(or(or(or(or(or(or(or(or(left_attr2 == 3, left_attr2 == 4), left_attr2 == 7), left_attr2 == 8), left_attr2 == 18), left_attr2 == 20), left_attr2 == 10), left_attr2 == 14), left_attr2 == 12), left_attr2 == 16);
    is_dash = or(or(or(or(or(or(or(or(or(left_attr2 == 1, left_attr2 == 2), left_attr2 == 5), left_attr2 == 6), left_attr2 == 17), left_attr2 == 19), left_attr2 == 9), left_attr2 == 13), left_attr2 == 11), left_attr2 == 15);
    is_other = not(or(or(is_solid, is_dash), left_attr2 == 0));
    left_x_solid(is_solid == 0) = NaN;
    left_y_solid(is_solid == 0) = NaN;
    left_x_dash(is_dash == 0) = NaN;
    left_y_dash(is_dash == 0) = NaN;
    left_x_other(is_other == 0) = NaN;
    left_y_other(is_other == 0) = NaN;

    left_x_long = MpuMessage1.strLineLeftPointPosXLong.sigValue.signals.values;
    left_y_long = MpuMessage1.strLineLeftPointPosYLong.sigValue.signals.values;

    right_x = MpuMessage1.strLineRightPointPosX.sigValue.signals.values;
    right_y = MpuMessage1.strLineRightPointPosY.sigValue.signals.values;
    right_connection = MpuMessage1.strLineRightConnection.sigValue.signals.values;
    right_attr = MpuMessage1.strLineRightAttribute.sigValue.signals.values;
    right_point_num = MpuMessage1.strRightLinePointNum.sigValue.signals.values;
    right_x2 = right_x;
    right_y2 = right_y;
    right_x_solid = right_x;
    right_y_solid = right_y;
    right_x_dash = right_x;
    right_y_dash = right_y;
    right_x_other = right_x;
    right_y_other = right_y;
    right_x_zebra = right_x;
    right_y_zebra = right_y;
    right_valid = cast(bitget(right_attr, 1), 'single');
    right_x = right_x .* right_valid;
    right_y = right_y .* right_valid;
    right_x2(right_valid == 0) = NaN;
    right_y2(right_valid == 0) = NaN;
    right_attr2 = bitand(cast(right_attr, 'uint32'), cast(0x3E, 'uint32'));
    right_x2(right_attr2 ~= 0) = NaN;
    right_y2(right_attr2 ~= 0) = NaN;
    right_attr2 = bitshift(right_attr2, -1);
    is_solid = or(or(or(or(or(or(or(or(or(right_attr2 == 3, right_attr2 == 4), right_attr2 == 7), right_attr2 == 8), right_attr2 == 18), right_attr2 == 20), right_attr2 == 10), right_attr2 == 14), right_attr2 == 11), right_attr2 == 15);
    is_dash = or(or(or(or(or(or(or(or(or(right_attr2 == 1, right_attr2 == 2), right_attr2 == 5), right_attr2 == 6), right_attr2 == 17), right_attr2 == 19), right_attr2 == 9), right_attr2 == 13), right_attr2 == 12), right_attr2 == 16);
    is_other = not(or(or(is_solid, is_dash), right_attr2 == 0));
    right_x_solid(is_solid == 0) = NaN;
    right_y_solid(is_solid == 0) = NaN;
    right_x_dash(is_dash == 0) = NaN;
    right_y_dash(is_dash == 0) = NaN;
    right_x_other(is_other == 0) = NaN;
    right_y_other(is_other == 0) = NaN;

    right_x_long = MpuMessage1.strLineRightPointPosXLong.sigValue.signals.values;
    right_y_long = MpuMessage1.strLineRightPointPosYLong.sigValue.signals.values;

    border_left_x = MpuMessage1.strBoundaryLeftPointX.sigValue.signals.values;
    border_left_y = MpuMessage1.strBoundaryLeftPointY.sigValue.signals.values;
    border_left_point_num = MpuMessage1.strLeftBorderPointNum.sigValue.signals.values;

    border_right_x = MpuMessage1.strBoundaryRightPointX.sigValue.signals.values;
    border_right_y = MpuMessage1.strBoundaryRightPointY.sigValue.signals.values;
    border_right_point_num = MpuMessage1.strRightBorderPointNum.sigValue.signals.values;

    border_left_mul_x = MpuMessage1.strBoundaryLeftMultX.sigValue.signals.values;
    border_left_mul_y = MpuMessage1.strBoundaryLeftMultY.sigValue.signals.values;
    border_left_mul_num = MpuMessage1.strLeftBorderMulPointNum.sigValue.signals.values;

    border_right_mul_x = MpuMessage1.strBoundaryRightMultX.sigValue.signals.values;
    border_right_mul_y = MpuMessage1.strBoundaryRightMultY.sigValue.signals.values;
    border_right_mul_num = MpuMessage1.strRightBorderMulPointNum.sigValue.signals.values;

    left_line_near = MpuMessage1.strLaneNearLLinePntIdx.sigValue.signals.values;
    right_line_near = MpuMessage1.strLaneNearRLinePntIdx.sigValue.signals.values;

    if exist('MpuMessage3', 'var')
        ht_lat = MpuMessage3.htLatitude.signals.values;
        ht_lon = MpuMessage3.htLongitude.signals.values;
    end

    xlimVLow = -20; xlimVHigh = 20;
    ylimVLow = -350; ylimVHigh = 400;

    plotFig;
    frame_h = get(handle(gcf),'JavaFrame');
    set(frame_h,'Maximized',1);
    slider_obj.Value=double( find(abs(LogTime-curPoint)==min(abs(LogTime-curPoint))) );
    ReplotBEV_fig6;

    saveas(fig6,fullfile(pwd,'tmpFig','MPUMapPic.png'));
end
