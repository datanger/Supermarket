%% Chart 1
ax611 = subplot(9,4,4);

plot(ax611,time(cutSmpl4save,1),S_lmVecClineEndX.signals.values(cutSmpl4save,1),'r.-');hold on;
plot(ax611,time(cutSmpl4save,1),S_lmVecClineEndX.signals.values(cutSmpl4save,2),'b.-');hold on;
xline(ax611,time(timeChartIndex));
grid minor;
ax611.YLim = [ 0 100 ];
ax611.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];

plotValue=S_lmVecClineEndX.signals.values(timeChartIndex,1);
plotValue1=S_lmVecClineEndX.signals.values(timeChartIndex,2);
title(ax611,strcat('\color{red}LeftCamEndX:',num2str(plotValue),'  \color{blue}RightCamEndX:',num2str(plotValue1)),'Fontsize',7);

%---------------------------------------------------------------------------------------------------------------------------
%% Chart 2

ax612 = subplot(9,4,8);
plot(ax612,time(cutSmpl4save,1),S_MElaneExistenceProb.signals.values(cutSmpl4save,1),'r.-');hold on;
plot(ax612,time(cutSmpl4save,1),S_MElaneExistenceProb.signals.values(cutSmpl4save,2),'b.-');hold on;
xline(ax612,time(timeChartIndex));
grid minor;
ax612.YLim = [ 0 1 ];
ax612.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
plotValue=S_MElaneExistenceProb.signals.values(timeChartIndex,1);
plotValue1=S_MElaneExistenceProb.signals.values(timeChartIndex,2);
title(ax612,strcat('\color{red}LeftCLineProb:',num2str(plotValue),'  \color{blue}RightCLineProb:',num2str(plotValue1)),'Fontsize',7);

%----------------------------------------------------------------------------------------
%% Chart 3

ax613 = subplot(9,4,12);
plot(ax613,time(cutSmpl4save,1),S_lmVecClineQuality_Cam.signals.values(cutSmpl4save,1),'r.-');hold on;
plot(ax613,time(cutSmpl4save,1),S_lmVecClineQuality_Cam.signals.values(cutSmpl4save,2),'b.-');hold on;
xline(ax613,time(timeChartIndex));
grid minor;
ax613.YLim = [ 0 3.2 ];
ax613.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
yticks( ax613, 0:1:3.2 );

plotValue=S_lmVecClineQuality_Cam.signals.values(timeChartIndex,1);
plotValue1=S_lmVecClineQuality_Cam.signals.values(timeChartIndex,2);
title(ax613,strcat('\color{red}LeftCLineQuality:',num2str(plotValue),'  \color{blue}RightCLineQuality:',num2str(plotValue1)),'Fontsize',7);

%----------------------------------------------------------------------------------------
%% Chart 4
ax614 = subplot(9,4,16);
plot(ax614,time(cutSmpl4save,1),S_MElaneType.signals.values(cutSmpl4save,1),'k.-');hold on;
plot(ax614,time(cutSmpl4save,1),S_MElaneType.signals.values(cutSmpl4save,2),'r.-');hold on;
plot(ax614,time(cutSmpl4save,1),S_MElaneType.signals.values(cutSmpl4save,3),'b.-');hold on;
plot(ax614,time(cutSmpl4save,1),S_MElaneType.signals.values(cutSmpl4save,4),'m.-');hold on;
xline(ax614,time(timeChartIndex));
grid minor;
ax614.YLim = [ 0 11.5 ];
ax614.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
yticks( ax614, 0:2:11.5 );

plotValue=S_MElaneType.signals.values(timeChartIndex,1);
plotValue1=S_MElaneType.signals.values(timeChartIndex,2);
plotValue2=S_MElaneType.signals.values(timeChartIndex,3);
plotValue3=S_MElaneType.signals.values(timeChartIndex,4);
title(ax614,strcat('\color{black}LeftCLineType:',num2str(plotValue),'  \color{red}RightCLineType:',num2str(plotValue1),'  \color{blue}NextLeftCLineType:',num2str(plotValue2),'  \color{magenta}NextRightCLineType:',num2str(plotValue3)),'Fontsize',7);

%----------------------------------------------------------------------------------------
%% Chart 5
ax615 = subplot(9,4,20);
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 1 ),'-');hold on;
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 2 ) * 2,'-');hold on;
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 3 ) * 3,'-');hold on;
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 4 ) * 4,'-');hold on;
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 5 ) * 5,'-');hold on;
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 6 ) * 6,'-');hold on;
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 7 ) * 7,'-');hold on;
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 8 ) * 8,'-');hold on;
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 9 ) * 9,'-r');hold on;
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 10 ) * 10,'-g');hold on;
plot(ax615,time(cutSmpl4save,1),bitget(yrmStt(cutSmpl4save,1), 11 ) * 11,'-k');hold on;
xline(ax615,time(timeChartIndex));
grid minor;
ax615.YLim = [ 0 11.5 ];
ax615.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
yticks( ax615, 0:2:11.5 );
legend(ax615,["elineCam","elineMap","eR","eT","ede","ecnt","ewrongLane","CamLineLostFlg","CamDiffAsapFlg","CamLineLostBothFlg","CamBothErrFlg"],'Location','northoutside','FontSize',8,'NumColumns',2);


%% Chart 6
ax616 = subplot(9,4,24);
plot(ax616,time(cutSmpl4save,1),bitget(lmPldStt(cutSmpl4save,1),17),'-');hold on;
plot(ax616,time(cutSmpl4save,1),bitget(lmPldStt(cutSmpl4save,1),16) * 2,'-');hold on;
plot(ax616,time(cutSmpl4save,1),bitget(lmPldStt(cutSmpl4save,1),6) * 3,'-');hold on;
plot(ax616,time(cutSmpl4save,1),bitget(lmPldStt(cutSmpl4save,1),5) * 4,'-');hold on;
plot(ax616,time(cutSmpl4save,1),bitget(lmPldStt(cutSmpl4save,1),24) * 5,'-');hold on;
plot(ax616,time(cutSmpl4save,1),bitget(lmPldStt(cutSmpl4save,1),25) * 6,'-');hold on;
plot(ax616,time(cutSmpl4save,1),bitget(lmPldStt(cutSmpl4save,1),18) * 7,'-');hold on;
plot(ax616,time(cutSmpl4save,1),bitget(lmPldStt(cutSmpl4save,1),21) * 8,'-r');hold on;
plot(ax616,time(cutSmpl4save,1),bitget(lmPldStt(cutSmpl4save,1),19) * 9,'-g');hold on;
plot(ax616,time(cutSmpl4save,1),bitget(lmPldStt(cutSmpl4save,1),20) * 10,'-k');hold on;
xline(ax616,time(timeChartIndex));
grid minor;
ax616.YLim = [ 0  10.5 ];
ax616.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
yticks( ax616, 0:2:10.5 );
legend(ax616,["724","723","711","710","731","732","725","728","726","727"],'Location','northoutside','FontSize',8,'NumColumns',5);


%% Chart 7
ax617 = subplot(9,4,28);
% diffMpuTimeStamp1=diff(S_mpuTimeStamp_log.mpuTimeStamp1.signals.values);
% diffMpuTimeStamp1=diff(S_mpuTimeStamp_log.signals.values);
% diffMpuTimeStamp1=vertcat(0,diffMpuTimeStamp1);
% plot(ax617,time(cutSmpl4save,1),diffMpuTimeStamp1(cutSmpl4save,1),'b.-');hold on;
xline(ax617,time(timeChartIndex));
grid minor;
% ax617.YLim = [ 0 100 ];
ax617.XLim = [time(min(cutSmpl4save)) time(max(cutSmpl4save))];
% plotValue=diffMpuTimeStamp1(timeChartIndex,1);
title(ax617,strcat('\color{red}mpuTimeStamp1Diff:',num2str(plotValue)),'Fontsize',7);
ax617.Position = [0.7484 0.11 0.1566 0.061];


if ax616.Position(2) > 0.1100
        ax615Left = ax615.Position(1);
        ax615Width = ax615.Position(3);
%         ax615Bottom = 0.3170;
        ax615Bottom = 0.3610;
%         ax615Height = 0.1440;
        ax615Height = 0.095;
        ax615.Position = [ax615Left ax615Bottom ax615Width ax615Height];
        
        ax616Left = ax616.Position(1);
        ax616Width = ax616.Position(3);
%         ax616Bottom = 0.11;
        ax616Bottom = 0.1990;
%         ax616Height = 0.1440;
        ax616Height = 0.095;
        ax616.Position = [ax616Left ax616Bottom ax616Width ax616Height];
        
        
end