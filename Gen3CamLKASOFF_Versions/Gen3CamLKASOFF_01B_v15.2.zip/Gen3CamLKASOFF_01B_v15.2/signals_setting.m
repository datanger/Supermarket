time = Group1Time - Group1Time(1);
lmInhStt = saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmInhStt.signals.values;
eMap = bitget( lmInhStt, 3 );
Spd = sqrt(saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoMovX.signals.values.^2 + saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoMovY.signals.values.^2);
N = length(time);
%% �p�����[�^
samples = length(Group1Time);
LogTime = Group1Time;

LogTimeCam = Group1Time;
samplesCam = length(Group1Time);
CP_operatePuase = 0.1; %�����Đ�/�`��X�V�����B���g���̊��ɍ��킹�ĕύX���Ă��������B

jL    = 500;                                       % MH�n�}�����̓_��
jP    = 500;                                       % PL�Ԑ����S���̓_��
DBG_range = 451;
DBG_range2 = 800;
DBG_range3 = 51;
%%CANape�u������

% LM���Ȉʒu�x�[�X�n�}�����E���S��
mapCtLmX = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntX.signals.values;
mapCtLmY = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntY.signals.values;
mapLtLmX = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntX.signals.values;
mapLtLmY = mapCtLmY + saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntDistToLineL.signals.values;

mapRtLmX = saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntX.signals.values;
mapRtLmY = mapCtLmY + saTldMiBusOut_lmTldMapBusOut_lmMapBusOut_log.lmVecMapLnPntDistToLineR.signals.values;

%�J��������
if isfield(saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log,"lmcmVecCLineX")
      CamX = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmcmVecCLineX.signals.values;
      
      CamY = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmcmVecCLineY.signals.values;
      if all(CamY(:,[101,352]) == 0)
          CamY = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClinePointPosY.signals.values;
      end
      CamProb = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClineProbability.signals.values;
      CamEndX = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClineEndX.signals.values;
      CamType = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClineType.signals.values;
      CamTypeRaw= saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadType.signals.values;
      CamQ = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClineQuality.signals.values;
      CamX2 = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClinePointPosX.signals.values;
      CamY2 = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClinePointPosY.signals.values;
      LMCMSignalExist = 1;
else
    CamX = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClinePointPosX.signals.values;
    CamY = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClinePointPosY.signals.values;
    CamProb = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClineProbability.signals.values;
    CamEndX = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClineEndX.signals.values;
    CamType = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClineType.signals.values;
    CamTypeRaw= saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadType.signals.values;
    CamQ = saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log.lmVecClineQuality.signals.values;
    LMCMSignalExist = 0;
end

% Ctrl�Ԑ�
lmCtrlX = saTldLaneCnvBusOut_saCurrentCtrlBusOut_log.saVecCtrlLnPntX.signals.values;
lmCtrlY = saTldLaneCnvBusOut_saCurrentCtrlBusOut_log.saVecCtrlLnPntY.signals.values;

lmCtrlX = circshift_fillnan(lmCtrlX, -1);
lmCtrlY = circshift_fillnan(lmCtrlY, -1);

row = size(lmCtrlX, 1);

movX = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoMovX.signals.values;
movY =saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoMovY.signals.values;
movRotX = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoRot.signals.values;   

lmodmovX = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmodEgoMovX.signals.values;
lmodmovY = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmodEgoMovY.signals.values;
lmodmovRotX = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmodEgoRot.signals.values;

if all(lmodmovX == 0) && all(lmodmovY == 0) && all(lmodmovRotX == 0)
    lmodmovX = saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveFloat.signals.values(:, 1);
    lmodmovY = saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveFloat.signals.values(:, 2);
    lmodmovRotX = saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveFloat.signals.values(:, 3);

    logFile = fullfile(currentDir,'c0_use_saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.log');
    fileID = fopen(logFile, 'a');
    fprintf(fileID, "c0_use_saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log\n");
    fclose(fileID);

    if all(lmodmovX == 0) && all(lmodmovY == 0) && all(lmodmovRotX == 0)
        lmodmovX = saTldMiBusOut_saTldEgoMovBusOut_saEgo100BusOut_log.saEgoMovX.signals.values;
        lmodmovY = saTldMiBusOut_saTldEgoMovBusOut_saEgo100BusOut_log.saEgoMovY.signals.values;
        lmodmovRotX = saTldMiBusOut_saTldEgoMovBusOut_saEgo100BusOut_log.saEgoRot.signals.values;
        logFile = fullfile(currentDir,'c0_use_saTldMiBusOut_saTldEgoMovBusOut_saEgo100BusOut_log.log');
        fileID = fopen(logFile, 'a');
        fprintf(fileID, "c0_use_saTldMiBusOut_saTldEgoMovBusOut_saEgo100BusOut_log\n");
        fclose(fileID);
    end
end



CamValid = ones(samples,2);
%C0�O�Ղ̍쐬�@�O��50�_
movXmod = modmov(lmodmovX,Group1Time,0.1,0);
movYmod = modmov(lmodmovY,Group1Time,0.1,0);
movRotXmod = modmov(lmodmovRotX,Group1Time,0.1,0);

[c00xb,c00yb,c00bb]= AccumPointsB(zeros(samples,2),[CamY(:,[101,352])],CamValid,500,movXmod,movYmod,movRotXmod);%�����C0�O��
[c00x,c00y,c00b]= AccumPointsForwardB(zeros(samples,2),[CamY(:,[101,352])],CamValid,500,movXmod,movYmod,movRotXmod);%�O����C0�O��

%�O�㍇��
C0x2 = [c00xb, c00x];
C0y2 = [c00yb, c00y];
C0b2 = [c00bb, c00b];

if  isfield("saTldMiBusOut_ahdfCp2ApBusOut_mcApBusOut_log","mcVecOvrdStt")
   mcVecOvrdStt = saTldMiBusOut_ahdfCp2ApBusOut_mcApBusOut_log.mcVecOvrdStt.signals.values;
elseif  isfield("saTldMiBusOut_ahdfCp2ApBusOut_mcApBusOut_log","mcOvrdStt")
   mcVecOvrdStt = saTldMiBusOut_ahdfCp2ApBusOut_mcApBusOut_log.mcOvrdStt.signals.values;
else
   mcVecOvrdStt = zeros(length(Group1Time),1);
end

if exist('saTldMiBusOut_ahdfCp2ApBusOut_vhclBusOut_log', 'var')
    epsVecStrTrq         = saTldMiBusOut_ahdfCp2ApBusOut_vhclBusOut_log.epsVecStrTrq.signals.values; % frazkiAdd3
    smVecSysActivateMode = saTldMiBusOut_ahdfCp2ApBusOut_vhclBusOut_log.smVecSysActivateMode.signals.values;
elseif exist('saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log', 'var')

    if isfield(saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log,"epsVecStrTrq")
        epsVecStrTrq = saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log.epsVecStrTrq.signals.values; % frazkiAdd3
    elseif isfield(saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log,"epsStrTrq")
        epsVecStrTrq = saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log.epsStrTrq.signals.values; % frazkiAdd3
    else
        epsVecStrTrq = zeros(length(Group1Time),1);
    end

    if isfield(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log,"smVecSysActivateMode")
        smVecSysActivateMode = saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smVecSysActivateMode.signals.values;
    elseif isfield(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log,"smSysActivateMode")
    smVecSysActivateMode = saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smSysActivateMode.signals.values;
    else
        smVecSysActivateMode = zeros(length(Group1Time),1);
    end
else
   epsVecStrTrq = zeros(length(Group1Time),1);
    if isfield(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log,"smVecSysActivateMode")
        smVecSysActivateMode = saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smVecSysActivateMode.signals.values;
    elseif isfield(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log,"smSysActivateMode")
    smVecSysActivateMode = saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smSysActivateMode.signals.values;
    else
        smVecSysActivateMode = zeros(length(Group1Time),1);
    end
end

smVecSysActivateMode = circshift_fillnan(smVecSysActivateMode,-2);

StrOverRideStt = bitget(mcVecOvrdStt(:,1),1);
ACCflg = bitget(smVecSysActivateMode,1)*2;
LKASflg = bitget(smVecSysActivateMode,2)*3;
AILDflg = bitget(smVecSysActivateMode,3)*4;



VehicleStt = double(mcVecOvrdStt)*2  +  double(bitget(smVecSysActivateMode,2));
    [kisekixb,kisekiyb,kisekibb]= AccumPointsB(zeros(samplesCam,1),zeros(samplesCam,1),VehicleStt,500,movX,movY,movRotX);%�O����C0�O��
    [kisekix,kisekiy,kisekib]= AccumPointsForwardB(zeros(samplesCam,1),zeros(samplesCam,1),VehicleStt,500,movX,movY,movRotX);%�O����C0�O��

%         VehicleStt = zeros(samplesCam,1);
%             [kisekixb,kisekiyb,kisekibb]= AccumPointsB(zeros(samplesCam,1),zeros(samplesCam,1),VehicleStt,500,movX,movY,movRotX);%�O����C0�O��
%             [kisekix,kisekiy,kisekib]= AccumPointsForwardB(zeros(samplesCam,1),zeros(samplesCam,1),VehicleStt,500,movX,movY,movRotX);%�O����C0�O��



Kx = [kisekix,kisekixb];
Ky = [kisekiy,kisekiyb];
Kb = [kisekib,kisekibb]; 


cC0L = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadC0.signals.values(:,1);
cC0R = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadC0.signals.values(:,2);
cC1L = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadC1.signals.values(:,1);
cC1R = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadC1.signals.values(:,2);
cC2L = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadC2.signals.values(:,1);
cC2R = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadC2.signals.values(:,2);
cC3L = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadC3.signals.values(:,1);
cC3R = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadC3.signals.values(:,2);

cCsttL =  saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadStartX.signals.values(:,1);
cCsttR =  saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadStartX.signals.values(:,2);
cCendL =  saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadEndX.signals.values(:,1);
cCendR =  saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadEndX.signals.values(:,2);

% [ClineXl,ClineYl] = CalcCline(cC0L,cC1L,cC2L,cC3L,cCsttL,cCendL);
% [ClineXr,ClineYr] = CalcCline(cC0R,cC1R,cC2R,cC3R,cCsttR,cCendR);

swUseRawPF = 1;
if swUseRawPF == 1
    % ���W���擾
%             vecObsIDAll = S_pfVecObjId.signals.values;
%             vecObsXAll = S_pfVecObjPosX.signals.values;
%             vecObsYAll = S_pfVecObjPosY.signals.values;
%             vecObsLAll = S_pfVecObjLength.signals.values;
%             vecObsWAll = S_pfVecObjWidth.signals.values;
%             vecObsYawAll = zeros(length(vecObsIDAll),50);
    vecObsIDAll = saTldMiBusOut_pfTldMoBusOut_pfObjBusOut_log.pfVecObjId.signals.values; % 243*100 unit32
    vecObsXAll  = saTldMiBusOut_pfTldMoBusOut_pfObjBusOut_log.pfVecObjPosX.signals.values; % 243*100 single
    vecObsYAll  = saTldMiBusOut_pfTldMoBusOut_pfObjBusOut_log.pfVecObjPosY.signals.values;
    vecObsLAll  = saTldMiBusOut_pfTldMoBusOut_pfObjBusOut_log.pfVecObjLength.signals.values;
    vecObsWAll  = saTldMiBusOut_pfTldMoBusOut_pfObjBusOut_log.pfVecObjWidth.signals.values;
    vecObsYawAll = zeros(length(vecObsIDAll),50);


    % �t���[�X�y�[�X���擾
%             CSpaceR = S_pfVecFspcFusionRange.signals.values;
%             CSpaceTheta = S_pfVecFspcFusionTheta.signals.values;
%             CSpaceClass = S_pfVecFspcFusionClass.signals.values;


    try
        CSpaceR     = saTldMiBusOut_pfTldMoBusOut_pfFspcBusOut_log.pfVecFspcFusionRange.signals.values; % 243*3600 single
        CSpaceTheta = saTldMiBusOut_pfTldMoBusOut_pfFspcBusOut_log.pfVecFspcFusionTheta.signals.values;
        CSpaceClass = saTldMiBusOut_pfTldMoBusOut_pfFspcBusOut_log.pfVecFspcFusionClass.signals.values; % uint8
        
        CamFsCalcX = CSpaceR .* cos(CSpaceTheta);
        CamFsCalcY = CSpaceR .* sin(CSpaceTheta);
        
        CamFsCalcX_sel = zeros(length(CSpaceClass(:,1)),length(CSpaceClass(1,:)));
        CamFsCalcY_sel = zeros(length(CSpaceClass(:,1)),length(CSpaceClass(1,:)));
        
        for k=1:length(CSpaceClass(1,:))
            for i=1:length(CSpaceClass(:,1))
                if CSpaceClass(i,k)==2 || CSpaceClass(i,k)==3
                    CamFsCalcX_sel(i,k) = CamFsCalcX(i,k);
                    CamFsCalcY_sel(i,k) = CamFsCalcY(i,k);
                end
            end
        end
    catch
        CamFsCalcX_sel = zeros(length(Group1Time),1);
        CamFsCalcY_sel = zeros(length(Group1Time),1);
    end
end

% PL����p�X
try
plVecPathX = hdfAp2CpFromSaTldMiBusOut_plTldBusOut_log.plVecPathX.signals.values;
plVecPathY = hdfAp2CpFromSaTldMiBusOut_plTldBusOut_log.plVecPathY.signals.values;
catch
    plVecPathX = saTldMiBusOut_plTldLtBusOut_plltBusOut_log.plltVecPathX.signals.values;
    plVecPathY = saTldMiBusOut_plTldLtBusOut_plltBusOut_log.plltVecPathY.signals.values;
end


function mov = modmov(movraw,time,unitsec,mode)
    tmp = movraw;

    if size(time,1) == 1
        difftime = [0 diff(time)];
    else
        difftime = [0;diff(time)];
    end
    for i = 2:length(movraw)
        if difftime(i) > unitsec
            if mode ==0
                tmp(i) = (movraw(i)*(difftime(i)+ unitsec)   + movraw(i-1)*(difftime(i)-unitsec))/(2*unitsec);
            else
                tmp(i) = movraw(i)*(difftime(i)/unitsec);
            end
        end
    end
    mov = tmp;
end

%%%%% accsample��O��sample�̒l��`�ʂ��邽�߂̊֐�
function  [aX,aY,aB]  = AccumPointsB(sigx,sigy,sigb,accsample,egomoveX,egomoveY,egoMoveRotZ)

    %��sample��
    N = length(sigx(:,1));
    %1sample�̃x�N�g���̑傫��
    unit = length(sigx(1,:));
    % accsample = 20;
    % unit = 40;
    veclength = unit*accsample;
    X = zeros(N,veclength);
    Y = zeros(N,veclength);
    B = zeros(N,veclength);
    %1�ڊi�[
    X(1,1:unit) = sigx(1,1:unit);
    Y(1,1:unit) = sigy(1,1:unit);
    B(1,1:unit) = sigb(1,1:unit);
    for i = 2:N
        %�ŐV�����M�����i�[
        X(i,1:unit) = sigx(i,1:unit);
        Y(i,1:unit) = sigy(i,1:unit);
        B(i,1:unit) = sigb(i,1:unit);
        %1sample�O�̃��O��1sample�O�̓���M������ɍX�V
        %�悸�ԗ����i�������ړ�
        tmpX = X(i-1,1:veclength -unit) - egomoveX(i);
        tmpY = Y(i-1,1:veclength-unit)  - egomoveY(i);
        %�ق�ŃN�����
        X(i,1+unit:veclength) =  tmpX*cos(-egoMoveRotZ(i)) - tmpY*sin(-egoMoveRotZ(i));
        Y(i,1+unit:veclength) =  tmpX*sin(-egoMoveRotZ(i)) + tmpY*cos(-egoMoveRotZ(i));
        B(i,1+unit:veclength) = B(i-1,1:veclength-unit);
    end
    
    
    aX = X;
    aY = Y;
    aB = B;
end

%%%%% accsample����sample�̒l��`�ʂ��邽�߂̊֐�
function  [aX,aY,aB]  = AccumPointsForwardB(sigx,sigy,sigb,accsample,egomoveX,egomoveY,egoMoveRotZ)

    %��sample��
    N = length(sigx(:,1));
    %1sample�̃x�N�g���̑傫��
    unit = length(sigx(1,:));
    % accsample = 20;
    % unit = 40;
    veclength = unit*accsample;
    X = zeros(N,veclength);
    Y = zeros(N,veclength);
    B = zeros(N,veclength);
    %1�ڊi�[
    X(N,1:unit) = sigx(N,1:unit);
    Y(N,1:unit) = sigy(N,1:unit);
    B(N,1:unit) = sigb(N,1:unit);
    for iv = 1:N-1
        i= N -iv;
    
        %�ŐV�����M�����i�[
        X(i,1:unit) = sigx(i,1:unit);
        Y(i,1:unit) = sigy(i,1:unit);
        B(i,1:unit) = sigb(i,1:unit);
        %1sample�O�̃��O��1sample�O�̓���M������ɍX�V
        %�悸�N����
        tmpX = X(i+1,1:veclength-unit)*cos(egoMoveRotZ(i+1)) - Y(i+1,1:veclength-unit)*sin(egoMoveRotZ(i+1));
        tmpY = X(i+1,1:veclength-unit)*sin(egoMoveRotZ(i+1)) + Y(i+1,1:veclength-unit)*cos(egoMoveRotZ(i+1));
        %�ق�ŕ��i
        X(i,unit+1:veclength) =  tmpX + egomoveX(i+1);
        Y(i,unit+1:veclength) =  tmpY + egomoveY(i+1);
        B(i,unit+1:veclength) =  B(i+1,1:veclength-unit);
    end
    aX = X;
    aY = Y;
    aB = B;
end

function [X,Y] = CalcCline(C0,C1,C2,C3,St,Ed)
    Xv = [0:100];
    Xm = repmat(Xv, length(C0), 1);
    Xm3 = Xm.*Xm.*Xm;
    Xm2 = Xm.*Xm;
    Ym = C3.*Xm3 + C2.*Xm2+ C1.*Xm + C0.*ones(length(C0),101);
    X = zeros(length(Xm),101);
    Y = zeros(length(Xm),101);
    for i  =1:length(C0)
        X(i,:) = Xm(i,:).*double(St(i) <Xm(i,:));
        X(i,:) = Xm(i,:).*double(Ed(i) >Xm(i,:));
        Y(i,:) = Ym(i,:).*double(St(i) <Xm(i,:));
        Y(i,:) = Ym(i,:).*double(Ed(i) >Xm(i,:));
    end
end
