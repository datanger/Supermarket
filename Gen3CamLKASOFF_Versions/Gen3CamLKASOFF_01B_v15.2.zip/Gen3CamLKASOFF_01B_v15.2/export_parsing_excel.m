
fprintf("making lkas off analysis excel...\n")
tmpFigPath = fullfile(currentDir,'tmpFig');
if ~exist(tmpFigPath,'dir')
    mkdir(tmpFigPath)
end

issue_point_data = readtable(fullfile(currentDir,"issueList",dataDate+"_LKASOFF.xlsx"), 'ReadVariableNames', false, 'Sheet', 1);


all_file = ["�p�^�[��A.xlsx","�p�^�[��B.xlsx","�p�^�[��C.xlsx","�p�^�[��DEF.xlsx","�p�^�[��Other.xlsx"];



all_parapara = dir(fullfile(currentDir,"ParaSave","*","*","*.png"));



for f_i = 1:length(all_file)
    if exist(fullfile(currentDir, dataDate,all_file(f_i)), 'file')
        delete(fullfile(currentDir, dataDate,all_file(f_i)))
    end
    excel = actxserver('Excel.Application');
    excel.Visible = 0;
    workbook = excel.Workbooks.Add;

    add_flg = 0;

    i=0;
    for col = 1:width(issue_point_data)
        plus_name =  string(issue_point_data{1, col});
        if data_ver == 2 %360+
            if sliceData == 0
                load(fullfile(dataFolder,plus_name,regexprep(plus_name, '_Plus\d+', '')+'_ACore_XCP_remap.mat'),'saTldMiBusOut_MPU_message4BusOut_log','Group2Time');
                longitude = saTldMiBusOut_MPU_message4BusOut_log.gnssLongitude.signals.values;
                latitude = saTldMiBusOut_MPU_message4BusOut_log.gnssLatitude.signals.values;
            else
                load(fullfile(dataFolder,'M'+regexprep(plus_name, '_Plus\d+', '')+'_ACore_XCP_remap.mat'),'saTldMiBusOut_MPU_message4BusOut_log','Group2Time');
                longitude = saTldMiBusOut_MPU_message4BusOut_log.gnssLongitude.signals.values;
                latitude = saTldMiBusOut_MPU_message4BusOut_log.gnssLatitude.signals.values;
            end
        elseif data_ver == 1 %360
            if sliceData == 0
                try
                    load(fullfile(dataFolder,plus_name,regexprep(plus_name, '_Plus\d+', '')+'_ACore_XCP_remap.mat'),'saTldMiBusOut_sdmapMmInfoBusOut_log');
                    if exist('saTldMiBusOut_sdmapMmInfoBusOut_log','var')
                        logFile = fullfile(currentDir,'find_saTldMiBusOut_sdmapMmInfoBusOut.log');
                        fileID = fopen(logFile, 'a');
                        fprintf(fileID, "find_saTldMiBusOut_sdmapMmInfoBusOut\n");
                        fclose(fileID);
                    end
                catch ME
                end
                load(fullfile(dataFolder,plus_name,regexprep(plus_name, '_Plus\d+', '')+'_ACore_XCP_remap.mat'),'saTldMiBusOut_MPU_message4BusOut_log','Group2Time');
                longitude = saTldMiBusOut_MPU_message4BusOut_log.gnssLongitude.signals.values;
                latitude = saTldMiBusOut_MPU_message4BusOut_log.gnssLatitude.signals.values;
            else
                try
                    load(fullfile(dataFolder,'M'+regexprep(plus_name, '_Plus\d+', '')+'_ACore_XCP_remap.mat'),'saTldMiBusOut_sdmapMmInfoBusOut_log');
                    if exist('saTldMiBusOut_sdmapMmInfoBusOut_log','var')
                        logFile = fullfile(currentDir,'find_saTldMiBusOut_sdmapMmInfoBusOut.log');
                        fileID = fopen(logFile, 'a');
                        fprintf(fileID, "find_saTldMiBusOut_sdmapMmInfoBusOut\n");
                        fclose(fileID);
                    end
                catch ME
                end
                load(fullfile(dataFolder,'M'+regexprep(plus_name, '_Plus\d+', '')+'_ACore_XCP_remap.mat'),'saTldMiBusOut_MPU_message4BusOut_log','Group2Time');
                longitude = saTldMiBusOut_MPU_message4BusOut_log.gnssLongitude.signals.values;
                latitude = saTldMiBusOut_MPU_message4BusOut_log.gnssLatitude.signals.values;
            end
            
        end
    
        for row = 3:height(issue_point_data)
            
    
            cell_value = issue_point_data{row, col};
            
    
            if ismissing(cell_value) || isempty(cell_value) || (ischar(cell_value) && isempty(strtrim(cell_value)))
                break;  
            else
                issue_time = strsplit(string(cell_value),"#");
                issue_time = replace(replace(issue_time{3},"time_",""),"[sec].png","");
                patern_name = strsplit(string(cell_value),"#");
                patern_name = string(patern_name{2});

                if patern_name+".xlsx" ~= all_file(f_i)
                    continue
                end
                add_flg = 1;
                fprintf("processing:" + plus_name + ":" +string(row-2) +  "\n");
                
                mf4_extracted = strsplit(string(cell_value),"#");
                mf4_extracted = string(mf4_extracted{4});

                expressway_flg = strsplit(string(cell_value),"#");
                express_flg_input = "";
                if length(expressway_flg) == 5
                    if expressway_flg(5) == "1"
                        express_flg_input = "�Z";
                    elseif expressway_flg(5) == "0"
                        express_flg_input = "�~";
                    end
                end

                sheet_name = mf4_extracted+"_"+mod(str2double(issue_time),VideoTimeInterval);
                
                i=i+1;
    
                if i == 1
                    worksheet = workbook.Worksheets.Item(1);
                else
                    worksheet = workbook.Worksheets.Add([], workbook.Worksheets.Item(workbook.Worksheets.Count));
                end
                
            
                worksheet.Name = sheet_name;
            
                Shapes = worksheet.Shapes;
                
                current_plus_parapara_folder = "";
                current_plus_parapara = strings(0, 1);
                for k = 1:length(all_parapara)
                    if contains(all_parapara(k).folder,plus_name+"\")
                        if strcmp(all_parapara(k).name, sprintf('time_%0.2f[sec].png',str2double(issue_time)))
                            current_plus_parapara_folder = all_parapara(k).folder;
                        end
                        
                        current_plus_parapara(end+1) = all_parapara(k).name;
                    end
                end
    
                % sort
                numbers = cellfun(@(x) str2double(strrep(strrep(x, 'time_', ''),'[sec].png','')), current_plus_parapara);
                [~, sorted_idx] = sort(numbers);
                sorted_current_plus_parapara = current_plus_parapara(sorted_idx);
    
                issuetime_1_idx = 0;
                for k = 1:length(sorted_current_plus_parapara)
                    if contains(sorted_current_plus_parapara(k),sprintf('time_%0.2f[sec].png',str2double(issue_time)))
                        issuetime_1_idx = k;
                        break
                    end
                end
    
    
                issuetime_1 = fullfile(current_plus_parapara_folder,sprintf('time_%0.2f[sec].png',str2double(issue_time)));
                issuetime_0 = "";
                if issuetime_1_idx>1
                    issuetime_0 = fullfile(current_plus_parapara_folder,sorted_current_plus_parapara(k-1));
                end
                
    
    
                worksheet.Range("AB2").value = "Date";
                worksheet.Range("AC2").value = regexprep(plus_name, '_Plus\d+', '');
    
    
                worksheet.Range("AB3").value = "�p�^�[��";
                worksheet.Range("AC3").value = patern_name;
    
                worksheet.Range("AB4").value = "MF4 File Name";
                
%                 mf4_file_name = '';
% 
%                 if mf4_file_list ~= 0
%                     load(mf4_file_list);
%                     dateTime = string(regexprep(plus_name, '_Plus\d+', ''));
%                     for n = 1:length(Blf_date_list)
%                         if Blf_date_list(n) == dateTime
% 	                        num = ceil(str2double(issue_time)/VideoTimeInterval);
%                             mf4_file_name = strcat(Blf_date_list(n+num-1),'_ACore_XCP_remap.mat');
%                             break;
%                         end
%                     end
%                 elseif blf_dataFolder ~= 0
%                     all_acore = dir(fullfile(blf_dataFolder,'*ACore_XCP.mf4'));
%                     for i = 1:length(all_acore)
%                         if contains(all_acore(i).name,regexprep(plus_name, '_Plus\d+', ''))
%                             mf4_file_name = all_acore(i+floor(str2double(issue_time)/VideoTimeInterval)).name;
%                             break
%                         end
%                     end
%                 end

                worksheet.Range("AC4").value = strcat(mf4_extracted,'_ACore_XCP_remap.mat');

                if sliceData == 0
                    blf_time = string(regexprep(plus_name, '_Plus\d+', ''));
                    mf4_time = string(mf4_extracted);
                    add_time = str2double(issue_time);
                    add_divide = VideoTimeInterval;
                    blf_time_dt_add = datetime(blf_time, 'InputFormat', 'yyyyMMdd_HHmmss') + seconds(fix(add_time/add_divide) * add_divide);
                    mf4_time_dt = datetime(mf4_time, 'InputFormat', 'yyyyMMdd_HHmmss');
                    timeoffset = seconds(blf_time_dt_add - mf4_time_dt);
                    if abs(timeoffset) > 120
                        cell_AC4 = worksheet.Range("AC4");
                        cell_AC4.Interior.Color = 255; 
                    end
                end
    
                worksheet.Range("AB5").value = "MF4 system limit time(sec)";
                worksheet.Range("AC5").value = mod(str2double(issue_time),VideoTimeInterval);
    
    
%                 worksheet.Range("AB6").value = "BLF File Name";
%                 worksheet.Range("AC6").value = plus_name;
    
    
%                 worksheet.Range("AB7").value = "BLF system limit time(sec)";
%                 worksheet.Range("AC7").value = issue_time;
    
    
                weather = ["Sunny","Cloudy","Rainy","Snowy","Fog","Heavy Sun/Light Glaring","Night","Other"];
                objectLabel = ["Side Branch","Ego Branch","Side Merge","Ego Merge","Increase","Decrease","Tunnel", ...
                    "Tunnel Entrance/Exit","Construction","Small R Curve","Undivided","Undivided(temp)","Toll Gate", ...
                    "JCT","PA/SA","Ordinary Road","Other","Ego HOV Lane"];
                surfaceCondition = ["Shadow","Repair Blend/Crack","Puddle","Snow","Light Reflection","Road Paint","Other"];
                vehicleCondition = ["Cut In/Cut Out","Ego Lane Change","Other"];
                objectCondition = ["Pylon","Human","Other"];
                lineCategory = ["Solid or Dashed","Deceleration","Double Line","Zebra","Wide Dashed","Botts Dots","Other"];
                lineColor = ["White","Yellow","Other"];
                lineCondition = ["Clear","Unclear","None"];
                worksheet.Range("AZ1:AZ8").Value = transpose(cellstr(weather));
                worksheet.Range("AZ9:AZ26").Value = transpose(cellstr(objectLabel));
                worksheet.Range("AZ27:AZ33").Value = transpose(cellstr(surfaceCondition));
                worksheet.Range("AZ34:AZ36").Value = transpose(cellstr(vehicleCondition));
                worksheet.Range("AZ37:AZ39").Value = transpose(cellstr(objectCondition));
                worksheet.Range("AZ40:AZ46").Value = transpose(cellstr(lineCategory));
                worksheet.Range("AZ47:AZ49").Value = transpose(cellstr(lineColor));
                worksheet.Range("AZ50:AZ52").Value = transpose(cellstr(lineCondition));
                switch all_file(f_i)
                    case "�p�^�[��A.xlsx"
                        worksheet.Range("AZ53:AZ55").Value = cellstr(["A-1";"A-2";"A-3"]);
                        range = worksheet.Range("AC22");
                        range.Validation.Delete;
                        range.Validation.Add(3, 1, 1, '=$AZ53:AZ55');
                        range.Validation.InCellDropdown = true;
                    case "�p�^�[��B.xlsx"
                        worksheet.Range("AZ53:AZ54").Value = cellstr(["B-1";"B-2"]);
                        range = worksheet.Range("AC22");
                        range.Validation.Delete;
                        range.Validation.Add(3, 1, 1, '=$AZ53:AZ54');
                        range.Validation.InCellDropdown = true;
                    case "�p�^�[��C.xlsx"
                    case "�p�^�[��DEF.xlsx"
                        worksheet.Range("AZ53:AZ67").Value = cellstr(["D-1";"D-2";"F-1";"Z-2"; ...
                            "E-1";"E-2";"E-3";"E-4";"E-5";"E-6";"E-7";"E-8";"E-9";"E-10";"E-11"]);
                        range = worksheet.Range("AC22");
                        range.Validation.Delete;
                        range.Validation.Add(3, 1, 1, '=$AZ53:AZ67');
                        range.Validation.InCellDropdown = true;
                    case "�p�^�[��Other.xlsx"
                end

                range = worksheet.Range("AZ:AZ");
                range.Columns(1).Hidden = true;


                range = worksheet.Range("AC8");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ1:AZ8');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC9");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ9:AZ26');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC10");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ9:AZ26');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC11");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ9:AZ26');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC12");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ27:AZ33');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC13");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ27:AZ33');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC14");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ34:AZ36');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC15");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ34:AZ36');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC16");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ37:AZ39');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC17");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ37:AZ39');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC18");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ40:AZ46');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC19");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ47:AZ49');
                range.Validation.InCellDropdown = true;

                range = worksheet.Range("AC20");
                range.Validation.Delete;
                range.Validation.Add(3, 1, 1, '=$AZ50:AZ52');
                range.Validation.InCellDropdown = true;
                
                worksheet.Range("AB6").value = "���� Soft Ver.";
                worksheet.Range("AC6").value = soft_ver;
    
                worksheet.Range("AB7").value = "�ԑ�[km/h]";
                speed = strsplit(string(cell_value),"#");
                speed = speed{1};
                worksheet.Range("AC7").value = speed;
    
                worksheet.Range("AB8").value = "�V�C";
                worksheet.Range("AB9").value = "�C�x���g���P";
                worksheet.Range("AB10").value = "�C�x���g���Q";
                worksheet.Range("AB11").value = "�C�x���g���R";
                worksheet.Range("AB12").value = "�H�ʏ�ԂP";
                worksheet.Range("AB13").value = "�H�ʏ�ԂQ";
                worksheet.Range("AB14").value = "�ԗ��󋵂P";
                worksheet.Range("AB15").value = "�ԗ��󋵂Q";
                worksheet.Range("AB16").value = "���W�󋵂P";
                worksheet.Range("AB17").value = "���W�󋵂Q";
                worksheet.Range("AB18").value = "�������";
                worksheet.Range("AB19").value = "�����F";
                worksheet.Range("AB20").value = "�������";
    
                worksheet.Range("AB21").value = "Google Map Link";

                [~, oi] = min(abs(mod(Group2Time,VideoTimeInterval) - str2double(issue_time)));
                GoogleMapLink = strcat("https://maps.google.com/maps?q=",num2str(latitude(oi),'%.20g')," ",num2str(longitude(oi),'%.20g'));
                displayLink = strcat("'",num2str(latitude(oi),'%.20g'),',',num2str(longitude(oi),'%.20g'));
                
                obj = worksheet.Range("AC21");
                obj.Hyperlinks.Add(obj, GoogleMapLink,"","", displayLink);
        
                worksheet.Range("AB22").value = "1����͕��ތ���";
                worksheet.Range("AB23").value = "2����͕��ތ���";

                worksheet.Range("AB24").value = "���l��";
                worksheet.Range("AB25").value = "�f�[�^����";
                if data_ver == 1
                    worksheet.Range("AC25").value = "360";
                elseif data_ver == 2
                    worksheet.Range("AC25").value = "360+";
                end

                worksheet.Range("AB26").value = "�������H����(�Z/�~)";
                worksheet.Range("AC26").value = express_flg_input;
%                 ctrl_judge = ['�אڎԐ���Ctrl�Ԑ����o�Ă��Ȃ�', char(10), '/�ُ�̏ꍇ�Ɂ~���L��'];
%                 worksheet.Range("AB27").value = ctrl_judge;
            
            %     worksheet.Range("AE1").value = "�ŐV�\�t�g(BLFwithMF4)";
            %     worksheet.Range("AW1").value = "���ԃ\�t�g(BLFwithMF4)";
                
            %     worksheet.Range("AC2").value = '';
            %     worksheet.Range("AC3").value = '';
            %     worksheet.Range("AC4").value = '';
            %     worksheet.Range("AC5").value = '';
            %     worksheet.Range("AC6").value = "-";
            %   
            %     worksheet.Range("AC7").value = "-";
            %     worksheet.Range("AC8").value = '';
            %     worksheet.Range("AC10").value = '';
            % 
            %     worksheet.Range("AC12").value = '';
                
                worksheet.Range("AC2:AC26").HorizontalAlignment = -4131;
                worksheet.Range("AB:AC").EntireColumn.AutoFit;  
                worksheet.Range("AB2:AB26").Interior.ColorIndex = 38;        
                worksheet.Range("AB2:AC26").Borders.LineStyle = 1;
                worksheet.Range("AB:AB").ColumnWidth = 32;
            %     Range = worksheet.Range("AE1:AU1");
            %     Range.Font.Size = 14;
            %     Range.Interior.Color = int32(hex2dec('b8b644'));
            %     Range.Font.Bold=true;
            %     Range = worksheet.Range("AW1:BM1");
            %     Range.Font.Size = 14;
            %     Range.Interior.Color = int32(hex2dec('b8b644'));
            %     Range.Font.Bold=true;
            
                if issuetime_0 ~= "" && exist(issuetime_0,'file')
                        shape = Shapes.AddPicture(issuetime_0,0,1,1,1,1,1);
                        shape.Left = worksheet.Range( strcat('A2',':','Q33') ).Left;
                        shape.Top = worksheet.Range( strcat('A2',':','Q33') ).Top;
                        shape.Width = worksheet.Range( strcat('A2',':','Q33') ).Width;
                        shape.Height = worksheet.Range( strcat('A2',':','Q33') ).Height;
                end
                if exist(issuetime_1,'file')
                        shape = Shapes.AddPicture(issuetime_1,0,1,1,1,1,1);
                        shape.Left = worksheet.Range( strcat('A35',':','Q66') ).Left;
                        shape.Top = worksheet.Range( strcat('A35',':','Q66') ).Top;
                        shape.Width = worksheet.Range( strcat('A35',':','Q66') ).Width;
                        shape.Height = worksheet.Range( strcat('S35',':','Z66') ).Height;
                end
                if sliceData
                    allAviFiles = dir(fullfile(dataFolder, '*.avi'));
                    aviFileNames = {allAviFiles.name}; 
                    aviFilesIdx = endsWith(aviFileNames, 'front.avi', 'IgnoreCase', true);
                    aviFiles = allAviFiles(aviFilesIdx);
                    [aviMatchName, aviMatchResult] = matchAviFile1(aviFiles,mf4_extracted);
                else
                    allAviFiles = dir(fullfile(dataFolder, '*.avi'));
                    aviFileNames = {allAviFiles.name}; 
                    aviFilesIdx = endsWith(aviFileNames, 'front.avi', 'IgnoreCase', true);
                    aviFiles = allAviFiles(aviFilesIdx);
                    [aviMatchName, aviMatchResult] = matchAviFile(aviFiles,str2double(issue_time),regexprep(plus_name, '_Plus\d+', ''),VideoTimeInterval);
                end
                
                if aviMatchResult == 1
                    if sliceData
                        avi_path = fullfile(dataFolder,aviMatchName);
                    else
                        avi_path = fullfile(dataFolder,plus_name,aviMatchName);
                    end
                    videoPoint1 = mod(str2double(issue_time),VideoTimeInterval);
	                videoPoint2 = mod(str2double(issue_time)-0.1,VideoTimeInterval);
        
                    fig1 = PlotFrontCam(videoPoint1,avi_path);
                    fig2 = PlotFrontCam(videoPoint2,avi_path);
                    
                    saveas(fig1,fullfile(tmpFigPath,'CamFig1.jpg'));
                    saveas(fig2,fullfile(tmpFigPath,'CamFig2.jpg'));
        
                    shape = Shapes.AddPicture(fullfile(tmpFigPath,'CamFig2.jpg'),0,1,1,1,1,1);
                    shape.Left = worksheet.Range( strcat('S2',':','Z33') ).Left;
                    shape.Top = worksheet.Range( strcat('S2',':','Z33') ).Top;
                    shape.Width = worksheet.Range( strcat('S2',':','Z33') ).Width;
                    shape.Height = worksheet.Range( strcat('S2',':','Z33') ).Height;
                    shape = Shapes.AddPicture(fullfile(tmpFigPath,'CamFig1.jpg'),0,1,1,1,1,1);
                    shape.Left = worksheet.Range( strcat('S35',':','Z66') ).Left;
                    shape.Top = worksheet.Range( strcat('S35',':','Z66') ).Top;
                    shape.Width = worksheet.Range( strcat('S35',':','Z66') ).Width;
                    shape.Height = worksheet.Range( strcat('S35',':','Z66') ).Height;
                else
                    worksheet.Range("V2").value = "No WebCam";
                    worksheet.Range("V35").value = "No WebCam";
                end
                
            end
        end
    end


    
    if ~exist(fullfile(currentDir,dataDate),'dir')
        mkdir(fullfile(currentDir,dataDate));
    end
    % �ꎟ���ۑ���������
    
    workbook.SaveAs(fullfile(currentDir,dataDate,all_file(f_i)));
    
    % ����?��
    workbook.Close(false);
    excel.Quit;
    delete(excel);

    if add_flg==0
        delete(fullfile(currentDir,dataDate,all_file(f_i)))
    end
end




function [aviName, aviMatchResult] = matchAviFile(aviDir,curPoint,acoreName,VideoTimeInterval)
    
    names = {aviDir.name};
    [~, idx] = sort(names);
    aviDir = aviDir(idx);

    videoTotalTime = 0;
    aviMatchResult = 0;
    aviName = 0;

    if isempty(aviDir)
        return;
    end
    startTime = string(strrep(acoreName,'_ACore_XCP_remap.mat',''));
    startTime = datetime(startTime,'InputFormat','yyyyMMdd_HHmmss');


    for k = 1:length(aviDir)
        aviName = aviDir(k).name;
        aviFolder = aviDir(k).folder;
        aviPath = fullfile(aviFolder,aviName);

        v = VideoReader(aviPath);
        videotime = v.Duration;
        videoTotalTime = videoTotalTime + videotime;
    
        if contains(aviDir(1).name, '_AXIS_FRONT.avi')
            curTime = string(strrep(aviDir(k).name,'_AXIS_FRONT.avi',''));
            curTime = datetime(curTime,'InputFormat','yyyyMMdd_HHmmss');
            calculateTime = curTime + duration(0,0,mod(curPoint,VideoTimeInterval)) - startTime;
        elseif contains(aviDir(1).name, '_AXIS_Front.avi')
            curTime = string(strrep(aviDir(k).name,'_AXIS_Front.avi',''));
            curTime = datetime(curTime,'InputFormat','yyyyMMdd_HHmmss');
            calculateTime = curTime + duration(0,0,mod(curPoint,VideoTimeInterval)) - startTime;
        else
            curTime = string(strrep(aviDir(k).name,'_Axis_Camera_Front.avi',''));
            curTime = datetime(curTime,'InputFormat','yyyyMMdd_HHmmss');
            calculateTime = curTime + duration(0,0,mod(curPoint,VideoTimeInterval)) - startTime;
        end
        
%         if curPoint <= videoTotalTime && abs(curPoint - seconds(calculateTime)) < 120
        if abs(curPoint - seconds(calculateTime)) < 120
            aviMatchResult = 1;
            break;
        end
    end
end


function fig = PlotFrontCam(pointTime,videoPath)

    v = VideoReader(videoPath);
    videotime = v.Duration;
    [~,chkMovieFileName,~] = fileparts(videoPath);
    fig = figure('Visible',0);
    ax1 = subplot('Position',[.1 .15 .8 .8]);
    fig.Position = [0 0 1366 768];
    % Take screen shoot when error codes are triggered
    movieSetTime = round(pointTime,2);
    if movieSetTime<videotime
        v.currenttime = movieSetTime;
    else
        v.currenttime = videotime - 0.1;
        warning(string(movieSetTime));
        warning(videoPath);
    end
    vidFrame = readFrame(v);
    image(ax1,vidFrame);
    set(ax1,'xtick',[],'ytick',[]);
    hold on;
    nowtime = strcat(strrep(chkMovieFileName,'_','\_'),...
                     ', Time = ',num2str(pointTime));
    title(ax1,nowtime);
    set(ax1,'FontSize',22,'Visible',1);
    ax1.TitleFontSizeMultiplier = 1;
end

function [aviMatchName, aviMatchResult] = matchAviFile1(aviFiles, mf4_extracted)
    aviMatchName = '';
    aviMatchResult = 0;
    
    if isempty(aviFiles)
        return;
    end
    
    % ��揊�Lavi�����I??�F�i�O15�������j
    aviTimestamps = cellfun(@(x) x(1:min(15,length(x))), {aviFiles.name}, 'UniformOutput', false);
    
    % ???datetime
    try
        aviDatetimes = datetime(aviTimestamps, 'InputFormat', 'yyyyMMdd_HHmmss');
        mf4Datetime = datetime(mf4_extracted, 'InputFormat', 'yyyyMMdd_HHmmss');
    catch
        return;
    end
    
    % ?�Z??����Q���ŏ�?
    timeDiffs = seconds(abs(aviDatetimes - mf4Datetime));
    [minDiff, minIdx] = min(timeDiffs);
    
    if minDiff < 150
        aviMatchResult = 1;
    end
    
    aviMatchName = aviFiles(minIdx).name;
end
