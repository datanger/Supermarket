

%% PARAPARAMODE 0: viewer, 1: create pptx
%% %%%%%%%%%%%%%%%%% P: �ݒ� %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global XlimUpperEdit XlimLowerEdit YlimUpperEdit YlimLowerEdit slider_obj ax1 jumpbutton_value

saveBEVbuttonFlg = 0;
startTimeEdit = nan;
endTimeEdit = nan;
saveBEVPathEdit = "";
PARAPARAMODE =0;
FrazkiFlg = 0;
fileN = 1;
Offset =1;
signals_setting;


%% range
% ax1
xlimVLow = -10; xlimVHigh = 10;
ylimVLow = -40; ylimVHigh = 100;

%% A. Data Load and Modification End %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% B. View Style Definition Start %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% figure��`
%         afig = figure(1001); clf;
%         pause(0.00001);
%         frame_h = get(handle(gcf),'JavaFrame');
%         set(frame_h,'Maximized',1);
%         fig1=figure(1001);

Fig.fig = figure(666666);
set(Fig.fig, 'Units', 'normalized', 'Position', [0 0 1 1]);
clf(Fig.fig);
% Fig.fig.Position = [100,50,1440,810];
%%% �ϐ���`
Fig.xlimVHigh = 10;
Fig.xlimVLow = -10;
Fig.ylimVHigh = 200;
Fig.ylimVLow = -200;

%%% �X���C�_�[�쐬
slider_obj = uicontrol('style','slider', 'Units','normalized',...
    'Tag', 'slider', 'Callback', {@viewerMF4_callback},...
    'min',1,'max',samples, 'Value',1, 'SliderStep',[1/samples 100/samples]);
slider_obj.Position = [0.05 0.02 0.4 0.05];

%�W�����v�{�^������
TimeJumperEdit = uicontrol('Style','edit', 'Units','normalized' ,'Position',[.83 .05 .05 .03], 'String',LogTime(1), 'FontSize',10);
button_jumper = uicontrol('Style','pushbutton', 'String','��RightClicktoJump',...
    'Units','normalized', 'Position',[.83 .01 .05 .03], 'FontSize',8,...
    'ButtonDownFcn',@jumpbutton);
set(button_jumper,'ButtonDownFcn',@jumpbutton);
jumpbutton_value = 0;

%����ۑ��{�^��
  button_saveBEV = uicontrol('Style','pushbutton', 'String','���搶��',...
    'Units','normalized', 'Position',[.9 .01 .05 .03], 'FontSize',8,...
    'Callback', @(src, event) saveBEVbutton);

%�����Đ��`�F�b�N�{�b�N�X
chkbox_autoPlayMode = uicontrol('Style','checkbox','String','�����Đ�','Units','normalized','FontSize',10,'Value',0,'Position',[.51 .01 .05 .03]);
chkbox_autoRange = uicontrol('Style','checkbox','String','�����W�ݒ�','Units','normalized','FontSize',10,'Value',1,'Position',[.51 .04 .05 .03]);
%�\���`�F�b�N�{�b�N�X
chkbox_CenterMapEgo  = uicontrol('Style','checkbox','String','MapEgo','Units','normalized','FontSize',10,'Value',1,'Position',[.78 .055 .05 .03]);
chkbox_CenterCtrl = uicontrol('Style','checkbox','String','Ctrl','Units','normalized','FontSize',10,'Value',1,'Position',[.73 .055 .05 .03]);
chkbox_CenterMap = uicontrol('Style','checkbox','String','Map','Units','normalized','FontSize',10,'Value',1,'Position',[.68 .055 .05 .03]);

chkbox_line_cam = uicontrol('Style','checkbox','String','�J��������','Units','normalized','FontSize',10,'Value',1,'Position',[.78 .03 .05 .025]);
chkbox_line_Map = uicontrol('Style','checkbox','String','�n�}����','Units','normalized','FontSize',10,'Value',1,'Position',[.73 .03 .05 .025]);
chkbox_MH_Out = uicontrol('Style','checkbox','String','LM����','Units','normalized','FontSize',10,'Value',0,'Position',[.68 .03 .05 .025]);

chkbox_Pf_Obj = uicontrol('Style','checkbox','String','���W','Units','normalized','FontSize',10,'Value',1,'Position',[.68 .007 .05 .025]);
chkbox_Pf_Fsp = uicontrol('Style','checkbox','String','FSP','Units','normalized','FontSize',10,'Value',1,'Position',[.73 .007 .05 .025]);

%���ԕ\��
LogInfoPanel = uipanel('Position',[.0 .97 .5 .03]);
TimeInfoTextBox = annotation(LogInfoPanel, 'textbox', 'Position',[.02 .95 .7 0], 'LineStyle','none',...
    'String',sprintf('dummy'),...
    'FontSize',10);
LocBox = uicontrol(LogInfoPanel, 'Style','edit', 'Units','normalized' ,'Position',[.75 .0 .2 1], 'String',1, 'FontSize',10);


%% �O���t��xlim/ylim�ݒ�p
PlotLimPanel = uipanel('Position',[.57 .001 .1 .08], 'Title','�v���b�g�͈͐ݒ�');
XlimLowerTextBox = annotation(PlotLimPanel,'textbox', 'Position',[.02 .52 .2 .4], 'String','Xmin', 'LineStyle','none', 'FontSize',10);
XlimLowerEdit = uicontrol(PlotLimPanel,'Style','edit', 'Units','normalized' ,'Position',[.3 .52 .2 .4], 'String',num2str(ylimVLow), 'FontSize',10);
XlimUpperTextBox = annotation(PlotLimPanel,'textbox', 'Position',[.5 .52 .2 .4], 'String','Xmax', 'LineStyle','none', 'FontSize',10);
XlimUpperEdit = uicontrol(PlotLimPanel,'Style','edit', 'Units','normalized' ,'Position',[.8 .52 .2 .4], 'String',num2str(ylimVHigh), 'FontSize',10);
YlimLowerTextBox = annotation(PlotLimPanel,'textbox', 'Position',[.02 .02 .2 .4], 'String','Ymin', 'LineStyle','none', 'FontSize',10);
YlimLowerEdit = uicontrol(PlotLimPanel,'Style','edit', 'Units','normalized' ,'Position',[.3 .02 .2 .4], 'String',num2str(xlimVLow), 'FontSize',10);
YlimUpperTextBox = annotation(PlotLimPanel,'textbox', 'Position',[.5 .02 .2 .4], 'String','Ymax', 'LineStyle','none', 'FontSize',10);
YlimUpperEdit = uicontrol(PlotLimPanel,'Style','edit', 'Units','normalized' ,'Position',[.8 .02 .2 .4], 'String',num2str(xlimVHigh), 'FontSize',10);            

timeChartIndex = 1;
titleCommonOption = {...
    'Units', 'normalized',...
    'Position',[0.5, 1.01],...
    'HorizontalAlignment', 'center',...
    'VerticalAlignment', 'bottom',...
    'FontSize', 7,...
    };


ax1 = subplot(9,5,[11,12,16,17,21,22,26,27,31,32,36,37,41,42]);
grid on; hold off; grid minor;
graghDefalutSet(ax1);
ax1.XDir ='reverse';
ax1.XLim = [-10 10];
ax1.YLim = [-200 200];



% MAP 1
ax511 = subplot(9,5,3); box on; hold on;
if isfield(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log, 'lmInhStt')
    map1_eMap = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmInhStt.signals.values(:,1),3);
    map1_eYrm = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmInhStt.signals.values(:,1),5)*2;
else
    map1_eMap = ones(length(Group1Time), 1)*-1;
    map1_eYrm = ones(length(Group1Time), 1)*-1;
    saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmInhStt.signals.values = zeros(length(Group1Time), 1);
end
map1_mhStt = (saTldMiBusOut_MPU_message1BusOut_log.mpuStt.signals.values(:,1)~=0)*3;

plot(ax511, Group1Time, map1_eMap, 'r.-');
plot(ax511, Group1Time, map1_eYrm, 'b.-');
plot(ax511, Group1Time, map1_mhStt, 'g.-');

map1title = text('String', sprintf('\\color{red}eMap:%d \\color{blue}eYrm:%d \\color{green}mhStt:%d',...
    map1_eMap(timeChartIndex,1),...
    map1_eYrm(timeChartIndex,1),...
    map1_mhStt(timeChartIndex,1)),...
    titleCommonOption{:}...
    );


% MAP 2
ax512 = subplot(9,5,8); box on;
map2_radius = 1./saTldMiBusOut_lmTldMapBusOut_lmMapEgoBusOut_log.lmVecMapEgoLnPntExCurvature.signals.values(:,1);
plot(ax512, Group1Time, map2_radius, 'b.-');

map2title = text('String', sprintf('Radius:%.1f',...
    map2_radius(timeChartIndex)),...
    titleCommonOption{:},...
    'Color', 'blue');


% MAP 3
ax513 = subplot(9,5,13); box on;
egoSpd = sqrt(saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmodEgoMovX.signals.values.^2 ...
    + saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmodEgoMovY.signals.values.^2)*10;
map3_egoSpd = egoSpd * 3.6;

plot(ax513, Group1Time, map3_egoSpd, 'r.-');

map3title = text('String', sprintf('egoSpd:%.1f', map3_egoSpd(timeChartIndex)),...            
    titleCommonOption{:},...
    'Color', 'red'...
    );

% MAP 4
ax516 = subplot(9,5,18); box on; hold on;
map4_rightLineMatch = bitget(saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values,19);
map4_leftLineMatch  = bitget(saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values,20);
map4_cameraBase     = bitget(saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values,17);
map4_mapBase        = bitget(saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values,18);

plot(ax516, Group1Time, map4_rightLineMatch, 'k.-');
plot(ax516, Group1Time, map4_leftLineMatch *2, 'r.-');
plot(ax516, Group1Time, map4_cameraBase *3, 'b.-');
plot(ax516, Group1Time, map4_mapBase *4, 'm.-');

map4title = text('String', sprintf('\\color{black}RightLineMatch:%d  \\color{red}LeftLineMatch:%d  \\color{blue}CameraBase:%d  \\color{magenta}MapBase:%d',...
    map4_rightLineMatch(timeChartIndex),...
    map4_leftLineMatch(timeChartIndex),...
    map4_cameraBase(timeChartIndex),...
    map4_mapBase(timeChartIndex)),...
    titleCommonOption{:}...
    );

% MAP 5
ax517 = subplot(9,5,23); box on;
pld5  = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,5);
pld6  = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,6);
pld13 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,13);
pld14 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,14);
pld15 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,15);
pld16 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,16);
pld17 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,17);
pld18 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,18);
pld19 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,19);
pld20 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,20);
pld21 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,21);
pld22 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,22);
pld23 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,23);
pld24 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,24);
pld25 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,25);
pld26 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,26);
pld27 = bitget(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,27);
map5_pldON = pld5|pld6|pld13|pld14|pld15|pld16|pld17|pld18|pld19|pld20|pld21|pld22|pld22|pld23|pld24|pld25|pld26|pld27;

plot(ax517, Group1Time, map5_pldON,'b.-');

map5title = text('String', sprintf('System Limit:%s',...
    num2str(map5_pldON(timeChartIndex))),...
    titleCommonOption{:},...
    'Color', 'blue'...
    );

% MAP 6
ax518 = subplot(9,5,28); box on; hold on;

map6_leftClinebFlg  = saTldMiBusOut_lmTldMapBusOut_lmTldMapCamBusOut_log.lmVecClinebFlg.signals.values(:,1);
map6_rightClinebFlg = saTldMiBusOut_lmTldMapBusOut_lmTldMapCamBusOut_log.lmVecClinebFlg.signals.values(:,2);
plot(ax518, Group1Time, map6_leftClinebFlg, 'k.-');
plot(ax518, Group1Time, map6_rightClinebFlg, 'r.-');

map6title = text('String', sprintf('\\color{black}LeftClinebFlg:%s \\color{red}RightClinebFlg:%s',...
    int2str(map6_leftClinebFlg(timeChartIndex)), int2str(map6_rightClinebFlg(timeChartIndex))),...
    titleCommonOption{:}...
    );

% MAP 7
ax519 = subplot(9,5,[33,38]); box on; hold on;

TargetSec1 = 1.05;%BirdEyeView�̉����ʒu1
TargetSec2 = 2;%BirdEyeView�̉����ʒu2

tgtDiffy1 = calcTgtDiffy(LogTime, LogTimeCam,...
    egoSpd, map1_eMap,saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntX.signals.values, saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntY.signals.values, CamX, CamY,...
    saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadConf.signals.values,...
    saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadQuality.signals.values,...
    saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadType.signals.values,...
    saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnExistFlg.signals.values,...
    saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnStartIdx.signals.values,...
    saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnEndIdx.signals.values,...
    lmodmovX, lmodmovY, lmodmovRotX,...
    saTldMiBusOut_lmTldMapBusOut_lmMapEgoBusOut_log.lmVecMapEgoLnPntExCurvature.signals.values(:,1),...
    map4_rightLineMatch, map4_leftLineMatch, TargetSec1);
    map7_gapValue1 = tgtDiffy1(:, end); % 1.05�b��LM���H����

tgtDiffy2 = calcTgtDiffy(LogTime, LogTimeCam,...
    egoSpd, map1_eMap,saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntX.signals.values, saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntY.signals.values, CamX, CamY,...
    saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadConf.signals.values,...
    saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadQuality.signals.values,...
    saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadType.signals.values,...
    saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnExistFlg.signals.values,...
    saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnStartIdx.signals.values,...
    saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnEndIdx.signals.values,...
    lmodmovX, lmodmovY, lmodmovRotX,...
    saTldMiBusOut_lmTldMapBusOut_lmMapEgoBusOut_log.lmVecMapEgoLnPntExCurvature.signals.values(:,1),...
    map4_rightLineMatch, map4_leftLineMatch, TargetSec2);
    map7_gapValue2 = tgtDiffy2(:, end); % 2�b��LM���H����
    
    plot(ax519, Group1Time, map7_gapValue1, 'b.-');
    plot(ax519, Group1Time, map7_gapValue2, 'm.-');
    
    yline( ax519, -0.3, "-r", "DisplayName", "2sigma min" );
    yline( ax519, 0.3, "-r", "DisplayName", "2sigma max" );
    
    map7title = text('String', sprintf('\\color{blue}Gap value%.2fsec:%.3f \\color{magenta}Gap value%.1fsec:%.3f',...
        TargetSec1, map7_gapValue1(timeChartIndex),TargetSec2, map7_gapValue2(timeChartIndex)),...
        titleCommonOption{:},...
        'Color', 'blue');

% MAP 8
ax520 = subplot(9,5,43);
lmInhStt = saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmInhStt.signals.values;
% saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmCtrlLnMode
mhSttBin          = dec2bin(saTldMiBusOut_MPU_message1BusOut_log.mpuStt.signals.values(:,1),32);
lmPldSttBin       = dec2bin(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values,32);
lmInhSttBin       = dec2bin(lmInhStt,32);
lmLnModeBin       = dec2bin(saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values(:,1),32);
lmmmMapDiffSttBin = dec2bin(saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmmMapDiffStt.signals.values,32);
lmmmCamDiffStBin  = dec2bin(saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmmCamDiffStt.signals.values,32);
ReserveUint7Bin   = dec2bin(saTldMiBusOut_lmTldMapBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values,32);

% 4�����Ƃɋ󔒂�����
map8_mhStt = string(cellfun(@(x) join(arrayfun(@(digit) x(digit:digit+3), 1:4:32, 'UniformOutput', false), ' '), num2cell(mhSttBin, 2), 'UniformOutput', false));
map8_lmPldStt = string(cellfun(@(x) join(arrayfun(@(digit) x(digit:digit+3), 1:4:32, 'UniformOutput', false), ' '), num2cell(lmPldSttBin, 2), 'UniformOutput', false));
map8_lmInhStt = string(cellfun(@(x) join(arrayfun(@(digit) x(digit:digit+3), 1:4:32, 'UniformOutput', false), ' '), num2cell(lmInhSttBin, 2), 'UniformOutput', false));
map8_lmLnMode = string(cellfun(@(x) join(arrayfun(@(digit) x(digit:digit+3), 1:4:32, 'UniformOutput', false), ' '), num2cell(lmLnModeBin, 2), 'UniformOutput', false));
map8_lmmmMapDiffStt = string(cellfun(@(x) join(arrayfun(@(digit) x(digit:digit+3), 1:4:32, 'UniformOutput', false), ' '), num2cell(lmmmMapDiffSttBin, 2), 'UniformOutput', false));
map8_lmmmCamDiffStt = string(cellfun(@(x) join(arrayfun(@(digit) x(digit:digit+3), 1:4:32, 'UniformOutput', false), ' '), num2cell(lmmmCamDiffStBin, 2), 'UniformOutput', false));
map8_ReserveUint7 = string(cellfun(@(x) join(arrayfun(@(digit) x(digit:digit+3), 1:4:32, 'UniformOutput', false), ' '), num2cell(ReserveUint7Bin, 2), 'UniformOutput', false));

if exist('ax520', 'var') && isgraphics(ax520)
    cla(ax520);
else
    ax520 = subplot(9,4,35);
end
set(ax520,'xtick',[]);
set(ax520,'ytick',[]);
set(ax520,'xcolor','w');
set(ax520,'ycolor','w');

txtCommonOption = {...
    'FontSize', 8,...
    'Color', 'black',...
    'Units', 'normalized'...
    };

txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'mhStt', txtCommonOption{:});
txt.String = sprintf('mhStt: %s', map8_mhStt{timeChartIndex});
txt.Position= [0.01 1 0];

txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmPldStt', txtCommonOption{:});
txt.String = sprintf('lmPldStt: %s', map8_lmPldStt{timeChartIndex});
txt.Position= [0.01 0.85 0];

txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmInhStt',txtCommonOption{:});
txt.String = sprintf('lmInhStt: %s', map8_lmInhStt{timeChartIndex});
txt.Position= [0.01 0.70 0];

txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmLnMode', txtCommonOption{:});
txt.String = sprintf('lmLnMode: %s', map8_lmLnMode{timeChartIndex});
txt.Position= [0.01 0.55 0];

txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmmmMapDiffStt', txtCommonOption{:});
txt.String = sprintf('lmmmMapDiffStt: %s', map8_lmmmMapDiffStt{timeChartIndex});
txt.Position= [0.01 0.40 0];

txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'lmmmCamDiffStt', txtCommonOption{:});
txt.String = sprintf('lmmmCamDiffStt: %s', map8_lmmmCamDiffStt{timeChartIndex});
txt.Position= [0.01 0.25 0];

txt = text(ax520,ax520.XLim(2),ax520.YLim(2),'ReserveUint7', txtCommonOption{:});
txt.String = sprintf('ReserveUint7: %s', map8_ReserveUint7{timeChartIndex});
txt.Position= [0.01 0.1 0];
hold off;


% Chart 1
ax611 = subplot(9,5,4); box on; hold on;
chart1_leftCamEndX = CamEndX(:,1);
chart1_rightCamEndX = CamEndX(:,2);

if LMCMSignalExist
    plot(ax611, Group1Time, chart1_leftCamEndX,'r.-');
    plot(ax611, Group1Time, chart1_rightCamEndX,'b.-');
else
    plot(ax611, Group1Time, chart1_leftCamEndX,'r.-');
    plot(ax611, Group1Time, chart1_rightCamEndX,'b.-');
end
chart1title = text('String', sprintf('\\color{red}LeftCamEndX:%s \\color{blue}RightCamEndX:%s',...
    num2str(chart1_leftCamEndX(timeChartIndex)),...
    num2str(chart1_rightCamEndX(timeChartIndex))),...
    titleCommonOption{:}...
    );


% Chart 2
ax612 = subplot(9,5,9); box on; hold on;


chart2_leftCLineProb = CamProb(:,1);
chart2_rightCLineProb = CamProb(:,2);
if LMCMSignalExist           
    plot(ax612, Group1Time, chart2_leftCLineProb,'r.-');
    plot(ax612, Group1Time, chart2_rightCLineProb,'b.-');
else
    plot(ax612, Group1Time, chart2_leftCLineProb,'r.-');
    plot(ax612, Group1Time, chart2_rightCLineProb,'b.-');
end

chart2title = text('String', sprintf('\\color{red}LeftCLineProb:%s \\color{blue}RightCLineProb:%s',...
    num2str(chart2_leftCLineProb(timeChartIndex)),...
    num2str(chart2_rightCLineProb(timeChartIndex))),...
    titleCommonOption{:}...
    );

% Chart 3
ax613 = subplot(9,5,14); box on; hold on;

chart3_leftCLineQuality = CamQ(:,1);
chart3_rightCLineQuality = CamQ(:,2);

plot(ax613, Group1Time, chart3_leftCLineQuality,'r.-');
plot(ax613, Group1Time, chart3_rightCLineQuality,'b.-');


chart3title = text('String', sprintf('\\color{red}LeftCLineQuality:%s \\color{blue}RightCLineQuality:%s',...
    num2str(chart3_leftCLineQuality(timeChartIndex)),...
    num2str(chart3_rightCLineQuality(timeChartIndex))),...
    titleCommonOption{:}...
    );

% Chart 4
ax614 = subplot(9,5,19); box on; hold on;

chart4_leftCLineType      = CamType(:, 1);
chart4_rightCLineType     = CamType(:, 2);
chart4_nextLeftCLineType  = CamType(:, 3);
chart4_nextRightCLineType = CamType(:, 4);

% chart4_leftCLineTypeRaw      = CamTypeRaw(:, 1);
% chart4_rightCLineTypeRaw     = CamTypeRaw(:, 2);
% chart4_nextLeftCLineTypeRaw  = CamTypeRaw(:, 3);
% chart4_nextRightCLineTypeRaw = CamTypeRaw(:, 4);


 if LMCMSignalExist  
    plot(ax614, Group1Time, chart4_leftCLineType,'k.-');
    plot(ax614, Group1Time, chart4_rightCLineType,'r.-');
    plot(ax614, Group1Time, chart4_nextLeftCLineType,'b.-');
    plot(ax614, Group1Time, chart4_nextRightCLineType,'m.-');
 else
    plot(ax614, Group1Time, chart4_leftCLineType,'k.-');
    plot(ax614, Group1Time, chart4_rightCLineType,'r.-');
    plot(ax614, Group1Time, chart4_nextLeftCLineType,'b.-');
    plot(ax614, Group1Time, chart4_nextRightCLineType,'m.-');
 end

chart4title = text('String', sprintf(...
    '\\color{black}LeftCLineType:%s \\color{red}RightCLineType:%s',...
    num2str(chart4_leftCLineType(timeChartIndex)),...
    num2str(chart4_rightCLineType(timeChartIndex))),...
    titleCommonOption{:}...
    );
% Chart 5
ax615 = subplot(9,5,24); box on; hold on;
chart5_leftCLineTypeRaw      = CamTypeRaw(:, 1);
chart5_rightCLineTypeRaw     = CamTypeRaw(:, 2);
chart5_nextLeftCLineTypeRaw  = CamTypeRaw(:, 3);
chart5_nextRightCLineTypeRaw = CamTypeRaw(:, 4);


if LMCMSignalExist  
    plot(ax615, Group1Time, chart5_leftCLineTypeRaw,'k.-');
    plot(ax615, Group1Time, chart5_rightCLineTypeRaw,'r.-');
    plot(ax615, Group1Time, chart5_nextLeftCLineTypeRaw,'b.-');
    plot(ax615, Group1Time, chart5_nextRightCLineTypeRaw,'m.-');
else
    plot(ax615, Group1Time, chart5_leftCLineTypeRaw,'k.-');
    plot(ax615, Group1Time, chart5_rightCLineTypeRaw,'r.-');
    plot(ax615, Group1Time, chart5_nextLeftCLineTypeRaw,'b.-');
    plot(ax615, Group1Time, chart5_nextRightCLineTypeRaw,'m.-');
end
chart5title = text('String', sprintf(...
    '\\color{blue}NextLeftCLineType:%s \\color{magenta}NextRightCLineType:%s',...
    num2str(chart5_leftCLineTypeRaw(timeChartIndex)),...
    num2str(chart5_rightCLineTypeRaw(timeChartIndex))),...
    titleCommonOption{:}...
    );

% �e�L�X�g�\��
    signalExpLt = uipanel('Position',[0.6140625,0.281704781704782,0.083333333333333,0.182952182952183]);
    annotation(signalExpLt,'textbox', [0.000001,0.509489274770172,0.11,0.509999999999998], 'LineStyle','none', ...
        'String',sprintf(...
       ['�yCamLineType�z' ...
        '\\newline[ 0]UNDECIDED' ...
        '\\newline[ 1]SOLID' ...
        '\\newline[ 2]DASHED' ...
        '\\newline[ 3]ROADEDGE' ...
        '\\newline[ 4]DLM' ...
        '\\newline[ 5]BOTTS' ...
        '\\newline[ 6]BARRIER' ...
        '\\newline[ 7]CURB' ...
        '\\newline[ 8]CONE\\_POLES' ...
        '\\newline[ 9]PARKING\\_CARS' ...
        '\\newline[10]DECELERATION']),...
        'FontSize',7.7);

% Chart 5
% ax615 = subplot(9,5,24); box on; hold on;
% 
% chkName = 'hdfdataM3n200mBusOut_lmmlBusOut_log';
% isExistLmmlVecStt = exist(chkName, 'var');
% if isExistLmmlVecStt
%     fields = fieldnames(eval(chkName));
%     if find(contains(fields, 'lmmlVecStt', 'IgnoreCase', true))
%         fieldIdx = find(contains(fields, 'lmmlVecStt', 'IgnoreCase', true));
%         getValue = eval(strcat(chkName,'.', fields{fieldIdx}, '.signals.values'));
%         yrmStt = getValue;
%         isExistLmmlVecStt = 0;
%     end
% end
% if ~isExistLmmlVecStt
%     yrmStt = saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmmlVecStt.signals.values(:,11);
% end
% 
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 1 ),'-');
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 2 ) * 2,'-');
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 3 ) * 3,'-');
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 4 ) * 4,'-');
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 5 ) * 5,'-');
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 6 ) * 6,'-');
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 7 ) * 7,'-');
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 8 ) * 8,'-');
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 9 ) * 9,'-r');
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 10 ) * 10,'-g');
% plot(ax615,Group3Time,bitget(yrmStt(:,1), 11 ) * 11,'-k');
% 
% legendAx615 = legend(ax615,["elineCam","elineMap","eR","eT","ede","ecnt","ewrongLane","CamLineLostFlg",...
%     "CamDiffAsapFlg","CamLineLostBothFlg","CamBothErrFlg"],...
%     'Location', 'northoutside',...
%     'FontSize', 8,...
%     'NumColumns', 2,...
%     'Autoupdate', 'off');

% Chart 6
% ax616 = subplot(9,5,29); box on; hold on;
% lmPldStt = saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values;
% 
% plot(ax616, Group3Time,bitget(lmPldStt(:,1),17),'-');
% plot(ax616, Group3Time,bitget(lmPldStt(:,1),16) * 2,'-');
% plot(ax616, Group3Time,bitget(lmPldStt(:,1),6) * 3,'-');
% plot(ax616, Group3Time,bitget(lmPldStt(:,1),5) * 4,'-');
% plot(ax616, Group3Time,bitget(lmPldStt(:,1),24) * 5,'-');
% plot(ax616, Group3Time,bitget(lmPldStt(:,1),25) * 6,'-');
% plot(ax616, Group3Time,bitget(lmPldStt(:,1),18) * 7,'-');
% plot(ax616, Group3Time,bitget(lmPldStt(:,1),21) * 8,'-r');
% plot(ax616, Group3Time,bitget(lmPldStt(:,1),19) * 9,'-g');
% plot(ax616, Group3Time,bitget(lmPldStt(:,1),20) * 10,'-k');
% 
% legendAx616 = legend(ax616,["724","723","711","710","731","732","725","728","726","727"],...
%     'Location','northoutside',...
%     'FontSize',8,...
%     'NumColumns',5,...
%     'Autoupdate', 'off');

% Chart 7
ax617 = subplot(9,5,39); box on;
chart7_mpuTimeStamp1Diff = vertcat(0, diff(saTldMiBusOut_MPU_message1BusOut_log.rctfTimeStamp.signals.values(:,1)));
plot(ax617, Group1Time, chart7_mpuTimeStamp1Diff(:,1),'b.-');
chart7title = text('String', sprintf(...
    'mpuTimeStamp1Diff:%s',num2str(chart7_mpuTimeStamp1Diff(timeChartIndex))),...
    titleCommonOption{:},...
    'Color', 'red'...
    );
% ax617.Position = [0.67 0.11 0.1566 0.061];

% if ax616.Position(2) > 0.1100
%     ax615Left = ax615.Position(1);
%     ax615Width = ax615.Position(3);
%     ax615Bottom = 0.3610;  
%     ax615Height = 0.095;
%     ax615.Position = [ax615Left ax615Bottom ax615Width ax615Height];
%     
%     legendAx615.Position = [ax615.Position(1)*0.95 legendAx615.Position(2) legendAx615.Position(3) legendAx615.Position(4)];
% 
%     ax616Left = ax616.Position(1);
%     ax616Width = ax616.Position(3);
%     ax616Bottom = 0.1990;
%     ax616Height = 0.095;
%     ax616.Position = [ax616Left ax616Bottom ax616Width ax616Height];
%     
%     legendAx616.Position = [ax616.Position(1)*0.95 legendAx616.Position(2) legendAx616.Position(3) legendAx616.Position(4)];
% end

% vehicle 1
ax711 = subplot(9,5,1); box on; hold on;

try
vehicle1_epsStrAngRad = saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log.epsVecStrAngRad.signals.values;
plot(ax711, Group1Time, vehicle1_epsStrAngRad,'r.-');

vehicle1title = text('String', sprintf('\\color{red}epsStrAngRad:%s',...
    num2str(vehicle1_epsStrAngRad(timeChartIndex))),...
    titleCommonOption{:}...
    );
logFile = fullfile(currentDir,'use_saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log.epsVecStrAngRad.log');
                        fileID = fopen(logFile, 'a');
                        fprintf(fileID, "use_saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log.epsVecStrAngRad\n");
                        fclose(fileID);
catch
    vehicle1_epsStrAngRad = saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log.epsStrAngRad.signals.values;
    plot(ax711, Group1Time, vehicle1_epsStrAngRad,'r.-');
    
    vehicle1title = text('String', sprintf('\\color{red}epsStrAngRad:%s',...
        num2str(vehicle1_epsStrAngRad(timeChartIndex))),...
        titleCommonOption{:}...
        );
    logFile = fullfile(currentDir,'use_saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log.epsStrAngRad.log');
                            fileID = fopen(logFile, 'a');
                            fprintf(fileID, "use_saTldMiBusOut_ahdfCp2ApBusOut_vhclApBusOut_log.epsStrAngRad\n");
                            fclose(fileID);
end
% vehicle 2
ax712 = subplot(9,5,2); box on; hold on;

vehicle2_saEgoRateYaw = saTldMiBusOut_saTldEgoMovBusOut_saEgo100BusOut_log.saEgoRateYaw.signals.values;
plot(ax712, Group1Time, vehicle2_saEgoRateYaw,'r.-');

vehicle2title = text('String', sprintf('\\color{red}saEgoRateYaw:%s',...
    num2str(vehicle2_saEgoRateYaw(timeChartIndex))),...
    titleCommonOption{:}...
    );
% vehicle 3
ax713 = subplot(9,5,6); box on; hold on;

vehicle3_lmTldMapCnt = saTldMiBusOut_lmTldMapBusOut_log.lmTldMapCnt.signals.values;
plot(ax713, Group1Time, vehicle3_lmTldMapCnt,'r.-');  

vehicle3title = text('String', sprintf('\\color{red}lmTldMapCnt:%s',...
    num2str(vehicle3_lmTldMapCnt(timeChartIndex))),...
    titleCommonOption{:}...
    );

% frazki_add 1
ax811 = subplot(9,5,5); box on; hold on;

    plot(ax811, Group1Time,StrOverRideStt,'r.-');
    plot(ax811, Group1Time,LKASflg,'b.-');
    plot(ax811, Group1Time,ACCflg,'k.-');
    frazkiAdd1title = text('String', sprintf('\\color{red}1:StrOver \\color{blue}2:ACC \\color{black}3:LKAS'),...
        titleCommonOption{:}...
        );

% frazki_add 2
ax812 = subplot(9,5,10); box on; hold on;

% Use these as default settings
furatsukiLB = 0.0;                 %[m]?
furatsukiUB = 30.0;                %[m]?
furatsuki_IgnoreTimeNeighbourhood = 0.5;    % [s]
furatsuki_IncidentTime = 50;
furatsuki_NeighbourhoodLeftRange = 10.0;    % [s]
furatsuki_NeighbourhoodRightRange = 10.0;   % [s]
furatsuki_AnalyzeAllData = false;
furatsuki_noPeaksToFind = 10;               % [-]

saVecFcRoadC0 = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadC0.signals.values;

C0Time = Group1Time;
C0LeftRaw = saVecFcRoadC0(:,1);
C0RightRaw = saVecFcRoadC0(:,2);

%Automatically find furatsuki (only checking C0Center)
C0Left = C0LeftRaw;
C0Right = C0RightRaw;
C0Center = (C0LeftRaw + C0RightRaw)*0.5;


furatsukiInvalidIdx = find(C0LeftRaw==furatsukiLB | C0LeftRaw==furatsukiUB | C0RightRaw==furatsukiLB | C0RightRaw==furatsukiUB);

C0Left(furatsukiInvalidIdx) = NaN;
C0Right(furatsukiInvalidIdx) = NaN;
C0Center(furatsukiInvalidIdx) = NaN;

% Analyze furatsuki (C0Center only)
% [~, ~, furatsukiPeaksValleys, ~] = FuratsukiAnalysisPeaksValleys(C0Time, C0Center, ...
%     furatsuki_IgnoreTimeNeighbourhood, ...
%     furatsuki_IncidentTime, furatsuki_NeighbourhoodLeftRange, furatsuki_NeighbourhoodRightRange, ...
%     furatsuki_AnalyzeAllData, furatsuki_noPeaksToFind);
% LcDelIdx=[];
% LcTimeStart=[];
% LcTimeEnd=[];
% furatsukiPeaksValleysDiff = diff(furatsukiPeaksValleys,1);
% for LCnum = 1: size(furatsukiPeaksValleysDiff,1)
%     %0.3sec�ȓ��ɒJ����R��3m�ȏ�ψق����ꍇ�ALC�����Ƃ݂Ȃ��ď���
%     % �X�e�A�I�[�o�[���C�h�t���OON�̏ꍇ������
%     if furatsukiPeaksValleysDiff(LCnum,1)<0.3 && furatsukiPeaksValleysDiff(LCnum,2)>3 && furatsukiPeaksValleys(LCnum,2)*furatsukiPeaksValleys(LCnum+1,2)<0
%         LcDelIdx(end+1)=LCnum;
%         LcDelIdx(end+1)=LCnum+1;
%         LcTimeStart(end+1) = furatsukiPeaksValleys(LCnum,1)-2;
%         LcTimeEnd(end+1) = furatsukiPeaksValleys(LCnum+1,1)+2;
%     end
% end
% StrDelIdx =[];
% for STRnum = 1:size(furatsukiPeaksValleys,1)
%     ChkOvrRideIdx=find(Group1Time==furatsukiPeaksValleys(STRnum,1));
%     if StrOverRideStt(ChkOvrRideIdx)==1
%         StrDelIdx(end+1) =STRnum;
%     end
% end
% DelIdx=unique([LcDelIdx,StrDelIdx]);
% furatsukiPeaksValleys(DelIdx,:)=[];

plot(ax812, Group1Time, C0Left,'k.-');
plot(ax812, Group1Time, C0Right,'r.-');
plot(ax812, Group1Time, C0Center,'b.-');
% if ~isempty(furatsukiPeaksValleys)
%     xline(ax812, furatsukiPeaksValleys(:,1), '--r');
% end
frazkiAdd2title = text('String', sprintf('\\color{black}C0Left:%s  \\color{red}C0Right:%s  \\color{blue}C0Center:%s',...
    num2str(C0Left(timeChartIndex)),...
    num2str(C0Right(timeChartIndex)),...
    num2str(C0Center(timeChartIndex))),...
    titleCommonOption{:}...
    );


% frazki_add 3
ax813 = subplot(9,5,15); box on; hold on;
try
plot(ax813, Group1Time,epsVecStrTrq,'r.-');
frazkiAdd3title = text('String', sprintf('StrTrq:%s',...
    num2str(epsVecStrTrq(timeChartIndex))),...
    titleCommonOption{:}...
    );
catch
end

% frazki_add 4
ax814 = subplot(9,5,20); box on;

lmVecMapEgoLnPntExCurvature = saTldMiBusOut_lmTldMapBusOut_lmMapEgoBusOut_log.lmVecMapEgoLnPntExCurvature.signals.values;
CurvatureX = 10* [1:size(lmVecMapEgoLnPntExCurvature,2)];

frazkiAdd4title = title(ax814,'Curvature[1/m], �E:�{,��:�[');

ax815 = subplot(9,5,25); box on;
 hold on;grid on;grid minor;

LnModeCamCenter = bitget(saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values,1);
CarAvailable = bitget(saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values,4);
LnModeFrontCarTrace = bitget(saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values,2);
CtrlLnExistFlgLMTLDCAM = saTldLaneCnvBusOut_saCurrentCtrlBusOut_log.saVecCtrlLnExistFlg.signals.values(:,2);
if data_ver==1
    expresswayFlg1 = bitget(saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmVecDebugReserveUint.signals.values(:,1),1);
    expresswayFlg2 = bitget(saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log.lmVecDebugReserveUint.signals.values(:,1),4);
    expresswayFlg = expresswayFlg1 & expresswayFlg2;
elseif data_ver==2
    expresswayFlg = bitget(saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values,3);
end

plot(ax815,Group1Time,double(LnModeCamCenter),"r.-");
plot(ax815,Group1Time,double(LnModeFrontCarTrace)*2,"b.-");
plot(ax815,Group1Time,double(CarAvailable)*3,"g.-");
plot(ax815,Group1Time,double(CtrlLnExistFlgLMTLDCAM)*0.5,"k.-");
plot(ax815,Group1Time,double(expresswayFlg)*4,"m.-");


frazkiLnModeTitle = text('String', sprintf('lmLaneExistFlg:%s   \\color{red}CamLane:%s  \\color{blue}CarTraceLane:%s\n\\color{green}FrontCarAvailable:%s  \\color{magenta}expresswayFlg:%s',...
    num2str((LnModeCamCenter(timeChartIndex))),...
    num2str((LnModeFrontCarTrace(timeChartIndex))),...
    num2str((CarAvailable(timeChartIndex))),...
    num2str((expresswayFlg(timeChartIndex)))),...
    titleCommonOption{:}...
    );
frazkiLnModeTitle.Position = [0.5,0.976101694915254,0];

 ax816 = subplot(9,5,30); box on;
 hold on;grid on;grid minor;

cC1Diff = cC1L-cC1R;
cC2Diff = cC2L-cC2R;
cC3Diff = cC3L-cC3R;


plot(ax816,Group1Time,cC1Diff,"r.-");
plot(ax816,Group1Time,cC2Diff*10,"b.-");
plot(ax816,Group1Time,cC3Diff*100,"g.-");


frazkiCDiff = text('String', sprintf('\\color{red}C1Diff:%s  \\color{blue}C2Diff:%s  \\color{green}C3Diff:%s',...
    num2str((cC1Diff(timeChartIndex))),...
    num2str((cC2Diff(timeChartIndex))),...
    num2str((cC3Diff(timeChartIndex)))),...
    titleCommonOption{:}...
    );



 ax817 = subplot(9,5,35); box on;
 hold on;grid on;grid minor;

plot(ax817,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(:,1),1)),".-");
plot(ax817,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(:,1),2))*2,".-");
plot(ax817,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(:,1),3))*3,".-");
plot(ax817,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(:,1),4))*4,".-");
plot(ax817,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(:,1),5))*5,".-");
plot(ax817,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(:,1),6))*6,".-");
plot(ax817,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(:,1),7))*7,".-");
plot(ax817,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(:,1),8))*8,".-");
plot(ax817,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(:,1),9))*9,".-");

frazkiCDiffQ = text('String', sprintf('impt:%s',...
    string(bitgets(saTldMiBusOut_lmTldCamBusOut_lmReserveBusOut_log.lmVecReserveUint.signals.values(1,1)))),...
    titleCommonOption{:}...
    );

 ax818 = subplot(9,5,40); box on;
 hold on;grid on;grid minor;

 plot(ax818,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(:,1),8))*(7),".-");
 plot(ax818,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(:,1),9))*(8),".-");
 plot(ax818,Group1Time,double(bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(:,1),10))*(9),".-");
 frazkiCDiffW = text('String', sprintf('pldcam:%s',...
    string(bitgets(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(1,1)))),...
    titleCommonOption{:}...
    );

% ����
subPlots = [ax511, ax512, ax513, ax516, ax517, ax518, ax519,...
    ax611, ax612, ax613, ax614, ax615, ax617...
    ax711, ax712, ax713,...
    ax811, ax812, ax813,ax815,ax816,ax817,ax818];

for sp = 1 : length(subPlots)
    set(subPlots(sp), 'XGrid', 'on', 'YGrid', 'on');
    grid(subPlots(sp), 'minor');
end

if PARAPARAMODE
    prevFileIdx = currentFileIdx;
end


xlimVLow  = str2double(YlimLowerEdit.String);
xlimVHigh = str2double(YlimUpperEdit.String);
ylimVLow  = str2double(XlimLowerEdit.String);
ylimVHigh = str2double(XlimUpperEdit.String);


%% D. Function Definition %%%%%%%%%
%%% ax1 map
function graghDefalutSet(ax1)
ax1.NextPlot = 'add';
ax1.XGrid = 'on';
ax1.XMinorGrid='on';
ax1.YGrid = 'on';
ax1.YMinorGrid='on';
end

function jumpbutton(argument1, argument2)
global jumpbutton_value;
jumpbutton_value = 1;
    TimeJumperEdit = evalin( "base", "TimeJumperEdit" );
    slider_obj = evalin( "base", "slider_obj" );
    LogTime = evalin( "base", "LogTime" );
    
    editTime = single(str2double(TimeJumperEdit.String));
    [~, l50msec]  = min(abs( LogTime - editTime));

    slider_obj.Value = l50msec;
    assignin( "base", "slider_obj", slider_obj );

%     TimeJumperEdit.String = num2str(LogTime(l50msec));
%     assignin( "base", "TimeJumperEdit", TimeJumperEdit );

end

function saveBEVbutton
figObj=figure('Name','����ۑ��ݒ�','NumberTitle','off','Position', [200 200 600 300],'ToolBar','None','MenuBar','None');

startTimeTextBox = annotation(figObj, 'textbox', 'Position',[.05 .52 .2 .4], 'String','�J�n����', 'LineStyle','none', 'FontSize',12);
startTimeEdit = uicontrol(figObj, 'Style','edit', 'Units','normalized' ,'Position',[.2 .82 .2 .1], 'FontSize',12);

endTimeTextBox = annotation(figObj, 'textbox', 'Position',[.05 .32 .2 .4], 'String','�I������', 'LineStyle','none', 'FontSize',12);
endTimeEdit = uicontrol(figObj, 'Style','edit', 'Units','normalized' ,'Position',[.2 .62 .2 .1], 'FontSize',12);

saveBEVPathTextBox = annotation(figObj, 'textbox', 'Position',[.05 .12 .2 .4], 'String','�ۑ���', 'LineStyle','none', 'FontSize',12);
saveBEVPathEdit = uicontrol(figObj, 'Style','edit', 'Units','normalized' ,'Position',[.2 .42 .7 .1], 'FontSize',12);
button_dir = uicontrol(figObj, 'Style','pushbutton', 'String','�Q��','Units','normalized', 'Position',[.2 .32 .2 .1], 'FontSize',10,...
    'Callback',@(src, event) buttondir(saveBEVPathEdit));

button_finish = uicontrol(figObj, 'Style','pushbutton', 'String','����𐶐�','Units','normalized', 'Position',[.7 .1 .2 .15], 'FontSize',10,...
    'Callback', @(src, event) generate_video(startTimeEdit, endTimeEdit, saveBEVPathEdit, figObj));
uiwait(figObj);
end

function buttondir(saveBEVPathEdit)
    saveBEVpath = uigetdir(pwd);
    if saveBEVpath~=0
        set(saveBEVPathEdit, 'String', saveBEVpath);
    end
end

function generate_video(startTimeEdit, endTimeEdit, saveBEVPathEdit, figObj)
    startT = str2double(get(startTimeEdit, 'String'));
    endT = str2double(get(endTimeEdit, 'String'));
    saveP = get(saveBEVPathEdit, 'String');

    if startT >= endT || isnan(startT) || isnan(endT) || isempty(saveP)
        errordlg('���͂�����������܂���');
    else
        assignin( "base", "saveBEVbuttonFlg", 1 );
        assignin( "base", "startTimeEdit", startT );
        assignin( "base", "endTimeEdit", endT );
        assignin( "base", "saveBEVPathEdit", saveP );
        
        close(figObj);
    end
end

function [outIdx] = FuncTimeSearch (TimeData,targetTime)
% 1�����̒P��������TimeData���O������targetTime�ɍł��߂��l��T�����AIdx��ԋp����
rangeLow = 1;
rangeHigh = length(TimeData);
candidate = squeeze(zeros(5,1));

while((rangeHigh - rangeLow) > 5)

    %���̍쐬
    candidate(1) = rangeLow;
    candidate(5) = rangeHigh;
    candidate(3) = fix( (candidate(5) + candidate(1)) / 2);
    candidate(2) = fix( (candidate(3) + candidate(1)) / 2);
    candidate(4) = fix( (candidate(5) + candidate(3)) / 2);

    %���̒�����ŋߖT��T��
    errValue = abs(TimeData(candidate) - targetTime);
    [~ ,minId] = min(errValue);
    if minId == 1
        rangeHigh = candidate(2);
    elseif minId == 5
        rangeLow = candidate(4);
    else
        rangeLow = candidate(minId - 1);
        rangeHigh = candidate(minId + 1);
    end
end
%�ŏ��T���͈͂ōŋߖT�_���o��
errValue = abs(TimeData(rangeLow : rangeHigh) - targetTime);
[~ ,minId] = min(errValue);
outIdx = minId + rangeLow - 1;
end



function A= bitgets(a)
    k = "";
    for i=1:32
        b = bitget(a,i);
        if b==1
            k=k+string(i-1)+",";
        end
    end
    A = k;
end

%%% save movie
function ans = CopyMovie(filename,time,datapathlist,Moviefolder)
targettime = name2date(extractAfter(filename,"M"));
datanumber = floor(time/900);%���Ԗڂ̃f�[�^���H

disp(datanumber);

disp(targettime);

index = 0;
dev = duration(100000000,100000000,100000000);
for i= 1:length(datapathlist)

    A = strsplit(datapathlist(i),"\");%�t�@�C�����𒊏o����
    srctime = name2date(extractBefore(string(A(end)),"_Axis"));
    thisdev = abs(targettime -srctime);
    if dev >thisdev
        dev = thisdev;
        index = i;
    end
end

if index ==0
    disp("����3�I");
    ans = "dummy";%data�擾�ł��Ȃ���������߂�
else
    try
        copyfile(datapathlist(index),Moviefolder+"\"+string(filename)+"_"+string(time)+".avi");
    catch
    end
    ans =Moviefolder+"\"+string(filename)+"_"+string(time)+".avi";
end
end
%end

function adate = name2date(qname)
if length(qname)>1
    N = length(qname);
    tmp = datetime(zeros(N,6));
    for i  =1:N
        A = (strsplit(qname(i),"_"));
        A_yyyymmdd = char(A(1));
        A_hhmmss = char(A(2));
        tmp(i) = datetime(str2double(A_yyyymmdd(1:4)),str2double(A_yyyymmdd(5:6)),str2double(A_yyyymmdd(7:8)),str2double(A_hhmmss(1:2)),str2double(A_hhmmss(3:4)),str2double(A_hhmmss(5:6)));
    end
    adate = tmp;
else

    if ismissing(qname)
        adate = qname;
        
    else
    A = (strsplit(qname,"_"));
    A_yyyymmdd = char(A(1));
    A_hhmmss = char(A(2));

    adate = datetime(str2double(A_yyyymmdd(1:4)),str2double(A_yyyymmdd(5:6)),str2double(A_yyyymmdd(7:8)),str2double(A_hhmmss(1:2)),str2double(A_hhmmss(3:4)),str2double(A_hhmmss(5:6)));
    end
end
end






function viewerMF4_callback(src,event)

    if strcmp( src.Tag, "time" )
    %     timeEditValue = str2double( src.String );
    %     if mod(timeEditValue / 0.2, 1) ~= 0
    %         timeEditValue = round(timeEditValue / 0.2) * 0.2;
    %         timeEdit_obj = evalin( "base", "timeEdit_obj" );
    %         timeEdit_obj.String = num2str(timeEditValue);
    %     end
    %     time = evalin( "base", "time" );
    %     slider_obj = evalin( "base", "slider_obj" );
    %     slider_obj.Value = find( abs( time - str2double( src.String ) ) < 0.01 );
    %     assignin( "base", "slider_obj", slider_obj );
    
    elseif strcmp( src.Style, "slider" )
        sliderValue = round(src.Value);
        TimeJumperEdit = evalin( "base", "TimeJumperEdit" );
    
        LogTime = evalin( "base", "LogTime" );
        TimeJumperEdit.String = num2str(LogTime(sliderValue));
        assignin( "base", "TimeJumperEdit", TimeJumperEdit );
    
    end
%     evalin("base", "paraviewer_onlyMF4_d2_replot");
end

%%%%% sortSAVEs   
function sortSAVEs = sortSAVEsByFiles(partSAVEs, folderName, queryName)

    if isempty(partSAVEs)
        
        sortSAVEs = [];
        return;
        
    end

    sortFileList = unique([partSAVEs(:).Files], "sorted")';
    
    [sortSAVEs(1:length(sortFileList)).Files] = deal([]);
    [sortSAVEs(:).Indexes]    = deal([]);
    [sortSAVEs(:).GoogleLink] = deal([]);
    [sortSAVEs(:).Reserve]    = deal([]);
    [sortSAVEs(:).After]      = deal([]);
    [sortSAVEs(:).DiffType]   = deal([]);
    [sortSAVEs(:).FolderName] = deal([]);
    [sortSAVEs(:).QueryName]  = deal([]);

    [sortSAVEs(:).After]     = deal(partSAVEs(1).After);
    [sortSAVEs(:).QueryName] = deal(queryName(1));


    for filei = 1 : length(sortFileList)

        sortSAVEs(filei).Files =  sortFileList(filei);

        Indexes    = [];
        GoogleLink = [];
        Reserve    = [];
        DiffType   = [];
        FolderName = [];

        for SAVEsN = 1 : length(partSAVEs)

            SAVEsNidx = find(strcmp(sortFileList(filei), partSAVEs(SAVEsN).Files));

            if isempty(SAVEsNidx)
                continue;
            end

            Indexes    = [Indexes, partSAVEs(SAVEsN).Indexes(SAVEsNidx)];
            GoogleLink = [GoogleLink, partSAVEs(SAVEsN).GoogleLink(SAVEsNidx)];
            Reserve    = [Reserve, partSAVEs(SAVEsN).Reserve(:,SAVEsNidx)];
            DiffType   = [DiffType, partSAVEs(SAVEsN).DiffType(SAVEsNidx)];
            FolderName = [FolderName, repmat(folderName(SAVEsN), 1, length(SAVEsNidx))];

        end
        
        sortSAVEs(filei).Indexes    = Indexes;
        sortSAVEs(filei).GoogleLink = GoogleLink;
        sortSAVEs(filei).Reserve    = Reserve;
        sortSAVEs(filei).DiffType   = DiffType;
        sortSAVEs(filei).FolderName = FolderName;

    end
end

%% ��tgtDiffy�֘A
function tgtDiffy = calcTgtDiffy(LogTime, LogTimeCam,...
egoSpd, eMap, lmCtrlX, lmCtrlY, lmCamX, lmCamY,...
laneConfidence, laneQuality, laneType,...
cOutFlg, cOutStartIdx, cOutEndIdx,...
EgoMovX, EgoMovY, EgoRot, curvOrg,...
rightLineMatch, leftLineMatch, ts)

signalsChkResize = [...
    "egoSpd", "eMap", "lmCtrlX", "lmCtrlY", "lmCamX", "lmCamY",...
    "laneConfidence", "laneQuality", "laneType",...
    "cOutFlg", "cOutStartIdx", "cOutEndIdx",...
    "EgoMovX", "EgoMovY", "EgoRot", "curvOrg",...
    "rightLineMatch", "leftLineMatch"...
    ];

resizeArrayIdx = zeros(length(LogTime), 1, 'int32');
for i = 1 : length(LogTime)
     [~, l50msec]  = min(abs( LogTimeCam - LogTime(i)));
     resizeArrayIdx(i, 1) = l50msec;
end

for i = 1 : length(signalsChkResize)
    isLogTimeCam = eval( strcat("size(", signalsChkResize(i), ", 1) > ", string(length(LogTime)) ));
    if isLogTimeCam
        tgtSignal = signalsChkResize(i);
        eval(strcat(tgtSignal, "=", tgtSignal, "(resizeArrayIdx,:);"));
    end
end

time = LogTime;
%% setData.m
swSN = 0;        % ���H���x�̔�r�����{���A���x�̈Ⴂ���W�v���ĕ\������ꍇ1

% swXPosErr = 0;   % �c�ʒu�덷���ؗp�X�C�b�` 0:�ʏ탂�[�h 1:�c�ʒu�덷���؃��[�h
% swWidth = 0;     % ���ʒu�덷�ł͂Ȃ��Ԑ����덷���v���b�g����ꍇ1
% swAntLoc = 0;    % �n�}�}�b�`���O�E�f�b�h���R�EMPU���Ȉʒu�x�[�X�̑��H�`����v���b�g����ꍇ1


swSfnc = 1;      % Resim���[�h�̑I��/SFuncResim:1, ModelResim:2

samples = length(time);

% ���ԉ��_�X�e�[�^�X
if swSfnc == 1
%     laneConfidence =hdfdataM3n200mBusOut_saBusOut_saBusFcLane_log.saVecFcRoadConf.signals.values;
%     laneQuality = hdfdataM3n200mBusOut_saBusOut_saBusFcLane_log.saVecFcRoadQuality.signals.values;
%     laneType = hdfdataM3n200mBusOut_saBusOut_saBusFcLane_log.saVecFcRoadType.signals.values;
end

% eMap = bitget( lmInhStt, 3 );

% lmCtrlX = zeros(length(time),1353);
% lmCtrlY = zeros(length(time),1353);
% lmCamX = zeros(length(time),1004);
% lmCamY = zeros(length(time),1004);
% 
% if swSfnc == 1
%     lmCamX(:,[1:201 252:452]) = hdfdataM3n200mBusOut_lmBusOut_lmBusCLine_log.lmVecClinePointPosX.signals.values;
%     lmCamY(:,[1:201 252:452]) = hdfdataM3n200mBusOut_lmBusOut_lmBusCLine_log.lmVecClinePointPosY.signals.values;
% end

if swSfnc == 1
%     lmCtrlX(:,502:702) = hdfdataM3n200mBusOut_lmBusOut_lmBusCtrl_log.lmVecCtrlLnPntX.signals.values;
%     lmCtrlY(:,502:702) = hdfdataM3n200mBusOut_lmBusOut_lmBusCtrl_log.lmVecCtrlLnPntY.signals.values;
    if swSN == 0
%         cOutFlg = hdfdataM3n200mBusOut_lmBusOut_lmBusCtrl_log.lmVecCtrlLnExistFlg.signals.values;
%         cOutStartIdx(:,2) = hdfdataM3n200mBusOut_lmBusOut_lmBusCtrl_log.lmVecCtrlLnStartIdx.signals.values;
%         cOutEndIdx(:,2) = hdfdataM3n200mBusOut_lmBusOut_lmBusCtrl_log.lmVecCtrlLnEndIdx.signals.values;
    end
end

% curv(:,2) = hdfdataM3n200mBusOut_lmBusOut_lmBusCtrl_log.lmVecCtrlLnPntCurvature.signals.values;
curv = zeros(length(time),3); % 2��ڂ����g��
curv(:,2) = curvOrg;

selectedCtrlStt = rightLineMatch | leftLineMatch;

%% accuracyVerifMF4.m
swDir = 1;                             %���ԑO���̕]��������ꍇ��1�A����̕]��������ꍇ��0
if swDir
    X = 0:100;                         % �J�������T���v�����O�͈�[m]�i���ԑO���j
else
    X = -100:0;                        % �J�������T���v�����O�͈�[m]�i���Ԍ���j
end
% ts = 1.05;                             % ���b��̓_�����邩[s]
tgtPosOrg = [0, 10, 30, 70, 100];      % ���ԑO��(���)**m��̓_�̈ʒu�������v���b�g����
num = length( tgtPosOrg ) + 1;         % tgtPosOrg�̔z��ԍ����w�肷��(length+1��ts[s]����w�肷��)

interPoSagittaThd = 0.1;                      % C0�_�����}�����̍ő�l [m]
interPoDistanceThd = 20;                  % C0�_�����}����_�ԋ����̍ő�l [m]

swExcludeDifferenceLane = 1;            % 1:C0�O�Ղ�Ctrl�Ԑ��̎����Ԑ����قȂ�Ƃ��]�����Ȃ�
differenceLaneCheckDist = 20;                 % C0�O�Ղ�Ctrl�Ԑ��̎����Ԑ����قȂ邩�`�F�b�N����������[m]

swExcludeEMap = 0;                     % 1:eMap�������Ă���Ƃ����H�]�����Ȃ�
swExcludeCtrlStt = 0;                  % 1:���H�I����Ԃ����H����Ă����瑖�H�]�����Ȃ�

swExcludeLowSpeed = 1;                 % 1:�ԑ����x���Ƃ����H�]�����Ȃ�
lowSpeedThd = 20;                       % �ԑ����x���Ƃ����H���x�]�����Ȃ�臒l[km/h]

swExcludeAfterLaneChange = 1;                 % 1:�Ԑ��ύX�̒���͕]�����Ȃ�
afterLaneChangeDistThd = 20;               % �Ԑ��ύX�̒���Ƃ݂Ȃ�����[m]

swExcludeCamLineLostWithEMap = 1;         % 1:eMap�������Ă���ꍇ�́A�J���������������Ă���Ƃ��ȊO�]�����Ȃ�

yDiffLaneChangeThd = 1.8;     % �Ԑ��ύX�Ƃ݂Ȃ����ԉ��_�̕ω��ʂ̍ŏ��l
xDiffLaneChangeThd = 20;     % �Ԑ��ύX�Ƃ݂Ȃ��c�����̕ω��ʂ̍ő�l

% LM���H�̕]�����\�ȏ�Ԃ����肷�邽�߂ɕK�v�ȏ����擾����

% �ԑ����x����Ԃ��𔻒�
lowSpeed = 3.6 * egoSpd < lowSpeedThd;

% 2, C0�O�Ղ̏�Ԃ��擾
% bit 1�@confidence���Ⴂ�i���j
% bit 2�@confidence���Ⴂ�i�E�j
% bit 3�@quality���Ⴂ�i���j
% bit 4�@quality���Ⴂ�i�E�j
% bit 5�@�J�����������Ă��Ȃ��i���j
% bit 6�@�J�����������Ă��Ȃ��i�E�j
% bit 7�@C0�Ԑ����Ԑ��ύX�����^�C�~���O�ł���
% bit 8�@reserve
% bit 9�@reserve
% bit 10 reserve
% bit 11 ������ʂ������n(�����E�j���EDLM�E�����\��)�ȊO�i���j
% bit 12 ������ʂ������n(�����E�j���EDLM�E�����\��)�ȊO�i�E�j
c0PointStt = getC0PointSttMF4( laneConfidence, laneQuality, laneType, lmCamX, lmCamY );

% �J���������g�p�ł��Ȃ���Ԃ��ǂ����𔻒�
% c0�O�Ղ̏�� bit 1, 2, 3, 4, 5, 6, 11, 12 ��
% �����ꂩ�������Ă�����J�������g�p�ł��Ȃ�
% ���������������Ă��Ȃ�
camLineLostL =  bitget( c0PointStt, 1 ) | ...
                bitget( c0PointStt, 3 ) | ...
                bitget( c0PointStt, 5 ) | ...
                bitget( c0PointStt, 11 );

% �E�������������Ă��Ȃ�
camLineLostR =  bitget( c0PointStt, 2 ) | ...
                bitget( c0PointStt, 4 ) | ...
                bitget( c0PointStt, 6 ) | ...
                bitget( c0PointStt, 12 );

%���E�����ꂩ�������Ă��Ȃ�
camLineLost = camLineLostL | camLineLostR;

% C0�Ԑ��ύX�^�C�~���O�𔻒�
% �������@�Ԑ��ύX����
egoLmCamLY = lmCamY( :, 101 );
egoLmCamLB = not( camLineLostL );
laneChangeCamL = getLaneChange( egoLmCamLY, egoLmCamLB, EgoMovX, xDiffLaneChangeThd, yDiffLaneChangeThd ); 

% �E�����@�Ԑ��ύX����
egoLmCamRY = lmCamY( :, 352 );
egoLmCamRB = not( camLineLostR );
laneChangeCamR = getLaneChange( egoLmCamRY, egoLmCamRB, EgoMovX, xDiffLaneChangeThd, yDiffLaneChangeThd ); 

% ���E�����ꂩ���Ԑ��ύX�̂Ƃ��A�Ԑ��ύX�Ɣ���
laneChangeCam = laneChangeCamL | laneChangeCamR;
c0PointStt = bitset( c0PointStt, 7, laneChangeCam );

% ctrl�Ԑ��ύX�^�C�~���O�ӏ��𔻒�
egoCtrlY = lmCtrlY(:, 451+151 ); % Ctrl�Ԑ����ԉ�Y���W
% Ctrl�Ԑ����ԉ�Y���W�L���t���O
egoCtrlB = cOutFlg( :, 2 ) == 1 & ...
       cOutStartIdx( :, 2 ) ~= -1 & cOutEndIdx( :, 2 ) ~= -1 & ...
       cOutStartIdx( :, 2 ) <= 151 & cOutEndIdx( :, 2 ) >= 151;

laneChangeCtrl = getLaneChange( egoCtrlY, egoCtrlB, EgoMovX, xDiffLaneChangeThd, yDiffLaneChangeThd ); %�Ԑ��ύX����
laneChangeCtrl( find( diff( int8( eMap ) ) ) + 1 ) = 0; % eMap���؂�ւ�����^�C�~���O�͖�������

% �Ԑ��ύX�̒���ł��邩�𔻒� 
afterLaneChangeDistCam = getAfterLaneChangeDist( laneChangeCam, EgoMovX ); % C0�O�ՎԐ��ύX����̋���
afterLaneChangeDistCtrl = getAfterLaneChangeDist( laneChangeCtrl , EgoMovX );
laneChangeIdx = find( laneChangeCam | laneChangeCtrl ); % �Ԑ��ύX�^�C�~���O�̃C���f�b�N�X
afterLaneChange = zeros( size( time ) ); % �z�񏉊���
if isempty(laneChangeIdx) == 0
    % �Ԑ��ύX���Ă���̋��������ȓ��̎��A�Ԑ��ύX����Ɣ���
    afterLaneChange( laneChangeIdx(1):end ) = ( afterLaneChangeDistCam( laneChangeIdx(1):end ) < afterLaneChangeDistThd ) | ...
        ( afterLaneChangeDistCtrl( laneChangeIdx(1):end ) < afterLaneChangeDistThd );
end

% C0�O�Ղ�Ctrl�Ԑ��������Ԑ����قȂ邩�ǂ����𔻒�
% �����C0�Ԑ��ύX������A����Ctrl�Ԑ��̎Ԑ��ύX���Ȃ��Ƃ��AC0�O�Ղ�Ctrl�Ԑ��������Ԑ����قȂ�Ɣ���
% ����ɎԐ��ύX������ == �Ԑ��ύX����̋�����臒l��菬����
differenceLane = afterLaneChangeDistCam < differenceLaneCheckDist & ...
                 afterLaneChangeDistCtrl >= afterLaneChangeDistCam + differenceLaneCheckDist; 

% �ڕW�ʒu��Ctrl�Ԑ����g�p�s��
%    ���Ԑ��L���t���O��0 �܂���
%    �ڕW�ʒu�C���f�b�N�X�������l(-1)�@�܂���
%    �ڕW�ʒu�C���f�b�N�X��startIdx�`endIdx�͈̔͊O
tgtCtrlPos = horzcat( ones( samples, length( tgtPosOrg ) ) .* tgtPosOrg, egoSpd .* ts ) + 151;
tgtCtrlOutOfRange = cOutFlg( :, 2 ) == 0 | ...
                    cOutStartIdx( :, 2 ) == -1 | ...
                    cOutEndIdx( :, 2 ) == -1 | ...
                    tgtCtrlPos < cOutStartIdx( :, 2 )+1 | ...
                    tgtCtrlPos > cOutEndIdx( :, 2 )+1;

% C0�O�Ռv�Z
if exist( "TransClineCPosX" ) == 0
[ TransClineCPosX, TransClineCPosY, TransClineStt, TransEgoPosYi, EgoPosRot, TransClineLPosX, TransClineLPosY, TransClineRPosX, TransClineRPosY, TransRadius ] ...
    = makeC0TraceMF4( EgoMovX, EgoMovY, EgoRot, lmCamY, curv, c0PointStt, samples );
end

% ������
tgtDiffy = zeros(samples,length(tgtPosOrg)+1);
tgtStt = zeros(samples,length(tgtPosOrg)+1);
tgtExcludedStt = zeros( samples, length(tgtPosOrg)+1 );

% �ڕW�Ƃ���ʒu�ł�C0�O�Ղ�LM���H�ʒu�����Z�o
for i = 1 : samples

    %%% 244
    tgtPos = [ tgtPosOrg egoSpd(i,1)*ts ];
    %%% 261
    pStt_rs = interPoC0SttMF4( TransClineCPosX(i,:), TransClineCPosY(i,:), TransClineStt(i,:), X', TransRadius( i, : ), interPoSagittaThd, interPoDistanceThd );

    %% �`��Ɏg�p����6��ڂ̂݌v�Z
%     for tgt = 1 : length(tgtPos)
    for tgt = num : length(tgtPos)
%         if tgt > length(tgtPosOrg) || swWidth
            % �ڕW�Ƃ���ʒu�ł�C0�X�e�[�^�X
            ceilTgtPos = int16(ceil(tgtPos(tgt)));
            if ceilTgtPos == 0
                floorTgtPos = 0;
%                 roundTgtPos = 0;
            else
                floorTgtPos = int16(floor(tgtPos(tgt)));
%                 roundTgtPos = int16(round(tgtPos(tgt)));
            end
%         else
%             roundTgtPos = int16(tgtPos(tgt));
%         end

        [pC_rs(:,1), pC_rs(:,2), bwIdxC] = interPoC0(TransEgoPosYi(i,:), TransClineCPosX(i,:), TransClineCPosY(i,:), X');

        % C0�O��
        if tgt > length(tgtPosOrg)
            if (floorTgtPos>=0)&&(ceilTgtPos>=0)
                tgtStt( i, tgt ) = bitor( pStt_rs( floorTgtPos+1 ), pStt_rs( ceilTgtPos+1 ) ); % �ڕW�Ƃ���ʒu(1.05�b��)�̑O��̓_���Q�Ƃ���
                tgtC0XC(i,tgt) = tgtPos(tgt);
                tgtC0YC(i,tgt) = pC_rs(floorTgtPos+1,2) ...
                + ( pC_rs(ceilTgtPos+1,2) - pC_rs(floorTgtPos+1,2) ) * ( tgtPos(tgt) - pC_rs(floorTgtPos+1,1) ) ...
                / ( pC_rs(ceilTgtPos+1,1) - pC_rs(floorTgtPos+1,1) );
%                 if swXPosErr
%                     tgtC0YCBfr(i,tgt) = pC_rsBfr(floorTgtPos+1,2) + ( pC_rsBfr(ceilTgtPos+1,2) - pC_rsBfr(floorTgtPos+1,2) ) * ( tgtPos(tgt) - pC_rsBfr(floorTgtPos+1,1) ) / ( pC_rsBfr(ceilTgtPos+1,1) - pC_rsBfr(floorTgtPos+1,1) );
%                     tgtC0YCAft(i,tgt) = pC_rsAft(floorTgtPos+1,2) + ( pC_rsAft(ceilTgtPos+1,2) - pC_rsAft(floorTgtPos+1,2) ) * ( tgtPos(tgt) - pC_rsAft(floorTgtPos+1,1) ) / ( pC_rsAft(ceilTgtPos+1,1) - pC_rsAft(floorTgtPos+1,1) );
%                 end
            end
%         else
%             tgtStt( i, tgt ) = pStt_rs( tgtPos(tgt)+1 ); % �ڕW�Ƃ���ʒu�̓_�����̂܂܎g�p����
% 
%             tgtC0XC(i,tgt) = pC_rs(tgtPos(tgt)+1,1);
%             tgtC0YC(i,tgt) = pC_rs(tgtPos(tgt)+1,2);
        end

        % LM���H�ʒu���o        
        if tgt > length(tgtPosOrg)
%             if swDir == 0
%                 ceilTgtPos = int16(ceil(-tgtPos(tgt)));
%                 floorTgtPos = int16(floor(-tgtPos(tgt)));
%                 tgtCtrlX(i,tgt) = -(100+floorTgtPos);
%                 tgtCtrlY(i,tgt) = lmCtrlY(i,151+451-(100+floorTgtPos));
%             else
                tgtCtrlX(i,tgt) = tgtPos(tgt);
                tgtCtrlY(i,tgt) = lmCtrlY(i,151+451+floorTgtPos) ...
                + ( lmCtrlY(i,151+451+ceilTgtPos) - lmCtrlY(i,151+451+floorTgtPos) ) * ( tgtPos(tgt) - lmCtrlX(i,151+451+floorTgtPos) ) ...
                / ( lmCtrlX(i,151+451+ceilTgtPos) - lmCtrlX(i,151+451+floorTgtPos) );
%             end
%             if swAntLoc
%                 tgtCtrlXMpu(i,tgt) = tgtPos(tgt);   tgtCtrlYMpu(i,tgt) = lmCtrlYBsMpuLoc(i,151+floorTgtPos) + ( lmCtrlYBsMpuLoc(i,151+ceilTgtPos) - lmCtrlYBsMpuLoc(i,151+floorTgtPos) ) * ( tgtPos(tgt) - lmCtrlXBsMpuLoc(i,151+floorTgtPos) ) / ( lmCtrlXBsMpuLoc(i,151+ceilTgtPos) - lmCtrlXBsMpuLoc(i,151+floorTgtPos) );
%                 tgtCtrlXYrm(i,tgt) = tgtPos(tgt);   tgtCtrlYYrm(i,tgt) = lmCtrlYBsYrmLoc(i,151+floorTgtPos) + ( lmCtrlYBsYrmLoc(i,151+ceilTgtPos) - lmCtrlYBsYrmLoc(i,151+floorTgtPos) ) * ( tgtPos(tgt) - lmCtrlXBsYrmLoc(i,151+floorTgtPos) ) / ( lmCtrlXBsYrmLoc(i,151+ceilTgtPos) - lmCtrlXBsYrmLoc(i,151+floorTgtPos) );
%                 tgtCtrlXDr(i,tgt) = tgtPos(tgt);   tgtCtrlYDr(i,tgt) = lmCtrlYBsDrLoc(i,151+floorTgtPos) + ( lmCtrlYBsDrLoc(i,151+ceilTgtPos) - lmCtrlYBsDrLoc(i,151+floorTgtPos) ) * ( tgtPos(tgt) - lmCtrlXBsDrLoc(i,151+floorTgtPos) ) / ( lmCtrlXBsDrLoc(i,151+ceilTgtPos) - lmCtrlXBsDrLoc(i,151+floorTgtPos) );
%             end 
%         else
%             tgtCtrlX(i,tgt) = lmCtrlX(i,151+451+tgtPos4Ctrl(tgt));
%             tgtCtrlY(i,tgt) = lmCtrlY(i,151+451+tgtPos4Ctrl(tgt));
%             if swAntLoc
%                 tgtCtrlXMpu(i,tgt) = lmCtrlXBsMpuLoc(i,151+tgtPos4Ctrl(tgt));   tgtCtrlYMpu(i,tgt) = lmCtrlYBsMpuLoc(i,151+tgtPos4Ctrl(tgt));
%                 tgtCtrlXYrm(i,tgt) = lmCtrlXBsYrmLoc(i,151+tgtPos4Ctrl(tgt));   tgtCtrlYYrm(i,tgt) = lmCtrlYBsYrmLoc(i,151+tgtPos4Ctrl(tgt));
%                 tgtCtrlXDr(i,tgt) = lmCtrlXBsDrLoc(i,151+tgtPos4Ctrl(tgt));   tgtCtrlYDr(i,tgt) = lmCtrlYBsDrLoc(i,151+tgtPos4Ctrl(tgt));
%             end
        end

        %%% �ڕW�ʒu���]�������Ȃ�����
        % bit  1 ���x���x��
        % bit  2 LM�n�}�g�p�s���J�������Е������Ă��Ȃ�
        % bit  3 �Ԑ��ύX�̒���
        % bit  4 C0�O�Ղ�Ctrl�Ԑ��̎����Ԑ����قȂ�
        % bit  5 reserve
        % bit  6 reserve
        % bit  7 �O���Ԑ��ύX
        % bit  8 reserve
        % bit  9 �ڕW�ʒu�O���C0�̓_�ԋ��������ꂷ���Ă���
        % bit 10 �ڕW�ʒu��C0���S���v�Z�ł��Ȃ�
        % bit 11 �ڕW�ʒu��C0���������n�ȊO
        % bit 12 �ڕW�ʒu��C0�E�������n�ȊO
        % bit 13 �ڕW�ʒu��C0���S���W��(0,0)
        % bit 14 �ڕW�ʒu��Ctrl�Ԑ�������
        % bit 15 �ڕW�ʒu��Ctrl�Ԑ����W��(0,0)
        % bit 16 LM�n�}�g�p�s��
        % bit 17 Ctrl�Ԑ��������H����Ă���

       % �ڕW�ʒu���]�����O�����X�e�[�^�X���擾
        tgtExcludedStt( i, tgt ) = bitset( 0,  1, ( swExcludeLowSpeed && lowSpeed(i) ) ) + ...
                                   bitset( 0,  2, ( swExcludeCamLineLostWithEMap && eMap(i) && camLineLost(i) ) ) + ...
                                   bitset( 0,  3, ( swExcludeAfterLaneChange && afterLaneChange(i) ) ) + ...
                                   bitset( 0,  4, ( swExcludeDifferenceLane && differenceLane(i) )  )+ ...
                                   bitset( 0,  7, ( bitget( tgtStt(i,tgt ),  7 ) == 1 ) ) + ...
                                   bitset( 0,  9, ( bitget( tgtStt(i,tgt ),  9 ) == 1 ) ) + ...
                                   bitset( 0, 10, ( bitget( tgtStt(i,tgt ), 10 ) == 1 ) ) + ...
                                   bitset( 0, 11, ( bitget( tgtStt(i,tgt ), 11 ) == 1 ) ) + ...
                                   bitset( 0, 12, ( bitget( tgtStt(i,tgt ), 12 ) == 1 ) ) + ...
                                   bitset( 0, 13, ( tgtC0XC( i, tgt ) == 0 && tgtC0YC( i, tgt ) == 0  ) ) + ...
                                   bitset( 0, 14, ( tgtCtrlOutOfRange( i, tgt ) ) ) + ...
                                   bitset( 0, 15, ( tgtCtrlX( i, tgt ) == 0 && tgtCtrlY( i, tgt ) == 0  ) ) + ...
                                   bitset( 0, 16, ( swExcludeEMap && eMap( i )  ) ) + ...
                                   bitset( 0, 17, ( swExcludeCtrlStt && selectedCtrlStt( i )  ) );

        % �]�����O�����X�e�[�^�X��0�ȊO�ł���Ε]�����Ȃ�       
        if tgtExcludedStt( i, tgt ) ~= 0
            tgtDiffy(i,tgt) = NaN;
        else
            % �ڕW�Ƃ���ʒu�ł�C0�O�ՂƂ�y����        
            tgtDiffy(i,tgt) = tgtCtrlY(i,tgt) - tgtC0YC(i,tgt);
        end
    end
end
end
%%% accuracyVerifMF4
function c0PointStt = getC0PointSttMF4( laneConfidence, laneQuality, laneType, linePointPosX, linePointPosY )
    % ���E�̃J���������M���x���i�[
    laneConfidenceL = laneConfidence( :, 1 );
    laneConfidenceR = laneConfidence( :, 2 );

    % ���E�̃J���������i�����i�[
    laneQualityL = laneQuality( :, 1 );
    laneQualityR = laneQuality( :, 2 );
    
    % ���E�̃J����������ʂ��i�[
    laneTypeL = laneType( :, 1 );
    laneTypeR = laneType( :, 2 );
    
    % ��M���x�t���O����
    lowConfidenceL = laneConfidenceL < 0.1;
    lowConfidenceR = laneConfidenceR < 0.1;
    
    % ��i���t���O����
    lowQualityL = laneQualityL < 3;
    lowQualityR = laneQualityR < 3;
    
    % �����ȊO�̎�ʔ���
    lineTypeL = ( (laneTypeL == 1) + (laneTypeL == 2) + (laneTypeL == 4) + (laneTypeL == 10) ) == 0;
    lineTypeR = ( (laneTypeR == 1) + (laneTypeR == 2) + (laneTypeR == 4) + (laneTypeR == 10) ) == 0;
    
    % ���E�̃J�����������W���i�[
    xDistL = linePointPosX( :, 101 );
    xDistR = linePointPosX( :, 352 );
    yDistL = linePointPosY( :, 101 );
    yDistR = linePointPosY( :, 352 );

    % �J���������Ă��Ȃ�����
    noLinePointL = not( logical( xDistL ) ) & not( logical( yDistL ) );
    noLinePointR = not( logical( xDistR ) ) & not( logical( yDistR ) );
    
    c0PointStt = lowConfidenceL * 1 + ...
                 lowConfidenceR * 2 + ...
                 lowQualityL * 4 + ...
                 lowQualityR * 8 + ...
                 noLinePointL * 16 + ...
                 noLinePointR * 32 + ...
                 lineTypeL * 1024 + ...
                 lineTypeR * 2048;
                 
end

% getLaneChange
% �Ԑ��ύX����
% input:
%   egoPointY           ���ԉ��_���W�i���j
%   egoPointFlag        ���ԉ��_�L���t���O
%   egoMoveX            ���Ԉړ��ʁi�c�j
%   xDiffLaneChangeThd  �Ԑ��ύX�Ɣ��肷��c����������臒l�@���������̒l�ȏ�̂Ƃ��͎Ԑ��ύX�Ɣ��肵�Ȃ�
%   yDiffLaneChangeThd  �Ԑ��ύX�Ɣ��肷�鉡����������臒l�@���������̒l���傫���Ƃ��Ԑ��ύX�Ɣ��肷��
% output:
%   laneChangeFlag      �Ԑ��ύX�t���O
function laneChangeFlag = getLaneChange( egoPpointY, egoPointFlag, egoMoveX, xDiffLaneChangeThd, yDiffLaneChangeThd )
    % �L���_�̃C���f�b�N�X�擾
    enableIndex = find( egoPointFlag );
    
    % �O�̗L���_����̏c�����̕ω��ʂ����Ԉړ��ʂ���v�Z
    xDiff = zeros( size( egoMoveX ) );    
    for i = 2:length( enableIndex )
        xDiff( enableIndex( i ) ) = sum( egoMoveX( ( enableIndex( i - 1 )+1  ):enableIndex( i )  ) );
    end
    
    % �O�̗L���_����̉������̕ω��ʂ����ԉ�Y���W����v�Z
    yDiff = zeros( size( egoPpointY ) );
    yDiff( enableIndex( 2:end ) ) = abs( egoPpointY( enableIndex( 2:end ) ) - egoPpointY( enableIndex( 1:(end-1) ) ) );
    
    % �c�����̕ω��ʂ�臒l�����@���@Y�ω��ʂ�臒l���傫���Ƃ��@�Ԑ��ύX�Ɣ��肷��@ 
    laneChangeFlag = xDiff < xDiffLaneChangeThd & ...
                     yDiff > yDiffLaneChangeThd;
    
end

% getAfterLaneChangeDist
% �Ԑ��ύX����̋������Z�o
% input:
%   laneChange          �Ԑ��ύX�t���O
%   egoMoveX            ���Ԉړ��ʁi�c�j
% output:
%   afterLaneChangeDist �Ԑ��ύX���Ă���̋���
function afterLaneChangeDist = getAfterLaneChangeDist( laneChange, egoMoveX )

    afterLaneChangeDist = 10000 * ones( size( laneChange ) ); %������
    totalEgoMoveDist = cumsum( egoMoveX ); %�f�[�^�̎n�߂���̑��ړ�����
    laneChangeIdx = find( laneChange ); % �Ԑ��ύX�^�C�~���O�̃C���f�b�N�X�擾
    if isempty(laneChangeIdx)
        return
    end
    for i = 1:length( laneChangeIdx )-1 % �Ԑ��ύX�� - 1 �񃋁[�v
        startIdx = laneChangeIdx( i );      %�Ԑ��ύX����
        endIdx = laneChangeIdx( i+1 )-1;    %���̎Ԑ��ύX���O�܂�
        % �Ԑ��ύX�^�C�~���O�̑��ړ��������I�t�Z�b�g���ĎԐ��ύX����̈ړ��������v�Z
        afterLaneChangeDist( startIdx:endIdx ) = totalEgoMoveDist( startIdx:endIdx ) - totalEgoMoveDist( startIdx );
    end
    startIdx = laneChangeIdx( end );        % �Ō�̎Ԑ��ύX����
    endIdx = length( afterLaneChangeDist ); % �f�[�^�̍Ō�܂�
    % �Ԑ��ύX�^�C�~���O�̑��ړ��������I�t�Z�b�g���ĎԐ��ύX����̈ړ��������v�Z
    afterLaneChangeDist( startIdx:endIdx ) = totalEgoMoveDist( startIdx:endIdx ) - totalEgoMoveDist( startIdx );

end

function [ TransClineCPosX, TransClineCPosY, TransClineStt, TransEgoPosYi, EgoPosRot, TransClineLPosX, TransClineLPosY, TransClineRPosX, TransClineRPosY, TransRadius ] = makeC0TraceMF4( EgoMovX, EgoMovY, EgoRot, lmCamY, curv, c0PointStt, samples )
    for j=1:4
        for i=1:251
            ClinePointY(i,j,:) = lmCamY(:,(251*(j-1))+i);
        end
    end

    ClineLPosY = squeeze(ClinePointY(101,1,:));
    ClineLPosX = zeros(size(ClineLPosY));
    ClineRPosY = squeeze(ClinePointY(101,2,:));
    ClineRPosX = zeros(size(ClineRPosY));
    TransRadius = zeros( samples, 101 );
    
    radius = 1./curv( :, 2 );

    TransEgoPosYi = zeros(length( EgoMovX ),101);
    TransClineLPosX = zeros(length( EgoMovX ),101);
    TransClineLPosY = zeros(length( EgoMovX ),101);
    TransClineRPosX = zeros(length( EgoMovX ),101);
    TransClineRPosY = zeros(length( EgoMovX ),101);
    TransClineStt = zeros(length( EgoMovX ),101);
    TransClineCPosX = zeros(length(EgoMovX),101);
    TransClineCPosY = zeros(length(EgoMovX),101);
    samples = min(length(TransClineLPosX),length(ClineLPosY));

    EgoPosRot = zeros(1, size(EgoRot,1));
    for i=2:samples
        EgoPosRot(i) = EgoPosRot(i-1) + EgoRot(i);
    end
    
    for i=1:samples
    %       fprintf('loop%d���\n',i);
    %             fprintf('�J�����O�Ճf�[�^�쐬\n');
        if i+50 < samples
            end_frame = i+50;
        else
            end_frame = samples;
        end
        if i-50 >= 1
            start_frame = i-50;
        else
            start_frame = 1;
        end

        TransEgoPosX = [0.];
        TransEgoPosY = [0.];
        TransEgoPosRot = EgoPosRot(:) - EgoPosRot(i);
        % ���
        for j=i-1:-1:start_frame
            TransEgoPosX = [TransEgoPosX(1)-(EgoMovX(j+1)*cos(TransEgoPosRot(j))-EgoMovY(j+1)*sin(TransEgoPosRot(j))) TransEgoPosX];
            TransEgoPosY = [TransEgoPosY(1)-(EgoMovX(j+1)*sin(TransEgoPosRot(j))+EgoMovY(j+1)*cos(TransEgoPosRot(j))) TransEgoPosY];    % �J�����f���Ƃ̔�r�̂��߁A���𕉂Ƃ��Ĉ���
        end
        % �O��
        for j=i+1:end_frame
            TransEgoPosX = [TransEgoPosX TransEgoPosX(end)+(EgoMovX(j)*cos(TransEgoPosRot(j-1))-EgoMovY(j)*sin(TransEgoPosRot(j-1)))];
            TransEgoPosY = [TransEgoPosY TransEgoPosY(end)+(EgoMovX(j)*sin(TransEgoPosRot(j-1))+EgoMovY(j)*cos(TransEgoPosRot(j-1)))];    % �J�����f���Ƃ̔�r�̂��߁A���𕉂Ƃ��Ĉ���
        end

        for j=start_frame:end_frame
            TransRadius(i,j+1-start_frame) = radius( j );
            cnt = 0;
            TransEgoPosYi(i,j+1-start_frame) = TransEgoPosY(j+1-start_frame);
            TransClineLPosX(i,j+1-start_frame) = TransEgoPosX(j+1-start_frame) + ClineLPosX(j) * cos(TransEgoPosRot(j)) - ClineLPosY(j) * sin(TransEgoPosRot(j));
            TransClineLPosY(i,j+1-start_frame) = TransEgoPosY(j+1-start_frame) + ClineLPosX(j) * sin(TransEgoPosRot(j)) + ClineLPosY(j) * cos(TransEgoPosRot(j));        
            TransClineRPosX(i,j+1-start_frame) = TransEgoPosX(j+1-start_frame) + ClineRPosX(j) * cos(TransEgoPosRot(j)) - ClineRPosY(j) * sin(TransEgoPosRot(j));
            TransClineRPosY(i,j+1-start_frame) = TransEgoPosY(j+1-start_frame) + ClineRPosX(j) * sin(TransEgoPosRot(j)) + ClineRPosY(j) * cos(TransEgoPosRot(j));
            TransClineStt(i,j+1-start_frame) = c0PointStt( j );

            if ((ClineLPosX(j)==0)&&(ClineLPosY(j)==0))&&~((ClineRPosX(j)==0)&&(ClineRPosY(j)==0))
                TransClineLPosX(i,j+1-start_frame) = NaN;
                TransClineLPosY(i,j+1-start_frame) = NaN;
                cnt = cnt + 1;
            end
            if ((ClineRPosX(j)==0)&&(ClineRPosY(j)==0))&&~((ClineLPosX(j)==0)&&(ClineLPosY(j)==0))
                TransClineRPosX(i,j+1-start_frame) = NaN;
                TransClineRPosY(i,j+1-start_frame) = NaN;
                cnt = cnt + 1;
            end

            % C0���S���v�Z
            if cnt > 0
                TransClineCPosX(i,j+1-start_frame) = NaN;
                TransClineCPosY(i,j+1-start_frame) = NaN;
            else
                TransClineCPosX(i,j+1-start_frame) = (TransClineLPosX(i,j+1-start_frame) + TransClineRPosX(i,j+1-start_frame))/2;
                TransClineCPosY(i,j+1-start_frame) = (TransClineLPosY(i,j+1-start_frame) + TransClineRPosY(i,j+1-start_frame))/2;
            end
        end
    end
end

function [ReturndataX, ReturndataY, CenterIdx] = interPoC0(tEgoMoveY, tClineX, tClineY, SourceL)
%���͂����l��Idx�����@�����琳
%20191224�쐬�f�[�^�͈͂��S�ĕ��̍ۂɈ�ԑ傫�Ȓl���ςȒl�ƂȂ�o�O���C��

% �O����
c0TraceX = tClineX(abs(tEgoMoveY - tClineY)>0.01);
c0TraceY = tClineY(abs(tEgoMoveY - tClineY)>0.01);
if isempty(c0TraceX) || isempty(c0TraceY) || (length(c0TraceX) < 3) || (length(c0TraceY) < 3)
    ReturndataX = zeros(101,1);
    ReturndataY = zeros(101,1);
    CenterIdx = 0;
    return;
end
tf1L = isfinite(c0TraceX(1,:));

%�f�[�^�^���킹
SourceX = squeeze(c0TraceX(tf1L));
SourceY = squeeze(c0TraceY(tf1L));
SourceL = squeeze(SourceL);
PointX = zeros(length(SourceL),1);
PointY = zeros(length(SourceL),1);

%�@X,Y�̃f�[�^���Ⴂ�Ή�
if length(SourceX) < (SourceY)
    LengthData = length(SourceX);
else
    LengthData = length(SourceY);
end

RangeDetected = 0;

%%����f�[�^�n�_�ԍ�����
for cnt1 = 1 : length(SourceL)
    if SourceL(cnt1) == 0
        ReturnCenterIdx = cnt1;
        rangeDetected = 1; % Range��0�_������
        break;
    elseif SourceL(cnt1) > 0
        ReturnCenterIdx = cnt1;
        rangeDetected = 2; % Range���S�Đ�
        break;
    else
        ReturnCenterIdx = length(SourceL);
        rangeDetected = 3; % Range���S�ĕ�
    end
end
% ReturnCenterIdxTmp = ReturnCenterIdx;
% rangeDetectedTmp = rangeDetected;

%%�����ʒu�v�Z
SeppenId = 1;
detected = 0;
%0�_���ׂ��_���������T��
for cnt1 = 2:LengthData
    if SourceX(cnt1 - 1) < 0 && 0 <= SourceX(cnt1)
        SeppenId =cnt1;
        detected =1;
    end
end
% tmp1 = SeppenId;
% tmp2 = detected;

%�ׂ��Ȃ��p�^�[�� -> X>0�Ő�����0���牓������ꍇ�͏������֌v�Z/X<0�Ő�����0�֋߂Â��ꍇ�͋t�����ց@����ȊO�͍l�����Ȃ�
if detected == 0
    if (SourceX(1) < 0) && hypot(SourceX(1),SourceY(1)) > hypot(SourceX(end),SourceY(end))
        SeppenId = LengthData;
    end

end
% tmp1 = SeppenId;
% tmp2 = detected;

%%�ؕЌv�Z
if SeppenId == 1
    SeppenX = 0;
    SeppenY = SourceY(1) - (SourceY(2) - SourceY(1)) / (SourceX(2) - SourceX(1)) * SourceX(1);
elseif  SeppenId == LengthData
    SeppenX = 0;
    SeppenY = SourceY(SeppenId) - (SourceY(SeppenId) - SourceY(SeppenId - 1)) / (SourceX(SeppenId) - SourceX(SeppenId - 1)) * SourceX(SeppenId);
else
    SeppenX = 0;
    SeppenY = SourceY(SeppenId) - (SourceY(SeppenId) - SourceY(SeppenId - 1)) / (SourceX(SeppenId) - SourceX(SeppenId - 1)) * SourceX(SeppenId);
end
% tmp1 = SeppenX;
% tmp2 = SeppenY;

%�w��Ԋu�̃p�^�[��������

cnt2 = 1;
if rangeDetected == 1
    PointX(ReturnCenterIdx,1) = SeppenX;
    PointY(ReturnCenterIdx,1) = SeppenY;
elseif rangeDetected == 3
    ReturnCenterIdx = ReturnCenterIdx + 1;
end
% tmp1 = PointY;
% tmp2 = ReturnCenterIdx;
% tmp1 = PointX;
% tmp2 = PointY;

%�������쐬
tempX = SeppenX;
tempY = SeppenY;
tempL = 0;
cntId = SeppenId;

for cnt2 = ReturnCenterIdx : length(SourceL)
    detectedFlg = 0;

    while(cntId <= LengthData && cntId > 0)
        if hypot(tempX - SourceX(cntId), tempY - SourceY(cntId)) >= abs(SourceL(cnt2) - tempL) && hypot(tempX - SourceX(cntId), tempY - SourceY(cntId)) ~= 0
            PointX(cnt2,1) = cos(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempX;
            PointY(cnt2,1) = sin(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempY;
            detectedFlg = 1;
            break;
        else
            cntId = cntId + 1;
        end
    end
    if detectedFlg
        tempX = PointX(cnt2,1);
        tempY = PointY(cnt2,1);
    else
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end

    if detected ~=1 && cntId == SeppenId
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end


    tempL = SourceL(cnt2);
end
tmp1 = PointX;
tmp2 = PointY;

%�t�����쐬
if detected
    cntId = SeppenId - 1;
else
    cntId = SeppenId;
end
tempX = SeppenX;
tempY = SeppenY;
tempL = 0;

for cnt2 = ReturnCenterIdx - 1 : -1 : 1
    detectedFlg = 0;

    while(cntId <= LengthData && cntId > 0)
        if hypot(tempX - SourceX(cntId), tempY - SourceY(cntId)) >= abs(SourceL(cnt2) - tempL) && hypot(tempX - SourceX(cntId), tempY - SourceY(cntId)) ~= 0
            PointX(cnt2,1) = cos(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempX;
            PointY(cnt2,1) = sin(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempY;
            detectedFlg = 1;
            break;
        else
            cntId = cntId -1;
        end
    end
    if detectedFlg
        tempX = PointX(cnt2,1);
        tempY = PointY(cnt2,1);
    else
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end

    if detected ~=1 && cntId == SeppenId
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end

    tempL = SourceL(cnt2);

end


ReturndataX = PointX;
ReturndataY = PointY;
CenterIdx = SeppenId;

end

function ReturndataStt = interPoC0SttMF4( tClineX, tClineY, tClineStt, SourceL, tRadius, interPoSagittaThd, interPoDistanceThd )
%���͂����l��Idx�����@�����琳
%20191224�쐬�f�[�^�͈͂��S�ĕ��̍ۂɈ�ԑ傫�Ȓl���ςȒl�ƂȂ�o�O���C��

% �O����
%c0TraceX = tClineX(abs(tEgoMoveY - tClineY)>0.001);
%c0TraceY = tClineY(abs(tEgoMoveY - tClineY)>0.001);
%c0TraceStt = tClineStt(abs(tEgoMoveY - tClineY)>0.001);

c0TraceX = tClineX;
c0TraceY = tClineY;
c0TraceStt = tClineStt;

lowConfidenceL = bitget( tClineStt, 1 );
lowConfidenceR = bitget( tClineStt, 2 );
lowQualityL = bitget( tClineStt, 3 );
lowQualityR = bitget( tClineStt, 4 );
noLinePointL = bitget( tClineStt, 5 );
noLinePointR = bitget( tClineStt, 6 );
laneChange = bitget( tClineStt, 7 );
lineTypeL = bitget( tClineStt, 11 );
lineTypeR = bitget( tClineStt, 12 );


for i = 1:length( tClineStt )
    if lowConfidenceL( i ) == 1 || lowConfidenceR( i ) == 1 ...
            || lowQualityL( i ) == 1 || lowQualityR( i ) == 1 ...
            || noLinePointL( i ) == 1 || noLinePointR( i ) == 1 ...
            || lineTypeL( i ) == 1 || lineTypeR( i ) == 1
        c0TraceX( i ) = NaN;
        c0TraceY( i ) = NaN;
    end
end

%{
if laneChange( 51 ) == 1
    c0TraceStt( 51 ) = bitset( c0TraceStt( 51 ), 8, 0 );
end
%}
if isempty(c0TraceX) || isempty(c0TraceY) || (length(c0TraceX) < 3) || (length(c0TraceY) < 3)
    ReturndataX = zeros(101,1);
    ReturndataY = zeros(101,1);
    ReturndataStt = zeros(101,1);
    CenterIdx = 0;
    return;
end
tf1L = isfinite(c0TraceX(1,:));  

%�f�[�^�^���킹
SourceX = squeeze(c0TraceX(tf1L));
SourceY = squeeze(c0TraceY(tf1L));
SourceStt = squeeze(c0TraceStt(tf1L));
SourceL = squeeze(SourceL);
PointX = zeros(length(SourceL),1);
PointY = zeros(length(SourceL),1);
PointStt = zeros(length(SourceL),1);

%�@X,Y�̃f�[�^���Ⴂ�Ή�
if length(SourceX) < (SourceY)
    LengthData = length(SourceX);
else
    LengthData = length(SourceY);
end
if LengthData == 0
    ReturndataStt =  bitset( zeros(length(SourceL),1), 10 );
    ReturndataX = zeros(101,1);
    ReturndataY = zeros(101,1);
    CenterIdx = 0;
    return;
end

RangeDetected = 0;

%%����f�[�^�n�_�ԍ�����
for cnt1 = 1 : length(SourceL)
    if SourceL(cnt1) == 0
        ReturnCenterIdx = cnt1;
        rangeDetected = 1; % Range��0�_������
        break;
    elseif SourceL(cnt1) > 0
        ReturnCenterIdx = cnt1;
        rangeDetected = 2; % Range���S�Đ�
        break;
    else
        ReturnCenterIdx = length(SourceL);
        rangeDetected = 3; % Range���S�ĕ�
    end
end
% ReturnCenterIdxTmp = ReturnCenterIdx;
% rangeDetectedTmp = rangeDetected;

%%�����ʒu�v�Z
SeppenId = 1;
detected = 0;
%0�_���ׂ��_���������T��
for cnt1 = 2:LengthData
    if SourceX(cnt1 - 1) < 0 && 0 <= SourceX(cnt1)
        SeppenId =cnt1;
        detected =1;
    end
end
% tmp1 = SeppenId;
% tmp2 = detected;

%�ׂ��Ȃ��p�^�[�� -> X>0�Ő�����0���牓������ꍇ�͏������֌v�Z/X<0�Ő�����0�֋߂Â��ꍇ�͋t�����ց@����ȊO�͍l�����Ȃ�
if detected == 0
    if (SourceX(1) < 0) && hypot(SourceX(1),SourceY(1)) > hypot(SourceX(end),SourceY(end))
        SeppenId = LengthData;
    end
    
end
% tmp1 = SeppenId;
% tmp2 = detected;

%%�ؕЌv�Z
if SeppenId == 1
    SeppenX = 0;
    if length( SourceY ) == 1
        SeppenY = SourceY( 1 );
        SeppenStt = SourceStt( 1 );
    else
        SeppenY = SourceY(1) - (SourceY(2) - SourceY(1)) / (SourceX(2) - SourceX(1)) * SourceX(1);
        SeppenStt = SourceStt( 2 );
    end
elseif  SeppenId == LengthData
    SeppenX = 0;
    SeppenY = SourceY(SeppenId) - (SourceY(SeppenId) - SourceY(SeppenId - 1)) / (SourceX(SeppenId) - SourceX(SeppenId - 1)) * SourceX(SeppenId);
    SeppenStt = SourceStt( SeppenId );
else
    SeppenX = 0;
    SeppenY = SourceY(SeppenId) - (SourceY(SeppenId) - SourceY(SeppenId - 1)) / (SourceX(SeppenId) - SourceX(SeppenId - 1)) * SourceX(SeppenId);
    SeppenStt = SourceStt( SeppenId );
end

% tmp1 = SeppenX;
% tmp2 = SeppenY;

%�w��Ԋu�̃p�^�[��������

cnt2 = 1;
if rangeDetected == 1
    PointX(ReturnCenterIdx,1) = SeppenX;
    PointY(ReturnCenterIdx,1) = SeppenY;
    PointStt(ReturnCenterIdx,1) = SeppenStt;
elseif rangeDetected == 3
    ReturnCenterIdx = ReturnCenterIdx + 1;
end
% tmp1 = PointY;
% tmp2 = ReturnCenterIdx;
% tmp1 = PointX;
% tmp2 = PointY;

%�������쐬
tempX = SeppenX;
tempY = SeppenY;
tempL = 0;
cntId = SeppenId;
tempCntId = cntId;

laneChangeFlg = 0;

c0TraceIdx = find( not( isnan( c0TraceX ) ) );

if bitget( tClineStt( 51 ), 1 ) || bitget( tClineStt( 51 ), 2 ) || ...
        bitget( tClineStt( 51 ), 3 ) || bitget( tClineStt( 51 ), 4 ) || ... 
        bitget( tClineStt( 51 ), 5 ) || bitget( tClineStt( 51 ), 6 ) 
    tempCntId = tempCntId - 1;
    while( tempCntId > 0 && ( bitget( tClineStt( c0TraceIdx( tempCntId ) ), 5 ) == 1 || bitget( tClineStt( c0TraceIdx( tempCntId ) ), 6 ) == 1 ) )
        tempCntId = tempCntId - 1;
    end

    if tempCntId > 1
        tempX = SourceX( tempCntId );
        tempY = SourceY( tempCntId );
        tempL = tempX;
        tempStt = SourceStt( tempCntId );
        %SourceL = vertcat( tempL, SourceL );
    else
        tempCntId = cntId;
    end
end

for cnt2 = ReturnCenterIdx : length(SourceL)
    detectedFlg = 0;
    sagittaFlg = 0;
    
    while(cntId <= LengthData && cntId > 0)
        if SourceX( cntId ) > SourceL( cnt2 )
            PointX(cnt2,1) = cos(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempX;
            PointY(cnt2,1) = sin(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempY;

            if cntId > 1
                %distance = hypot( SourceX(cntId) - SourceX(cntId - 1), SourceY(cntId) - SourceY(cntId - 1) );
                distance = abs( SourceX(cntId) - SourceX(cntId - 1) );
                                
                aboveDistance = abs( SourceX( cntId ) - SourceL( cnt2 ) );
                behindDistance = abs( SourceL( cnt2 ) - SourceX( cntId - 1 ) );
                
                c0TraceIdx = find( not( isnan( c0TraceX ) ) );
                detectedAboveIdx = c0TraceIdx( cntId );
                detectedBehindIdx = c0TraceIdx( cntId - 1 );
                
                aboveIdx = detectedAboveIdx - floor( (detectedAboveIdx - detectedBehindIdx) * ( aboveDistance / distance ) ) ;
                behindIdx = detectedBehindIdx + floor( (detectedAboveIdx - detectedBehindIdx) * ( behindDistance / distance ) );
                
                aboveStt = c0TraceStt( aboveIdx );
                behindStt = c0TraceStt( behindIdx );
                
                radius = ( tRadius( aboveIdx ) + tRadius( behindIdx ) ) / 2;
                sagitta = abs( calcSagitta( radius, distance ) );
                
                % �_�ԋ��������ꂷ���Ă��Ȃ�������
                % 1, �_�ԋ������̂��̂��������Ȃ�������
                % 2, ����������Ȃ�������
                if ( distance > interPoDistanceThd ) || ...
                   ( sagitta > interPoSagittaThd )

                   PointStt(cnt2,1) = bitset( bitor( aboveStt, behindStt ), 9 );
                   sagittaFlg = 1;
                   
                else
                    PointStt(cnt2,1) = bitor( aboveStt, behindStt );
                    detectedFlg = 1;
                end
                
                % ���ԑO���_�`�ڕW�ʒu�O���_�̊ԂɎԐ��ύX�����邩�A
                % �ڕW�ʒu����_�`�ڕW�ʒu�O���_�i�ڕW�ʒu����_�������j�܂łɎԐ��ύX����Ε]�����Ȃ�
                if isempty( find( laneChange( 52:detectedAboveIdx ), 1 ) ) == 0 || ... 
                   isempty( find( laneChange( (detectedBehindIdx+1):detectedAboveIdx ),1 ) ) == 0
                                        
                    PointStt(cnt2,1) = bitset( PointStt(cnt2,1), 7 );
                    detectedFlg = 0;
                    break;
                end
                
            else
                PointStt(cnt2,1) = c0TraceStt( c0TraceIdx( 1 ) );
            end

            break;
        else
            cntId = cntId + 1;
        end
    end
    if detectedFlg == 1
        %if PointX(cnt2, 1 ) ~= 0 && PointX(cnt2, 1 ) ~= 0 
        %if bitget( PointStt(cnt2, 1 ), 5 ) ~= 0 || bitget( PointStt(cnt2, 1 ), 6 ) ~= 0 
        tempX = PointX(cnt2,1);
        tempY = PointY(cnt2,1);
        %end
        tempCntId = cntId;
        
    else
        if sagittaFlg ~= 1
            PointStt(cnt2,1) = bitset( 0, 10 );
        end
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end
    
    if detected ~=1 && cntId == SeppenId
        %PointStt(cnt2,1) = bitset( 0, 8 );
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end
    
    
    tempL = SourceL(cnt2);
end
tmp1 = PointX;
tmp2 = PointY;

%�t�����쐬
if detected
cntId = SeppenId - 1;
else
cntId = SeppenId;
end    
tempX = SeppenX;
tempY = SeppenY;
tempL = 0;

for cnt2 = ReturnCenterIdx - 1 : -1 : 1
    detectedFlg = 0;
    
    while(cntId <= LengthData && cntId > 0)
        if hypot(tempX - SourceX(cntId), tempY - SourceY(cntId)) >= abs(SourceL(cnt2) - tempL) && hypot(tempX - SourceX(cntId), tempY - SourceY(cntId)) ~= 0
            PointX(cnt2,1) = cos(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempX;
            PointY(cnt2,1) = sin(atan2((SourceY(cntId) - tempY),( SourceX(cntId) - tempX))) * abs(SourceL(cnt2) - tempL) + tempY;
            PointStt(cnt2,1) = SourceStt(cntId );
            detectedFlg = 1;
            break;
        else
            cntId = cntId -1;
        end
    end
    if detectedFlg
        tempX = PointX(cnt2,1);
        tempY = PointY(cnt2,1);
    else
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end
    
    if detected ~=1 && cntId == SeppenId
        PointX(cnt2,1) = NaN;
        PointY(cnt2,1) = NaN;
    end
    
    tempL = SourceL(cnt2);
    
end


% ReturndataX = PointX;
% ReturndataY = PointY;
ReturndataStt = PointStt;
% CenterIdx = SeppenId;

end

function s = calcSagitta( r, L )
    T = L / r;
    H = r * cos( T / 2 );
    s = r - H;
end
%% ��tgtDiffy�֘A




function [ans,rawmoviepath] = CopyMovieGen3(filename,time,datapathlist,Moviefolder,dataVer)
    targettime = name2date(filename);
    if dataVer == "US"
        datanumber = floor(time/900); %���Ԗڂ̃f�[�^���H
        targettime = targettime + seconds(datanumber*900); %�^�[�Q�b�g�ƂȂ�t�@�C���̎���(����)
        disp(datanumber);    
    elseif dataVer == "JP" % JP
        datanumber = floor(time/300);
        targettime = targettime + seconds(datanumber*300);
        disp(datanumber);    

    end
    
  
    
    index = 0;
    dev = duration(100000000,100000000,100000000);
    for i= 1:length(datapathlist)
    
        A = strsplit(datapathlist(i),"\");%�t�@�C�����𒊏o����
        if dataVer == "US"
            srctime = name2date(extractBefore(string(A(end)),"_Axis"));
        else % JP
            srctime = name2date(extractBefore(string(A(end)),"_AXIS"));  

            if ismissing(srctime)
                srctime = name2date(extractBefore(string(A(end)),"_Axis"));
            end
        end
        thisdev = abs(targettime -srctime);
        if dev >thisdev
            dev = thisdev;
            index = i;
        end
    end
    
    if index ==0
        disp("����3�I");
        ans = "dummy";%data�擾�ł��Ȃ���������߂�
        rawmoviepath = "dummy\dummy";
    else
        disp(datapathlist(index));
        try
            copyfile(datapathlist(index),Moviefolder+"\"+string(filename)+"_"+string(time)+".avi");
            disp("�R�s�[����");
        catch
        end
        ans =Moviefolder+"\"+string(filename)+"_"+string(time)+".avi";
        rawmoviepath = datapathlist(index);
    end
end


% Find peaks and vallyes in C0Center
function [furatsukiPeaks, furatsukiValleys, furatsukiPeaksValleys, foundIncidentTimeIdx] = FuratsukiAnalysisPeaksValleys(C0Time, C0Center, ...
    furatsuki_IgnoreTimeNeighbourhood, ...
    furatsuki_IncidentTime, furatsuki_NeighbourhoodLeftRange, furatsuki_NeighbourhoodRightRange, ...
    furatsuki_AnalyzeAllData, furatsuki_noPeaksToFind)

% Calculate number of samples to be ignored
C0SampleTime = mean(diff(C0Time));
minTimeSamples = round(furatsuki_IgnoreTimeNeighbourhood/C0SampleTime);

% Find where incident happened, and also its neighbourhood
% (Separate left and right)
C0Center_ApproachingLeft = C0Center;
C0Center_ApproachingRight = C0Center;

C0Center_ApproachingLeft(C0Center<0.0)=0.0;
C0Center_ApproachingRight(C0Center>=0.0)=0.0;

[~, foundIncidentTimeIdx] = min(abs(C0Time-furatsuki_IncidentTime));
[~, foundBeforeIncidentIdx] = min(abs(C0Time-(furatsuki_IncidentTime - furatsuki_NeighbourhoodLeftRange)));
[~, foundAfterIncidentIdx] = min(abs(C0Time-(furatsuki_IncidentTime + furatsuki_NeighbourhoodRightRange)));

% Protect against few data, or out of bounds limits (on the left)
foundBeforeIncidentIdx = max(foundBeforeIncidentIdx, 1);
foundAfterIncidentIdx = min(foundAfterIncidentIdx, numel(C0Time));

if foundAfterIncidentIdx < (foundBeforeIncidentIdx + 2)
    if foundBeforeIncidentIdx == 1
        foundAfterIncidentIdx = foundBeforeIncidentIdx + 2;
    end
end

if furatsuki_AnalyzeAllData == true

    [furatsukiPeaksVal, furatsukiPeaksLocs] = findpeaks(C0Center_ApproachingLeft, 'NPeaks', furatsuki_noPeaksToFind, 'sortStr', 'descend', 'MinPeakDistance', minTimeSamples);
    [furatsukiValleysVal, furatsukiValleysLocs] = findpeaks(-1.0*C0Center_ApproachingRight, 'NPeaks', furatsuki_noPeaksToFind, 'sortStr', 'descend', 'MinPeakDistance', minTimeSamples);
    furatsukiValleysVal= -1.0*furatsukiValleysVal;

    furatsukiPeaksTimes = C0Time(furatsukiPeaksLocs);
    furatsukiValleysTimes = C0Time(furatsukiValleysLocs);

else

    C0TimeSlice = C0Time(foundBeforeIncidentIdx:foundAfterIncidentIdx);
    C0Center_ApproachingLeftSlice = C0Center_ApproachingLeft(foundBeforeIncidentIdx:foundAfterIncidentIdx);
    C0Center_ApproachingRightSlice = C0Center_ApproachingRight(foundBeforeIncidentIdx:foundAfterIncidentIdx);

    % Protect against small slice
    if minTimeSamples > C0TimeSlice(end) - C0TimeSlice(1)
        minTimeSamples = (C0TimeSlice(end) - C0TimeSlice(1))*0.5;
        furatsuki_noPeaksToFind = 1;
    end

    [furatsukiPeaksVal, furatsukiPeaksLocs] = findpeaks(C0Center_ApproachingLeftSlice, 'NPeaks', furatsuki_noPeaksToFind, 'sortStr', 'descend', 'MinPeakDistance', minTimeSamples);
    [furatsukiValleysVal, furatsukiValleysLocs] = findpeaks(-1.0*C0Center_ApproachingRightSlice, 'NPeaks', furatsuki_noPeaksToFind, 'sortStr', 'descend', 'MinPeakDistance', minTimeSamples);
    furatsukiValleysVal= -1.0*furatsukiValleysVal;

    furatsukiPeaksTimes = C0TimeSlice(furatsukiPeaksLocs);
    furatsukiValleysTimes = C0TimeSlice(furatsukiValleysLocs);

end

furatsukiPeaks = [furatsukiPeaksTimes', furatsukiPeaksVal];
furatsukiValleys = [furatsukiValleysTimes', furatsukiValleysVal];
furatsukiPeaksValleys = sortrows([furatsukiPeaks; furatsukiValleys], 1);

end


