# 系统检测与初始化模块

## 概述

这是一个专门用于Windows系统的驱动器检测和初始化工具，能够自动识别系统中的驱动器类型，支持BitLocker加密驱动器的解锁，并为数据备份操作提供智能的驱动器分类。

## 主要功能

### 1. 自动驱动器检测
- 自动检测系统中所有可用的驱动器
- 获取驱动器的详细信息（容量、使用情况、文件系统等）
- 识别驱动器的卷标和类型

### 2. 智能系统盘识别
- 自动识别Windows系统盘（C盘等）
- 检测EFI分区和恢复分区
- 排除系统相关驱动器，避免误操作

### 3. 驱动器分类
- **源数据盘**：包含数据文件的驱动器
- **目标备份盘**：可用于备份的空驱动器或专门备份驱动器
- 基于文件夹结构和文件类型进行智能分类

### 4. BitLocker支持
- 检测驱动器的BitLocker加密状态
- 支持使用恢复密钥解锁被锁定的驱动器
- 批量解锁多个被锁定的驱动器

### 5. 详细日志记录
- 完整的操作日志记录
- 错误追踪和调试信息
- 支持文件和控制台双重输出

## 系统要求

- **操作系统**：Windows 10/11, Windows Server 2016+
- **Python版本**：Python 3.7+
- **管理员权限**：需要管理员权限进行驱动器操作

## 依赖库

```bash
pip install psutil pywin32
```

### 必需库说明
- `psutil`：系统信息获取
- `pywin32`：Windows API调用
- `subprocess`：系统命令执行（Python内置）
- `logging`：日志记录（Python内置）

## 安装方法

1. 克隆或下载项目文件
2. 安装依赖库：
   ```bash
   pip install -r requirements.txt
   ```
3. 确保以管理员权限运行

## 使用方法

### 基本使用

```python
from system_detector import SystemDetector

# 创建检测器实例
detector = SystemDetector()

# 检测所有驱动器
drives = detector.detect_all_drives()

# 获取系统驱动器
system_drives = detector.get_system_drives()

# 分类驱动器
source_drives, destination_drives = detector.classify_drives()

# 获取驱动器详细信息
drive_info = detector.get_drive_information()

# 打印摘要
detector.print_summary()
```

### 命令行运行

```bash
# 直接运行模块
python system_detector.py

# 或者作为模块导入
python -m system_detector
```

### BitLocker解锁

```python
# 检查BitLocker状态
locked_drives = [drive for drive, info in detector.drive_info.items() 
                if info.get('bitlocker_status') == 'Locked']

# 解锁驱动器
if locked_drives:
    recovery_key = input("请输入BitLocker恢复密钥: ")
    unlock_results = detector.unlock_all_locked_drives(recovery_key)
```

## 配置文件

`config.ini` 文件包含所有可配置参数：

### 系统配置
```ini
[System]
System_Disk = C,D
System_Folders = Windows,Program Files,Users
Exclude_System_Related = true
```

### 驱动器分类配置
```ini
[Drive_Classification]
Source_Data_Folders = data,record,logs
Source_Data_Extensions = .txt,.log,.csv
Destination_Backup_Folders = backup,archive,copy
Empty_Disk_Threshold = 2
```

### BitLocker配置
```ini
[BitLocker]
Status_Check_Timeout = 10
Unlock_Timeout = 30
Auto_Unlock = false
```

## 输出示例

### 控制台输出
```
系统检测与初始化工具
========================================

1. 正在检测所有可用驱动器...
检测到 4 个驱动器: ['C:\\', 'D:\\', 'E:\\', 'F:\\']

2. 正在识别系统驱动器...
识别到系统盘符: ['C:\\']

3. 正在分类驱动器...
驱动器分类完成:
  源数据盘: ['D:\\']
  目标备份盘: ['E:\\', 'F:\\']

4. 正在获取驱动器详细信息...

5. 正在检查BitLocker状态...
未发现被BitLocker锁定的驱动器

============================================================
系统检测摘要
============================================================

总驱动器数量: 4
系统驱动器: 1
源数据驱动器: 1
目标备份驱动器: 2

驱动器详细信息:
------------------------------------------------------------

驱动器: C:\
  卷标: Windows
  文件系统: NTFS
  总容量: 256.00 GB
  已使用: 128.50 GB
  可用空间: 127.50 GB
  BitLocker状态: Unlocked
  类型: 系统盘

驱动器: D:\
  卷标: Data
  文件系统: NTFS
  总容量: 1.00 TB
  已使用: 500.00 GB
  可用空间: 500.00 GB
  BitLocker状态: Unlocked
  类型: 源数据盘

驱动器: E:\
  卷标: Backup1
  文件系统: NTFS
  总容量: 2.00 TB
  已使用: 0.00 GB
  可用空间: 2.00 TB
  BitLocker状态: Unlocked
  类型: 目标备份盘

驱动器: F:\
  卷标: Backup2
  文件系统: NTFS
  总容量: 2.00 TB
  已使用: 0.00 GB
  可用空间: 2.00 TB
  BitLocker状态: Unlocked
  类型: 目标备份盘

============================================================
```

### 日志文件
日志文件 `system_detector.log` 包含详细的操作记录和错误信息。

## 高级功能

### 自定义驱动器类型识别
可以通过修改配置文件来自定义驱动器类型的识别规则。

### 性能优化
- 支持缓存机制
- 可配置的检查深度
- 超时控制

### 错误处理
- 完整的异常捕获
- 详细的错误日志
- 优雅的降级处理

## 故障排除

### 常见问题

1. **权限不足**
   - 确保以管理员权限运行
   - 检查用户账户控制设置

2. **BitLocker命令不可用**
   - 确认系统支持BitLocker
   - 检查Windows版本

3. **驱动器检测失败**
   - 检查驱动器是否正常挂载
   - 确认文件系统支持

### 调试模式
在配置文件中启用调试模式：
```ini
[Advanced]
Debug_Mode = true
```

## 开发说明

### 代码结构
- `SystemDetector`：主要的检测器类
- 模块化设计，易于扩展和维护
- 完整的类型注解和文档字符串

### 扩展点
- 支持自定义驱动器分类算法
- 可扩展的BitLocker处理逻辑
- 灵活的配置系统

## 许可证

本项目采用MIT许可证，详见LICENSE文件。

## 贡献

欢迎提交Issue和Pull Request来改进这个项目。

## 联系方式

如有问题或建议，请通过以下方式联系：
- 提交GitHub Issue
- 发送邮件至项目维护者

---

**注意**：此工具需要管理员权限运行，请谨慎使用，确保了解操作的影响。 