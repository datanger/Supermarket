close all;
clear all; clc;
summaryStartTime = clock;
isQuick = "0";
dataType = "1";
dataLocation = input('please input data location japan/LA/OH :',"s");
if dataType == "0"
    sw_DataType = 0; % 0:OldData_US
    resimMatType = '\MAPvcl_*.mat';
else
    sw_DataType = 1; % 1:JP/NewData_US
    resimMatType = '\2YCkai_*.mat';
end
writeMatType = input('Car No.:',"s");

selPath = uigetdir('',' Please select Folder contains lkas.xlsx');

TemplateFormPath = fullfile(pwd,'[LKASOFF]�J����LKASOFF���Summary.xlsx');
if exist(fullfile(pwd,'�J����LKASOFF���Summary.xlsx'),'file')
    error(strcat("Error Already exists ",fullfile(pwd,'�J����LKASOFF���Summary.xlsx'),' Please delete �J����LKASOFF���Summary.xlsx'));
    [result,msg] = copyfile(TemplateFormPath,fullfile(pwd,'�J����LKASOFF���Summary.xlsx'));
else
    result = copyfile(TemplateFormPath,fullfile(pwd,'�J����LKASOFF���Summary.xlsx'));
end
TemplateFormPath = fullfile(pwd,'�J����LKASOFF���Summary.xlsx');
filePathDir = dir(selPath);
chkFlgNameList = ["�p�^�[��A","�p�^�[��B","�p�^�[��C","�p�^�[��DEF","Other"];
for i = 3:length(filePathDir)
    namefile = strrep(string(filePathDir(i).name),'.xlsx','');
    if contains(filePathDir(i).name,'�p�^�[��')
        LKAS = 1;
        break;
    end
end
if LKAS == 1
    Excel = actxserver('Excel.Application');
    Workbooks = Excel.Workbook;
    excelFile = Workbooks.Open(TemplateFormPath);
    set(Excel,'Visible',1);
    Sheets = Excel.ActiveWorkBook.Sheets;
    Sheet1 = get(Sheets,'Item',1);
    Sheet1.Activate;
    ReverseMemoSum = [];
    MemoSumlist = [];    
    for i=1:length(chkFlgNameList)   
        excelFilePath = strcat(chkFlgNameList(i),'.xlsx');
        excelName= fullfile(selPath,excelFilePath);
        if isfile(excelName)         
            sheets = sheetnames(excelName);
            for j=1:length(sheets)            
                [~,~,DataDetail] = xlsread(excelName,j,'AB2:AC24');
                AnalysisMemo = DataDetail(:,2);
                ReverseMemoSum = [ReverseMemoSum,AnalysisMemo]; 
            end
        end              
    end
    ReverseMemoSum = [DataDetail(:,1),ReverseMemoSum];
    for k=1:length(ReverseMemoSum(1,:))       
        MemoSum = reshape(ReverseMemoSum(:,k),1,[]);
        MemoSumlist = [MemoSumlist;MemoSum];     
    end
    MemoSumlist(find(cellfun(@(x) any(isnan(x)),MemoSumlist))) = {""};
    MemoSumlist = string(MemoSumlist);
    isEnableRealData = "0";
    info = {};
    info{1,1} = "dataName";
    info{1,2} = "tgtDiffyLatestResim";
    info{1,3} = "tgtDiffyRealResim";
    info{1,4} = "eMapLatestResim";
    info{1,5} = "curvLatestResim";
    info{1,6} = "eMapRealResim";
    info{1,7} = "curvRealResim";
    info{1,8} = "Group1Time";
    info{1,9} = "tgtDiffyOnlyMF4";
    info{1,10} = "time0Resim";
    [row2,~] = size(MemoSumlist);
    count0 = 2;
    for i = 2:row2
        LALinfo = split(MemoSumlist(i,20),',');
        Longitude = LALinfo(2,1);
        Latitude = LALinfo(1,1);
        GoogleMapLink = strcat("https://maps.google.com/maps?q=",num2str(Latitude,'%.20g')," ",num2str(Longitude,'%.20g'));
        displayLink = strcat(num2str(Latitude,'%.20g'),",",num2str(Longitude,'%.20g'));
        
        % Location
        Sheet1.Range(strcat('C',string(i-1+6))).value = dataLocation;
        % ?�u����
        formula = sprintf('=VLOOKUP(D%d,���X�g�ꗗ!$C$4:$D$26,2,FALSE)', (i-1+6));        
        Sheet1.Range(strcat("F",string(i-1+6))).Formula = formula;

        % GNSS�ܓx�o�x(GoogleMap�����N)
        obj = Sheet1.Range(strcat('I',string(i-1+6)));
        obj.Hyperlinks.Add(obj, GoogleMapLink,"","",displayLink);
        % �\�t�gVer
        Sheet1.Range(strcat("H",string(i-1+6))).value = MemoSumlist(i,5);
        % ���ޔԍ�
        Sheet1.Range(strcat("D",string(i-1+6))).value = MemoSumlist(i,21);
        % �ԗ�No.
        Sheet1.Range(strcat("J",string(i-1+6))).value = writeMatType;
        % MF4�f�[�^��� �t�@�C����
        Sheet1.Range(strcat("L",string(i-1+6))).value = MemoSumlist(i,3);
        % MF4�f�[�^��� ����[s]
        Sheet1.Range(strcat("M",string(i-1+6))).value = MemoSumlist(i,4);

        % �ԑ�[km/h]
        Sheet1.Range(strcat("N",string(i-1+6))).value = MemoSumlist(i,6);
        % �V�C
        Sheet1.Range(strcat("O",string(i-1+6))).value = MemoSumlist(i,7);
        % �C�x���g���P
        Sheet1.Range(strcat("P",string(i-1+6))).value = MemoSumlist(i,8);
        % �C�x���g���2
        Sheet1.Range(strcat("Q",string(i-1+6))).value = MemoSumlist(i,9);
        % �C�x���g���3
        Sheet1.Range(strcat("R",string(i-1+6))).value = MemoSumlist(i,10);
        % �H�ʏ��1
        Sheet1.Range(strcat("S",string(i-1+6))).value = MemoSumlist(i,11);
        % �H�ʏ��2
        Sheet1.Range(strcat("T",string(i-1+6))).value = MemoSumlist(i,12);
        % �ԗ��󋵂P
        Sheet1.Range(strcat("U",string(i-1+6))).value = MemoSumlist(i,13);
        % �ԗ���2
        Sheet1.Range(strcat("V",string(i-1+6))).value = MemoSumlist(i,14);
        % ���W�󋵂P
        Sheet1.Range(strcat("W",string(i-1+6))).value = MemoSumlist(i,15);
        % ���W��2
        Sheet1.Range(strcat("X",string(i-1+6))).value = MemoSumlist(i,16);
        % �������
        Sheet1.Range(strcat("Y",string(i-1+6))).value = MemoSumlist(i,17);
        % �����F
        Sheet1.Range(strcat("Z",string(i-1+6))).value = MemoSumlist(i,18);
        % �������
        Sheet1.Range(strcat("AA",string(i-1+6))).value = MemoSumlist(i,19);
        % ���l
        Sheet1.Range(strcat("AC",string(i-1+6))).value = MemoSumlist(i,22);
        excelFile.Save;
    end
    Excel.Quit;
    Excel.delete;
end

summaryEndTime = clock;
elapsed_time = etime(summaryEndTime, summaryStartTime); 
fprintf('total waste time�F%.1f[s]\n', elapsed_time);
