% mf4_file_list = fullfile(currentDir,'data','mf4_info','mf4_file_list.mat');
LKASOFFIssueListDir = dir(fullfile(currentDir,'IssueList','*LKASOFF.xlsx'));

for i = 1:length(LKASOFFIssueListDir)
    resimBIssueListPath = fullfile(LKASOFFIssueListDir(i).folder, LKASOFFIssueListDir(i).name);
    [~,~,DataDetail] = xlsread(resimBIssueListPath);
    DataDetail(find(cellfun(@(x) any(isnan(x)),DataDetail))) = {''};
    DataDetail = string(DataDetail);
    [~,col] = size(DataDetail);
    NameList(1).name = "";
    NameList(1).point = "";
    NameList(1).spd = "";
    for j = 1:col
        for k = 1:length(DataDetail(:,j))
            if k ~=1 && k~=2
                row = length(NameList);
                infoDataDetail = split(string(DataDetail(k,j)),'#');
                point = infoDataDetail(2);
                spd = infoDataDetail(1);
                NameList(row+1,1).name = DataDetail(2,j);
                NameList(row+1,1).point = point;
                NameList(row+1,1).spd = spd;
                time = strrep(point,'time_','');
                time = strrep(time,'[sec].png','');
            end
        end
    end
end

for j = 2:length(NameList)
    excelPath = fullfile(currentDir,'IssueList','chkResultExcel');
    if ~exist(excelPath,'dir')
        mkdir(excelPath)
    else
%             rmdir(excelPath)
    end
    if j == 2
        Excel = actxserver('Excel.Application');
        set(Excel,'Visible',1);
        set(Excel,'DisplayAlerts',0);
        Workbooks = Excel.Workbooks;
        excelName = strcat(folderName,'_LKASOFF.xlsx');
        Workbook = Workbooks.Add;
        Sheets = Excel.ActiveWorkBook.Sheets;
        sheetIdx = Sheets.Count;
        Sheet = get(Sheets,'Item',sheetIdx);
        Shapes = Sheet.Shapes;
    elseif NameList(j).type ~= NameList(j-1).type
        if ~exist(fullfile(excelPath,date),'dir')
            mkdir(fullfile(excelPath,date))
        end

        if contains(excelName, '[') || contains(excelName, ']')
            Workbook.SaveAs(fullfile(excelPath,date,"tmp"));  
            Excel.Quit;
            Excel.delete;
            movefile(fullfile(excelPath,date,strcat("tmp",".xlsx")), fullfile(excelPath,date,strcat(excelName,".xlsx")));
        else
            Workbook.SaveAs(fullfile(excelPath,date,excelName)); 
            Excel.Quit;
            Excel.delete;
        end                    
        Excel = actxserver('Excel.Application');
        set(Excel,'Visible',1);
        set(Excel,'DisplayAlerts',0);
        Workbooks = Excel.Workbooks;
        excelName = NameList(j).type;
        Workbook = Workbooks.Add;
        Sheets = Excel.ActiveWorkBook.Sheets;
        sheetIdx = Sheets.Count;
        Sheet = get(Sheets,'Item',sheetIdx);
        Shapes = Sheet.Shapes;
    else
        sheetIdx = sheetIdx + 1;
        Add(Sheets,[],Sheet);
        Sheet = get(Sheets,'Item',sheetIdx);
        Shapes = Sheet.Shapes;
    end
    tmpFigPath = fullfile(pwd,'tmpFig');
    if ~exist(tmpFigPath,'dir')
        mkdir(tmpFigPath)
    end
    point = double(strrep(strrep(strrep(NameList(j).point,'time_',''),'[sec]',''),'.png',''));
    pointPicName = strcat('time_',sprintf('%0.2f',point),'[sec].png');
    % match avi file
    aviTmpPath = fullfile(currentDir,'data','matdata',NameList(j).name,'*_Axis_Camera_Front.avi');
    aviDir = dir(aviTmpPath);
    if isempty(aviDir)
        aviTmpPath = fullfile(currentDir,'data','matdata',NameList(j).name,'*_AXIS_FRONT.avi');
        aviDir = dir(aviTmpPath);
    end
    onlyName1 = dir(fullfile(currentDir,'data','matdata',NameList(j).name,'*_ACore_XCP_remap.mat'));
    onlyName = onlyName1.name;
    [aviMatchName, aviMatchResult] = matchAviFile(aviDir,point,onlyName);
    if aviMatchResult == 1
        aviName = aviMatchName; 
        aviPath = fullfile(currentDir,'data','matdata',NameList(j).name,aviName);
    
	    if sw_DataType == 1
            videoPoint1 = mod(point,VideoTimeInterval);
            videoPoint2 = mod(point-0.1,VideoTimeInterval);
	    else
		    videoPoint1 = mod(point,VideoTimeInterval);
    	    videoPoint2 = mod(point-0.1,VideoTimeInterval);
	    end
        try
            fig1 = PlotFrontCam(videoPoint1,NameList(j).type,aviPath);
            fig2 = PlotFrontCam(videoPoint2,NameList(j).type,aviPath);
            
            saveas(fig1,fullfile(tmpFigPath,'CamFig1.jpg'));
            saveas(fig2,fullfile(tmpFigPath,'CamFig2.jpg'));
            shape = Shapes.AddPicture(fullfile(tmpFigPath,'CamFig2.jpg'),0,1,1,1,1,1);
            shape.Left = Sheet.Range( strcat('S2',':','Z33') ).Left;
            shape.Top = Sheet.Range( strcat('S2',':','Z33') ).Top;
            shape.Width = Sheet.Range( strcat('S2',':','Z33') ).Width;
            shape.Height = Sheet.Range( strcat('S2',':','Z33') ).Height;
            shape = Shapes.AddPicture(fullfile(tmpFigPath,'CamFig1.jpg'),0,1,1,1,1,1);
            shape.Left = Sheet.Range( strcat('S35',':','Z66') ).Left;
            shape.Top = Sheet.Range( strcat('S35',':','Z66') ).Top;
            shape.Width = Sheet.Range( strcat('S35',':','Z66') ).Width;
            shape.Height = Sheet.Range( strcat('S35',':','Z66') ).Height;
        catch
        end
    else
        Sheet.Range("AC29").value = "No WebCam";
    end
    
    % match OnlyMF4 parapara file
    dateTime = char(NameList(j).name);
    date = string(dateTime(1:8));
%         point2Name = strcat('time_',num2str(point2, '%.2f'),'[sec]');
    OnlyFilePath = fullfile(currentDir,'data','paraSave','B',date);
    paraFileDir = dir(fullfile(OnlyFilePath,strcat(NameList(j).name,'*Only*')));
    paraparaFileDir = dir(fullfile(paraFileDir.folder,paraFileDir.name,NameList(j).type,'time_*'));
    for l = 1:length(paraparaFileDir)
        if string(paraparaFileDir(l).name) == pointPicName
            break;
        end
    end
    paraFilePath1 = fullfile(paraFileDir.folder,paraFileDir.name,NameList(j).type,pointPicName);
    paraFilePath2 = fullfile(paraFileDir.folder,paraFileDir.name,NameList(j).type,paraparaFileDir(l-1).name);
    if exist(paraFilePath1,'file') && exist(paraFilePath2,'file')
        shape = Shapes.AddPicture(paraFilePath2,0,1,1,1,1,1);
        shape.Left = Sheet.Range( strcat('A2',':','Q33') ).Left;
        shape.Top = Sheet.Range( strcat('A2',':','Q33') ).Top;
        shape.Width = Sheet.Range( strcat('A2',':','Q33') ).Width;
        shape.Height = Sheet.Range( strcat('A2',':','Q33') ).Height;
        shape = Shapes.AddPicture(paraFilePath1,0,1,1,1,1,1);
        shape.Left = Sheet.Range( strcat('A35',':','Q66') ).Left;
        shape.Top = Sheet.Range( strcat('A35',':','Q66') ).Top;
        shape.Width = Sheet.Range( strcat('A35',':','Q66') ).Width;
        shape.Height = Sheet.Range( strcat('S35',':','Z66') ).Height;
    end
    
	if sw_DataType == 1
        curSfuncNAME1 = dir(fullfile(currentDir,'data','matdata',NameList(j).name,'2YCkai_*.mat'));
        if isempty(curSfuncNAME1)
            curSfuncNAME1 = dir(fullfile(currentDir,'data','matdata',NameList(j).name,'MAPvcl_*.mat'));
        end 
        matName = fullfile(curSfuncNAME1.folder,curSfuncNAME1.name);
% 	        load(matName,'S_Group1Time');
%             time1 = S_Group1Time.signals.values;
	else
		curSfuncNAME1 = dir(fullfile(currentDir,'data','matdata',NameList(j).name,'MAPvcl_*.mat'));
        matName = fullfile(curSfuncNAME1.folder,curSfuncNAME1.name);
% 	        load(matName, 'S_lmPldStt');
%             time1 = S_lmPldStt.time;
    end
    load(matName,'S_Group1Time', 'S_lmPldStt');
    curSignalTime = S_Group1Time.signals.values;
    time1 = curSignalTime;
    
    % 724_CenterLineOfForwardMaplsBroken type add LM BEV and MPU BEV
    if NameList(j).type == "724_CenterLineOfForwardMapIsBroken"
        clearvars LMMapPic MPUMapPic
        reapperType = "latest";
        GenerateResimPara(currentDir,NameList(j),reapperType);
        folPath = fullfile(currentDir,'data','matdata',NameList(j).name);
        addpath(genpath('subFunc'));
        PlotMpuLine(point,folPath)
        LMMapPic = fullfile(pwd,'tmpFig','LMMapPic.png');
        MPUMapPic = fullfile(pwd,'tmpFig','MPUMapPic.png');
        Range = Sheet.Range("AE69:AU69");
        Range.Font.Size = 14;
        Range.Interior.Color = int32(hex2dec('b8b644'));
        Range.Font.Bold=true;
        Sheet.Range("AE69").value = "LM�o�͒f�ʒn�}";
        Range = Sheet.Range("AW69:BM69");
        Range.Font.Size = 14;
        Range.Interior.Color = int32(hex2dec('b8b644'));
        Range.Font.Bold=true;
        Sheet.Range("AW69").value = "MPU�o�͒f�ʒn�}";
        if exist(LMMapPic,'file') && exist(MPUMapPic,'file')
            shape = Shapes.AddPicture(LMMapPic,0,1,1,1,1,1);
            shape.Left = Sheet.Range( strcat('AE70',':','AU103') ).Left;
            shape.Top = Sheet.Range( strcat('AE70',':','AU103') ).Top;
            shape.Width = Sheet.Range( strcat('AE70',':','AU103') ).Width;
            shape.Height = Sheet.Range( strcat('AE70',':','AU103') ).Height;
            shape = Shapes.AddPicture(MPUMapPic,0,1,1,1,1,1);
            shape.Left = Sheet.Range( strcat('AW70',':','BM103') ).Left;
            shape.Top = Sheet.Range( strcat('AW70',':','BM103') ).Top;
            shape.Width = Sheet.Range( strcat('AW70',':','BM103') ).Width;
            shape.Height = Sheet.Range( strcat('AW70',':','BM103') ).Height;
        end
    end
    
    % match resim parapara file
    clearvars AC7ResimName AC8ResimTime latestParaFilePath1 latestParaFilePath2
    reapperType = "latest";
    reappearLatest = 0;

    onlyMF4Point = double(strrep(strrep(strrep(NameList(j).point,'time_',''),'[sec]',''),'.png',''));
    get_resim_time = getResimTimeByTypeAndOnlyTime(NameList(j).type, onlyMF4Point, only_dic, get_resim_time_dic);

    for o = 1:length(NameList)
        if NameList(o).type == NameList(j).type && NameList(o).name == NameList(j).name
%                 resimPoint = double(strrep(strrep(NameList(o).point,'time_',''),'[sec]',''));
%                 onlyMF4Point = double(strrep(strrep(NameList(j).point,'time_',''),'[sec]',''));
            resimPoint = double(strrep(strrep(strrep(NameList(o).point,'time_',''),'[sec]',''),'.png',''));
%                onlyMF4Point = double(strrep(strrep(strrep(NameList(j).point,'time_',''),'[sec]',''),'.png',''));
            if resimPoint==get_resim_time
                AC7ResimName = NameList(o).name;
                AC8ResimTime = string(resimPoint);
                ResimFilePath = fullfile(currentDir,'data','paraSave','B',date);
                paraFileDir = dir(fullfile(ResimFilePath,strcat(NameList(o).name,'*')));
                for oi = 1:length(paraFileDir)
                    if ~contains(string(paraFileDir(oi).name),'OnlyMF4')
                        paraReismDir = paraFileDir(oi);
                    end
                end
                paraparaFileDir = dir(fullfile(paraReismDir.folder,paraReismDir.name,NameList(o).type,'time_*'));
                for l = 1:length(paraparaFileDir)
                    if string(paraparaFileDir(l).name) == string(NameList(o).point)
                        reappearLatest = 1;
                        break;
                    end
                end
                latestParaFilePath1 = fullfile(paraReismDir.folder,paraReismDir.name,NameList(o).type,strcat(NameList(o).point));
                latestParaFilePath2 = fullfile(paraReismDir.folder,paraReismDir.name,NameList(o).type,paraparaFileDir(l-1).name);
                break;
            end
        end
    end
	if sw_DataType == 1
    	LMFileDir = dir(fullfile(currentDir,'data','matdata',NameList(j).name,'2YCkai_*.mat'));
        if isempty(LMFileDir)
            LMFileDir = dir(fullfile(currentDir,'data','matdata',NameList(j).name,'MAPvcl_*.mat'));
        end 
        ACoreFileDir = dir(fullfile(currentDir,'data','matdata',NameList(j).name,'*_ACore_XCP_remap.mat'));
        ACoreFile = fullfile(ACoreFileDir.folder,ACoreFileDir.name);
        load(ACoreFile,'saTldMiBusOut_lmTldMapBusOut_lmEgoBusOut_log','Group3Time');
        MPUFileDir = dir(fullfile(currentDir,'data','matdata',NameList(j).name,'*MPU_message12.mat'));
        MPUFile = fullfile(MPUFileDir.folder,MPUFileDir.name);
        load(MPUFile,'MpuMessage3');
	else
		MPUFileDir = dir(fullfile(currentDir,'data','matdata',NameList(j).name,'*MPU_message12.mat'));
        ACoreFile = fullfile(MPUFileDir.folder,MPUFileDir.name);
        load(ACoreFile,'MpuMessage3');
    end
    freezeSec = double(string(strrep(strrep(regexp(LMFileDir.name,'Freeze_.*?sec','match'),'Freeze_',''),'sec','')));
    if ~isempty(freezeSec)
        if max(time1)<point
            FreezeFlg = 1;
        else
            FreezeFlg = 0;
        end
    else
        FreezeFlg = 0;
    end
    if reappearLatest == 0 && ~FreezeFlg
        try
            AC7ResimName = NameList(j).name;
            AC8ResimTime = strrep(strrep(NameList(j).point,'time_',''),'[sec].png','');
            GenerateResimPara(currentDir,NameList(j),reapperType);
            latestParaFilePath1 = strcat(pwd,'\tmpFig\','latestPara_1','.png');
            latestParaFilePath2 = strcat(pwd,'\tmpFig\','latestPara_0','.png');
        catch
            disp(strcat('Generate Latest Resim Parapara Error: ',NameList(j).name,'_',NameList(j).point))
        end
    end
    GoogleMapLinks;
    load(mf4_file_list);
    for n = 1:length(Blf_date_list)
        if Blf_date_list(n) == string(dateTime(1:15))
			if sw_DataType == 1
                mf4Time = mod(point,VideoTimeInterval);
                num = ceil(point/VideoTimeInterval);
			else
				mf4Time = mod(point,VideoTimeInterval);
            	num = ceil(point/VideoTimeInterval);
			end
            mf4Name = Blf_date_list(n+num-1);
            break;
        end
    end
    
    % Format the excel table and fill in some content
    Sheet.Range("AB2").value = "Date";  
    Sheet.Range("AB3").value = "PLD Status";
    Sheet.Range("AB4").value = "MF4 File Name";
    Sheet.Range("AB5").value = "MF4 system limit time(sec)";
    Sheet.Range("AB6").value = "BLF File Name";
    Sheet.Range("AB7").value = "BLF system limit time(sec)";
    Sheet.Range("AB8").value = "�ŐVResim Soft Ver.";
    Sheet.Range("AB9").value = "�Č����i�ŐVResim���ʁj";
    Sheet.Range("AB10").value = "����Resim Soft Ver.";
    Sheet.Range("AB11").value = "�Č����i����Resim���ʁj";
    Sheet.Range("AB12").value = "�ԑ�[km/h]";
    Sheet.Range("AB13").value = "�V�C";
    Sheet.Range("AB14").value = "�C�x���g���P";
    Sheet.Range("AB15").value = "�C�x���g���Q";
    Sheet.Range("AB16").value = "�C�x���g���R";
    Sheet.Range("AB17").value = "�H�ʏ�ԂP";
    Sheet.Range("AB18").value = "�H�ʏ�ԂQ";
    Sheet.Range("AB19").value = "�ԗ��󋵂P";
    Sheet.Range("AB20").value = "�ԗ��󋵂Q";
    Sheet.Range("AB21").value = "���W�󋵂P";
    Sheet.Range("AB22").value = "���W�󋵂Q";
    Sheet.Range("AB23").value = "�������";
    Sheet.Range("AB24").value = "�����F";
    Sheet.Range("AB25").value = "�������";
    Sheet.Range("AB26").value = "���ԃ��[��������";
    Sheet.Range("AB27").value = "Google Map Link";
    Sheet.Range("AB28").value = "���ޔԍ�";
    Sheet.Range("AB29").value = "���l��";
    Sheet.Range("AB30").value = "��̓�������";
    ctrl_judge = ['�אڎԐ���Ctrl�Ԑ����o�Ă��Ȃ�', char(10), '/�ُ�̏ꍇ�Ɂ~���L��'];
    Sheet.Range("AB31").value = ctrl_judge;
    Sheet.Range("AB31").Font.Name = 'Calibri';

    Sheet.Range("AE1").value = "�ŐV�\�t�g(BLFwithMF4)";
    Sheet.Range("AW1").value = "���ԃ\�t�g(BLFwithMF4)";
    
    Sheet.Range("AC2").value = dateTime(1:15);
    Sheet.Range("AC3").value = NameList(j).type;
    Sheet.Range("AC4").value = strcat(mf4Name,'_ACore_XCP_remap.mat');
    Sheet.Range("AC5").value = string(mf4Time);
    if exist('AC7ResimName','var')
        Sheet.Range("AC6").value = AC7ResimName;
    else
        Sheet.Range("AC6").value = "-";
    end
    if exist('AC8ResimTime','var')
        Sheet.Range("AC7").value = AC8ResimTime;
    else
        Sheet.Range("AC7").value = "-";
    end
    Sheet.Range("AC8").value = latestResimSoftVer;
    Sheet.Range("AC10").value = realResimSoftVer;

    Sheet.Range("AC12").value = NameList(j).spd;
%         if ~FreezeFlg
    obj = Sheet.Range("AC27");
    obj.Hyperlinks.Add(obj, GoogleMapLink,"","", displayLink);
    if FreezeFlg
        Sheet.Range("AC29").value = "Resim�s��";
    end
    
    Sheet.Range("AC2:AC31").HorizontalAlignment = -4131;
    Sheet.Range("AB:AC").EntireColumn.AutoFit;  
    Sheet.Range("AB2:AB31").Interior.ColorIndex = 38;        
    Sheet.Range("AB2:AC31").Borders.LineStyle = 1;
    Sheet.Range("AB:AB").ColumnWidth = 32;
    Range = Sheet.Range("AE1:AU1");
    Range.Font.Size = 14;
    Range.Interior.Color = int32(hex2dec('b8b644'));
    Range.Font.Bold=true;
    Range = Sheet.Range("AW1:BM1");
    Range.Font.Size = 14;
    Range.Interior.Color = int32(hex2dec('b8b644'));
    Range.Font.Bold=true;
    if length(char(strcat(dateTime,'_',string(point))))>31
        pointName = char(string(point));
        pointName = pointName(1:7);
        Sheet.Name = strcat(dateTime,'_',string(pointName));
    else
        Sheet.Name = strcat(dateTime,'_',string(point));
    end
    if exist('latestParaFilePath1','var') && exist('latestParaFilePath2','var')
        if exist(latestParaFilePath1,'file') && exist(latestParaFilePath2,'file')
            shape = Shapes.AddPicture(latestParaFilePath2,0,1,1,1,1,1);
            shape.Left = Sheet.Range( strcat('AE',string(2),':','AU',string(33)) ).Left;
            shape.Top = Sheet.Range( strcat('AE',string(2),':','AU',string(33)) ).Top;
            shape.Width = Sheet.Range( strcat('AE',string(2),':','AU',string(33)) ).Width;
            shape.Height = Sheet.Range( strcat('AE',string(2),':','AU',string(33)) ).Height;
            shape = Shapes.AddPicture(latestParaFilePath1,0,1,1,1,1,1);
            shape.Left = Sheet.Range( strcat('AE',string(35),':','AU',string(66)) ).Left;
            shape.Top = Sheet.Range( strcat('AE',string(35),':','AU',string(66)) ).Top;
            shape.Width = Sheet.Range( strcat('AE',string(35),':','AU',string(66)) ).Width;
            shape.Height = Sheet.Range( strcat('AE',string(35),':','AU',string(66)) ).Height;
        end
    end
    if exist('realParaFilePath1','var') && exist('realParaFilePath2','var')
        if exist(realParaFilePath1,'file') && exist(realParaFilePath2,'file')
            shape = Shapes.AddPicture(realParaFilePath2,0,1,1,1,1,1);
            shape.Left = Sheet.Range( strcat('AW',string(2),':','BM',string(33)) ).Left;
            shape.Top = Sheet.Range( strcat('AW',string(2),':','BM',string(33)) ).Top;
            shape.Width = Sheet.Range( strcat('AW',string(2),':','BM',string(33)) ).Width;
            shape.Height = Sheet.Range( strcat('AW',string(2),':','BM',string(33)) ).Height;
            shape = Shapes.AddPicture(realParaFilePath1,0,1,1,1,1,1);
            shape.Left = Sheet.Range( strcat('AW',string(35),':','BM',string(66)) ).Left;
            shape.Top = Sheet.Range( strcat('AW',string(35),':','BM',string(66)) ).Top;
            shape.Width = Sheet.Range( strcat('AW',string(35),':','BM',string(66)) ).Width;
            shape.Height = Sheet.Range( strcat('AW',string(35),':','BM',string(66)) ).Height;
        end
    end
%         if reappearReal == 1
%             Sheet.Range("AC11").value = "�Z";
%         else
%             Sheet.Range("AC11").value = "�~";
%         end
    if reappearLatest == 1
        Sheet.Range("AC9").value = "�Z";
    else
        Sheet.Range("AC9").value = "�~";
    end
    if exist(fullfile(pwd,'tmpFig'), 'dir') == 7
        rmdir(fullfile(pwd,'tmpFig'), 's');
        mkdir(fullfile(pwd,'tmpFig'));
    end
    fprintf('Data Complete:%d/%d\n',j-1,length(NameList)-1);
end
if exist('excelPath', 'var')
    if ~exist(fullfile(excelPath,date),'dir')
        mkdir(fullfile(excelPath,date))
    end
    
    if contains(excelName, '[') || contains(excelName, ']')
        Workbook.SaveAs(fullfile(excelPath,date,"tmp"));  
        Excel.Quit;
        Excel.delete;
        movefile(fullfile(excelPath,date,strcat("tmp",".xlsx")), fullfile(excelPath,date,strcat(excelName,".xlsx")));
    else
        Workbook.SaveAs(fullfile(excelPath,date,excelName)); 
        Excel.Quit;
        Excel.delete;
    end                        
    result = rmdir(tmpFigPath,'s');
end