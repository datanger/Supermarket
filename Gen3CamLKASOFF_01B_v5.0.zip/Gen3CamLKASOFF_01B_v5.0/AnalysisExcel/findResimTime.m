function resim_time_dic = findResimTime(onlyTimeDic, resimTimeDic)
    all_only_keys = keys(onlyTimeDic);
    all_only_values = values(onlyTimeDic);

    resim_time_dic = containers.Map();
    
    for i = 1:length(all_only_keys)
        only_key = all_only_keys{i};
        only_value = all_only_values{i};

        new_value = [];
        if isempty(resimTimeDic)||~ismember(only_key, keys(resimTimeDic))
            for j = 1:length(only_value)
                new_value(end+1)=NaN;
            end
        else
            matches = find_matches(only_value, resimTimeDic(only_key));

            [numRows, numCols] = size(matches);
            for j = 1:numRows
                match_time = matches(j,2);
                new_value(end+1)=match_time{1};
            end
        end
        resim_time_dic(only_key) = new_value;

    end

end

function matches = find_matches(onlyTime, resimTime)

    matches = cell(length(onlyTime), 2); 
    used = false(1, length(resimTime));   
    

    [A_sorted, original_indices] = sort(onlyTime);

    for i = 1:length(A_sorted)
        a = A_sorted(i);
        best_diff = inf;         
        best_index = -1;         
        
        for j = 1:length(resimTime)
            if ~used(j) 
                diff = abs(a - resimTime(j));
                if diff < 1 && diff < best_diff
                    best_diff = diff;
                    best_index = j;
                end
            end
        end
        
        if best_index ~= -1
            matches{original_indices(i), 1} = onlyTime(original_indices(i));
            matches{original_indices(i), 2} = resimTime(best_index);
            used(best_index) = true;
        else
            matches{original_indices(i), 1} = onlyTime(original_indices(i));
            matches{original_indices(i), 2} = NaN;
        end
    end
    
    fprintf('\n%-14s %-14s\n', 'onlyTime Value', 'resimTime Match');
    fprintf('----------------------------\n');
    for row = 1:size(matches, 1)
        a_val = matches{row, 1};
        b_val = matches{row, 2};
        
        a_str = strip_trailing_zeros(num2str(a_val));
        b_str = strip_trailing_zeros(num2str(b_val));
        
        fprintf('%-14s %-14s\n', a_str, b_str);
    end
end

function str = strip_trailing_zeros(num_str)
    if contains(num_str, '.') && ~contains(num_str, 'e')
        str = regexprep(num_str, '\.?0+$', '');
    else
        str = num_str;
    end
end
