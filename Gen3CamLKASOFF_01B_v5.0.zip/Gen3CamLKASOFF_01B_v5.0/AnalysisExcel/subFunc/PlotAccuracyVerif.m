num = 6;
swLegend = 0;
% xrng = [140 550];
xrng = [0 max(time)];
sralSmpl = 5; % **�T���v���A���ő��H���x�������Ȃ�Ƃ��ɐ��x�������Ɣ��f����
figTimeSer = figure(312); clf;
figTimeSer.Name = folderName;
sub=11;

clear axListAccuracyVerif;
clear axHeightListAccuracyVerif;

axIndex = 1; axHeight = 1.5;
axListAccuracyVerif( axIndex ) = axes;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;
if swComp
    for dc = 1:compDataNum
        if dc == 1
            plot(time, eMapOrg{dc},'mo-', "DisplayName", "e Map" );
            plot(time, eYRMOrg{dc} * 2,'mo-', "DisplayName", "e YRM" );
            plot( time, selectedCtrlSttOrg{dc} * 3, 'mo-', "DisplayName", "selectedCtrlStt"  );hold on;
        else
            plot(time, eMapOrg{dc},'ko-', "DisplayName", "e Map" );
            plot(time, eYRMOrg{dc} * 2,'ko-', "DisplayName", "e YRM" );
            plot( time, selectedCtrlSttOrg{dc} * 3, 'ko-', "DisplayName", "selectedCtrlStt"  );hold on;
        end
    end
end
plot(time, eMap,'b.-', "DisplayName", "e Map" );
plot(time, eYRM * 2,'b.-', "DisplayName", "e YRM" );
plot( time, selectedCtrlStt * 3, 'b.-', "DisplayName", "selectedCtrlStt"  );hold on;
if swLegend
    legend;
end
ylim( [ 0 3 ] );
xlim(xrng);
title('LM�������');

axIndex = 2;
axHeight = 1.5;
axListAccuracyVerif( axIndex ) = axes;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;    
plot(time,egoSpd*3.6,'r.-'); hold on;
if swLegend
    legend('�ԑ�[km/h]');    
end
xlim(xrng);
title('�ԑ�[km/h]');

% ���ԉ��̋ȗ����a
ax = axes;
axIndex = 3;
axHeight = 2;
axListAccuracyVerif( axIndex ) = ax;
axHeightListAccuracyVerif( axIndex ) = axHeight;
grid on; hold on;
plot(time,1./abs(curv(:,2)),'b.-'); hold on;
if swLegend
    legend('���ԉ��̋ȗ����a');    
end
ylim([0 800]);
yticks( -1000:100:1000 );
xlim(xrng);
title('���ԉ��̋ȗ����a');

ax = axes;
axIndex = 4;
axHeight = 2;
axListAccuracyVerif( axIndex ) = ax;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;
if swComp 
    compNum(axIndex) = 13;
    plot(time,bitget(lmPldSttOrg{1},13),'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},14)*2,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},15)*3,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},16)*4,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},17)*5,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},18)*6,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},19)*7,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},20)*8,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},21)*9,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},22)*10,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},23)*11,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},24)*12,'mo-'); hold on;
    plot(time,bitget(lmPldSttOrg{1},25)*13,'mo-'); hold on;
end
plot(time,bitget(lmPldStt,13),'b.-'); hold on;
plot(time,bitget(lmPldStt,14)*2,'b.-'); hold on;
plot(time,bitget(lmPldStt,15)*3,'b.-'); hold on;
plot(time,bitget(lmPldStt,16)*4,'b.-'); hold on;
plot(time,bitget(lmPldStt,17)*5,'b.-'); hold on;
plot(time,bitget(lmPldStt,18)*6,'b.-'); hold on;
plot(time,bitget(lmPldStt,19)*7,'b.-'); hold on;
plot(time,bitget(lmPldStt,20)*8,'b.-'); hold on;
plot(time,bitget(lmPldStt,21)*9,'b.-'); hold on;
plot(time,bitget(lmPldStt,22)*10,'b.-'); hold on;
plot(time,bitget(lmPldStt,23)*11,'b.-'); hold on;
plot(time,bitget(lmPldStt,24)*12,'b.-'); hold on;
plot(time,bitget(lmPldStt,25)*13,'b.-'); hold on;
yticks([0:2:15]);
xlim(xrng);
yticklabels({'OFF','721','723','725','727','729','731'})
title('lmPldStt');

ax = axes;
axIndex = 5;
axHeight = 2;
axListAccuracyVerif( axIndex ) = ax;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;
if swComp
    for dc = 1:compDataNum
        if dc == 1
            marker = 'mo-';
        elseif dc == 2
            marker = 'kx-';
        end
        for i = 1:6
            plot(time,bitget( xcorrSttOrg{dc}, i ) * i, marker );
        end
    end
end
legendList = [];
for i = 1:6
    legendList( i ) = plot(time,bitget(xcorrStt,i) * i,'b.-'); hold on;
end
if swLegend
    legend( legendList, '[1]ICP���ʏo��','[2]�f�b�h���R���ʏo��','[3]��','[4]�t�F�[�h�A�E�g������','[5]���~�b�g������');
end
yticks(0:1:6);
xlim(xrng);
title('xcorrStt');

ax = axes;
axIndex = 6;
axHeight = 2;
axListAccuracyVerif( axIndex ) = ax;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;
if swComp
    for i = 1:15
        plot( time, bitget( xcorrIcpErrSttOrg{1}, i ) * i, "mo-" );
    end
end
for i = 1:15
    plot( time, bitget( xcorrIcpErrStt, i ) * i, "b.-" );
end    
if swLegend
    legend('[1]�c���ŏ��l�ߑ�','[2]�c���ő�l�ߏ�','[3]��ӂɓ���ł��Ȃ�(��)','[4]��ӂɓ���ł��Ȃ�(����)','[5]���炵�ʂ����e�l�ȏ�','[6]�c���ŏ��_������','[7]�����L�k','[8]��]�ʉߑ�','[9]�c���`�󂪂���','[10]�c�ʒu�␳�s���̈�', '[11]���������Z��', '[12]Perr�ő�l','[13]Perr���ϒl','[14]���[���[�g�o�C�A�X���w�K','[15]���x�Q�C�����w�K');
end
xlim(xrng);
yticks(0:2:20);
title('xcorrIcpErrStt');

% �c�ʒu�␳��
ax = axes;
axIndex = 7;
axHeight = 3;
axListAccuracyVerif( axIndex ) = ax;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;
if swComp
    for dc = 1:compDataNum
        if dc == 1
            plot(time,xcorrDxOrg{dc}(:,1),'mo-'); hold on;
        elseif dc == 2
            plot(time,xcorrDxOrg{dc}(:,1),'ko-'); hold on;
        end
    end
end
plot(time,xcorrDx,'b.-'); hold on;
yticks(-30:2:30);
if swLegend
    legend('�c�ʒu�␳��');
end
xlim(xrng);
title('�c�ʒu�␳��');

ax = axes;
axIndex = 8;
axHeight = 3;
axListAccuracyVerif( axIndex ) = ax;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;
if swComp
    for dc = 1:compDataNum
        if dc == 1
            plot(time,xcorrIcpDxOrg{dc}(:,1),'mo-'); hold on;
        elseif dc == 2
            plot(time,xcorrIcpDxOrg{dc}(:,1),'ko-'); hold on;
        end
    end
end
plot(time,S_lmmlXcorrIcpDx.signals.values(:,1),'b.-'); hold on;
if swLegend
    legend('ICP�c�ʒu�␳��');
end
xlim(xrng);
title('ICP�c�ʒu�␳��');

% �ڕW�ʒu�ł̉��ʒu�덷
ax = axes;
axIndex = 10;
axHeight = 6;
axListAccuracyVerif( axIndex ) = ax;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;
if swComp
    for dc = 1:compDataNum
        if dc == 1
            plot(time,tgtDiffyOrg{dc},'mo-', "DisplayName", "��r��" );
        elseif dc == 2
            plot(time,tgtDiffyOrg{dc},'kx-', "DisplayName", "��r��2" );
        end
    end
end
if swAntLoc
%         plot(time,tgtDiffyMpu,'g.-', "DisplayName", "1.05�b��LM���H(���ԕ␳��MPU���Ȉʒu���_)����" );
    plot(time,tgtDiffyYrm,'c.-', "DisplayName", "1.05�b��LM���H(�n�}�}�b�`���O���Ȉʒu���_)����" );
%         plot(time,tgtDiffyDr,'k.-', "DisplayName", "1.05�b��LM���H(�f�b�h���R���Ȉʒu���_)����" );
end
plot(time,tgtDiffy,'b.-', "DisplayName", "1.05�b��LM���H����" );
yline( -0.3, "-r", "DisplayName", "tgtRange" );
yline( 0.3, "-r", "DisplayName", "tgtRange" );
ylim( [ -0.4 0.4 ] );
if swLegend
    legend;
end
title(ax,'�ڕW�ʒu�ł̉��ʒu�덷[m]');
yticks([-1.2:0.1:1.2])
xlim(xrng);

if swComp
    ax = axes;
    axIndex = 14;
    axHeight = 2;
    axListAccuracyVerif( axIndex ) = ax;
    axHeightListAccuracyVerif( axIndex ) = axHeight;
    hold on; grid on;
    for dc = 1:compDataNum
        tgtDiffyDiffOrg{dc} = abs( tgtDiffyOrg{dc} ) - abs( tgtDiffy );
        for i = 1:length( tgtDiffyDiffOrg{dc} )
            if isnan( tgtDiffyDiffOrg{dc}( i ) )
                tgtDiffyDiffOrg{dc}( i ) = NaN;
            elseif (tgtDiffyDiffOrg{dc}( i ) > 0.1) && (abs( tgtDiffyOrg{dc}( i ) ) > 0.3) && (abs( tgtDiffy( i ) ) < 0.3)
                tgtDiffyDiffOrg{dc}( i ) = 1;
            elseif (tgtDiffyDiffOrg{dc}( i ) < -0.1) && (abs( tgtDiffy( i ) ) > 0.3) && (abs( tgtDiffyOrg{dc}( i ) ) < 0.3)
                tgtDiffyDiffOrg{dc}( i ) = -1;
            else
                tgtDiffyDiffOrg{dc}( i ) = 0;
            end
            if i > sralSmpl
                if all(tgtDiffyDiffOrg{dc}( i - sralSmpl:i)==-1)
                    plot(time( i - sralSmpl:i),tgtDiffyDiffOrg{dc}( i - sralSmpl:i),'ro');
                elseif all(tgtDiffyDiffOrg{dc}( i - sralSmpl:i)==1)
                    plot(time( i - sralSmpl:i),tgtDiffyDiffOrg{dc}( i - sralSmpl:i),'bo');
                end
            end
        end
        if dc == 1
            marker = 'm.-';
        elseif dc == 2
            marker = 'k.-';
        end
        displayName = sprintf( "��r��%d", dc );
        plot(time,tgtDiffyDiffOrg{dc},marker, "DisplayName", displayName );
    end
    title(ax,'���H���x���� 1:���� -1:����');
    xlim(xrng);
else
    ax = axes;
    axIndex = 14;
    axHeight = 2;
    axListAccuracyVerif( axIndex ) = ax;
    axHeightListAccuracyVerif( axIndex ) = axHeight;
    hold on; grid on;
    dc = 1;
    tgtDiffyDiffOrg{dc} = abs( tgtDiffy ) ;

    for i = 1:length( tgtDiffyDiffOrg{dc} )
        if isnan( tgtDiffyDiffOrg{dc}( i ) )
            tgtDiffyDiffOrg{dc}( i ) = NaN;
        elseif tgtDiffyDiffOrg{dc}( i ) <= 0.3
            tgtDiffyDiffOrg{dc}( i ) = 1;
        elseif tgtDiffyDiffOrg{dc}( i ) > 0.3
            tgtDiffyDiffOrg{dc}( i ) = -1;
        else
            tgtDiffyDiffOrg{dc}( i ) = 0;
        end
        if i > sralSmpl
            if all(tgtDiffyDiffOrg{dc}( i - sralSmpl:i)==-1)
                plot(time( i - sralSmpl:i),tgtDiffyDiffOrg{dc}( i - sralSmpl:i),'ro');
            end
        end
    end
    marker = 'b.-';
    displayName = sprintf( "��r��%d", dc );
    plot(time,tgtDiffyDiffOrg{dc},marker, "DisplayName", displayName );
    title(ax,'���H���x���� 1:���� -1:����');
    xlim(xrng);
end

ax = axes;
axIndex = 15;
axListAccuracyVerif( axIndex ) = ax;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;
axHeight = 2;
if swComp
    plot( time, transpose(min(xcorrLNumOrg{1},xcorrCamLNumOrg{1})), "mo-", "DisplayName", "��r��" );
end
plot( time, min(xcorrLNum,xcorrCamLNum), "b.-", "DisplayName", "�L���_����" );
yticks(0:200:1000);
xlim(xrng);
title('�c�ʒu�␳�������_��(min(Map,Cam))');

ax = axes;
axIndex = 16;
axHeight = 2;
axListAccuracyVerif( axIndex ) = ax;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;
if swComp
    plot( time, transpose(min(xcorrRNumOrg{1},xcorrCamRNumOrg{1})), "mo-", "DisplayName", "��r��" );
end
plot( time, min(xcorrRNum,xcorrCamRNum), "b.-", "DisplayName", "�L���_���E" );
%yticks(0:200:1000);
xlim(xrng);
title('�c�ʒu�␳�E�����_��(min(Map,Cam))');

ax = axes;
axIndex = 17;
axHeight = 2;
axListAccuracyVerif( axIndex ) = ax;
axHeightListAccuracyVerif( axIndex ) = axHeight;
hold on; grid on;
plot( time, camC0(:,[1]), "r.-");
plot( time, camC0(:,[2]), "b.-");
% plot(time,tcFilter,'r.-'); hold on;
ylim([-3 3]);
xlim(xrng);
title('�J����C0');

%% �T�u�v���b�g��������
axListAccuracyVerifEnable = [];
gap = 0.02; %�T�u�v���b�g�Ԃ̕�(Figure�S�̂ɑ΂���䗦)
heightUnit = ( 1 - 2 * gap ) / sum( axHeightListAccuracyVerif );
for i = 1:length( axListAccuracyVerif )
    ax = axListAccuracyVerif( i );
    if isprop( ax, "Position" )
        axPosition = ax.Position;
        axLeft = axPosition( 1 );
        axBottom = axPosition( 2 );
        axWidth = axPosition( 3 );
        axHeight = axPosition( 4 );

        if axHeightListAccuracyVerif( i ) == 0
            cla( ax );
            ax.Visible = 'off';
        else
            ax.Visible = 'on';
            axLeft = 2 * gap;
            axBottom = 1 - ( heightUnit * sum( axHeightListAccuracyVerif( 1:i ) )  ) ;
            axWidth = 1 - 4 * gap;
            axHeight = heightUnit * axHeightListAccuracyVerif( i ) - gap ;
            axPosition = [ axLeft axBottom axWidth axHeight ];
            ax.Position = axPosition;

            axListAccuracyVerifEnable = vertcat( axListAccuracyVerifEnable, ax );
        end

        pause( 0.1 );
    else
        delete( ax );
    end
end

linkaxes( axListAccuracyVerifEnable,'x');
