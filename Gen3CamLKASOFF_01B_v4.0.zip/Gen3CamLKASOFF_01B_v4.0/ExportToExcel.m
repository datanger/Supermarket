ExcelTable = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","AA","AB","AC","AD","AE","AF",...
    "AG","AH","AI","AJ","AK","AL","AM","AN","AO","AP","AQ","AR","AS","AT","AU","AV","AW","AX","AY","AZ","BA","BB","BC","BD","BE","BF","BG","BH","BI",...
    "BJ","BK","BL","BM","BN","BO","BP","BQ","BR","BS","BT","BU","BV","BW","BX","BY","BZ"];
Excel = actxserver('Excel.Application');
set(Excel,'Visible',1);
set(Excel,'DisplayAlerts',0);
Workbooks = Excel.Workbooks;
OnlyMF4BExcelfolder = fullfile(currentDir,'issueList');
if ~exist(OnlyMF4BExcelfolder,'dir')
    mkdir(OnlyMF4BExcelfolder);
end
OnlyMF4LKASExcel = strcat(OnlyMF4BExcelfolder,'\',dataDate,'_LKASOFF.xlsx');
if isfile(OnlyMF4LKASExcel)
    Workbook = Workbooks.Open(OnlyMF4LKASExcel);
    [~,~,subsetA] = xlsread(OnlyMF4LKASExcel,'Sheet1');
    subsetA = string(subsetA);
    [~,A_length] = size(subsetA);
    excelNum = A_length + 1;
else
    Workbook = Workbooks.Add;
    excelNum = 1;
end
Sheets = Excel.ActiveWorkBook.Sheets;
Sheet = get(Sheets,'Item',1);
Sheet.Activate;
A3i = 1;
dataName = folderName;
A1 = ExcelTable(1,excelNum) + "1";
Sheet.Range(A1).value = dataName;
A2 = ExcelTable(1,excelNum) + "2";
Sheet.Range(A2).value = strcat(strrep(folderName,PlusName,''),'_ACore_XCP_remap.mat');
fprintf(1,'LogFileName = %s\n',dataName);
time = Group1Time;
DataIndex = [];
for i = 1:length(eMap)
    conditionA = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(i),8) || ...
    bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(i),9) || ...
    bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(i),10);
    conditionB = saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmVecCtrlLnExistFlg.signals.values(i,2) == 0;
    conditionC = bitget(smVecSysActivateMode(i),2);
    if eMap(i) == 1 && (conditionA || conditionB) &&  conditionC == 1
        DataIndex = [DataIndex;i];
    end
end
if ~isempty(DataIndex)
    numIdx = DataIndex(1);
    for i = 2:length(DataIndex)
        if DataIndex(i)-DataIndex(i-1) == 1
        else
            numIdx = [numIdx;DataIndex(i)];
        end
    end
    numIdxType = "";
    for i = 1:length(numIdx)
        CA = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(numIdx(i)),8);
        CB = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(numIdx(i)),9);
        CC = bitget(saTldMiBusOut_lmTldCamBusOut_lmSttBusOut_log.lmPldStt.signals.values(numIdx(i)),10);
        CD = (bitget(saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values(numIdx(i)),1)==0) && ...
            (bitget(saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmCtrlLnMode.signals.values(numIdx(i)),2)==0);
        CE = saTldMiBusOut_lmTldCamBusOut_lmCtrlBusOut_log.lmVecCtrlLnExistFlg.signals.values(numIdx(i),2);
        if CA == 1
            numIdxType(i,1) = '�p�^�[��A';
        else
            if CB == 1
                numIdxType(i,1) = '�p�^�[��B';
            else
                if CC == 1
                    numIdxType(i,1) = '�p�^�[��C';
                else
                    if CD
                        numIdxType(i,1) = '�p�^�[��DEF';
                    else
                        if CE == 1
                            numIdxType(i,1) = '�p�^�[��DEF';
                        else
                            numIdxType(i,1) = 'Other';
                        end
                    end
                end
            end
        end
    end
    if ~isempty(numIdx)
        for i = 1:length(numIdx)
            ltmp = numIdx(i);
            A3 = ExcelTable(1,excelNum) + string(2+A3i);
            A3i = A3i + 1;
            speed = string(sprintf('%.1f',Spd(ltmp)*20*3.6));
            
            mf4_file_name = '';
            if mf4_file_list ~= 0
                load(mf4_file_list);
                dateTime = string(regexprep(dataName, '_Plus\d+', ''));
                for n = 1:length(Blf_date_list)
                    if Blf_date_list(n) == dateTime
                        num = ceil(LogTimeCam(ltmp)/VideoTimeInterval);
                        mf4_file_name = string(Blf_date_list(n+num-1));
                        break;
                    end
                end
            elseif blf_dataFolder ~= 0
                all_acore = dir(fullfile(blf_dataFolder,'*ACore_XCP.mf4'));
                for i = 1:length(all_acore)
                    if contains(all_acore(i).name,regexprep(dataName, '_Plus\d+', ''))
                        mf4_file_name = all_acore(i+floor(LogTimeCam(ltmp)/VideoTimeInterval)).name;
                        mf4_result = regexp(mf4_file_name, '^\d+_\d+', 'match');
                        mf4_extracted = result{1};
                        mf4_file_name = string(mf4_extracted);
                        break
                    end
                end
            end
            
            if isempty(mf4_file_name)
                error("mf4_info error: plus %s time %f", dataName, LogTimeCam(ltmp))
            end
            
            A3value = strcat(speed,'#',numIdxType(i),'#',"time_", string(round(LogTimeCam(ltmp),2)),"[sec].png", '#', mf4_file_name);
            Sheet.Range(A3).value = A3value;
        end
    end
    Workbook.SaveAs(OnlyMF4LKASExcel);
end
Excel.Quit;
Excel.delete;