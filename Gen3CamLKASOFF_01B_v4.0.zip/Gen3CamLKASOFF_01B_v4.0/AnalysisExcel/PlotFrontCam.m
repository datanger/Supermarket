function fig = PlotFrontCam(pointTime,PLDType,videoPath)

    v = VideoReader(videoPath);
    videotime = v.Duration;
    [~,chkMovieFileName,~] = fileparts(videoPath);
    fig = figure('Visible',0);
    ax1 = subplot('Position',[.1 .15 .8 .8]);
    fig.Position = [0 0 1366 768];
    % Take screen shoot when error codes are triggered
    movieSetTime = round(pointTime,2);
    if movieSetTime<videotime
        v.currenttime = movieSetTime;
    else
        v.currenttime = videotime - 0.1;
        warning(string(movieSetTime));
        warning(videoPath);
    end
    vidFrame = readFrame(v);
    image(ax1,vidFrame);
    set(ax1,'xtick',[],'ytick',[]);
    hold on;
    nowtime = strcat(strrep(chkMovieFileName,'_','\_'),...
                     ', ChkFlgName = ',strrep(PLDType,'_','\_'), ...
                     ', Time = ',num2str(pointTime));
    title(ax1,nowtime);
    set(ax1,'FontSize',22,'Visible',1);
    ax1.TitleFontSizeMultiplier = 1;
end