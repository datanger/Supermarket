%% �esubplot�͈̔͂�ݒ�
if swXcorr == 0
    ax3.XLim = [str2double(XlimLowerEdit.String) str2double(XlimUpperEdit.String)];
    ax3.YLim = [str2double(YlimLowerEdit.String) str2double(YlimUpperEdit.String)];
    ax5.XLim = [-100 100];
    ax5.YLim = [-150 300];
else
    ax3XlimMin = min([min(xcorrCamLY(l,:)) min(xcorrCamRY(l,:)) min(xcorrAftLY(l,:)) min(xcorrAftRY(l,:))]);
    ax3XlimMax = max([max(xcorrCamLY(l,:)) max(xcorrCamRY(l,:)) max(xcorrAftLY(l,:)) max(xcorrAftRY(l,:))]);
    ax3YlimMin = min([min(xcorrCamLX(l,:)) min(xcorrCamRX(l,:)) min(xcorrAftLX(l,:)) min(xcorrAftRX(l,:))]);
    ax3YlimMax = max([max(xcorrCamLX(l,:)) max(xcorrCamRX(l,:)) max(xcorrAftLX(l,:)) max(xcorrAftRX(l,:))]);
    ax3XlimRng = [ax3XlimMin ax3XlimMax];
    ax3YlimRng = [ax3YlimMin ax3YlimMax];
    if (ax3XlimRng(1) == ax3XlimRng(2)) || (ax3YlimRng(1) == ax3YlimRng(2))
        ax3.XLim = [str2double(XlimLowerEdit.String) str2double(XlimUpperEdit.String)];
        ax3.YLim = [str2double(YlimLowerEdit.String) str2double(YlimUpperEdit.String)];
    else
        ax3.XLim = ax3XlimRng;
        ax3.YLim = ax3YlimRng;
    end
    ax4.XLim = [-4 4];
    ax4.YLim = [-30 30];
    ax5.XLim = [-4 4];
    ax5.YLim = [-30 30];
    ax6.XLim = [-1000 100];
    ax7.XLim = [-1000 100];
end

xlimTimeBegin = time( l ) - tt;
xlimTimeEnd = time( l ) + tt;
for i = 1:length( find( isgraphics( axTime ) ) )
    ax = axTime( i );
    ax.XLim = [ xlimTimeBegin xlimTimeEnd ];
    if swCANape == 0
        if i == length( find( isgraphics( axTime ) ) ) - 1
            break;
        end
    else
        if i == length( find( isgraphics( axTime ) ) )
            break;
        end
    end
end
if swWebCam == 0
    for i = 1:length( find( isgraphics( axTimeEx2 ) ) )
        ax = axTimeEx2( i );
        ax.XLim = [ xlimTimeBegin xlimTimeEnd ];
        if swCANape == 0
            if i == length( find( isgraphics( axTime ) ) ) - 1
                break;
            end
        else
            if i == length( find( isgraphics( axTime ) ) )
                break;
            end
        end
    end
end

plotIndLength =(str2double(XlimUpperEdit.String) - str2double(XlimLowerEdit.String))/40;%TODO�@�v����
xlimVHigh= str2double(XlimUpperEdit.String);
xlimVLow= str2double(XlimLowerEdit.String);
ylimVHigh=str2double(YlimUpperEdit.String);
ylimVLow =str2double(YlimLowerEdit.String);

if swXcorr == 0
    % BEV�v���b�g
    ax3.NextPlot = 'add';
    cla(ax3);
    swDispCont = swDispContRt;
    ax = ax3;
    SelectPlot;
    xticks( ax3, -100:1:100 );
    % �L���BEV�v���b�g
    ax5.NextPlot = 'add';
    cla(ax5);
    swDispCont = swDispContRtLarge;
    ax = ax5;
    SelectPlot;

    % webCam�`��
    if swWebCam
        ax4.NextPlot = 'add';
        cla(ax4);

        % webCam�����\��
        m = image(ax4,vidFrame);
        axis(ax4,'image');
        ax4.Visible = 'off';
        settime = time(l) + offset;
        settime(settime > maxtime) = maxtime;
        settime(settime < 0) = 0;
        settime = double(settime);

        if multiSw == 1
            filenumber = sum(sumtime < settime);
            if filenumber == 0
                v{1}.currenttime = settime;    
            else
                v{filenumber+1}.currenttime = settime - sumtime(filenumber);
            end
            vidFrame = readFrame(v{filenumber+1});
            m.CData = vidFrame;
        else
            settime = mod(settime(1),300);
            if v.Duration > 0
                v.currenttime = settime;
                vidFrame = readFrame(v);
                m.CData = vidFrame;
            end
        end
    end
%% �n�}�E�J�����_��p�v���b�g
elseif swXcorr == 1
    ax3.NextPlot = 'add';
    cla(ax3);
%     if chkbox_Ctrl.Value
%         plot(ax3,lmCtrlY(l,452:902),lmCtrlX(l,452:902),'b.'); hold on;
%     end
    if swComp == 0 || (chkbox_Comp1.Value == 0 && chkbox_Comp2.Value == 0) 
        if chkbox_camLine.Value
            plot(ax3,xcorrCamLY(l,:),xcorrCamLX(l,:),'b.'); hold on;
            plot(ax3,xcorrCamRY(l,:),xcorrCamRX(l,:),'b.'); hold on;
            plot(ax3,xcorrCamLY(l,1:100:1001),xcorrCamLX(l,1:100:1001),'b*'); hold on;
            plot(ax3,xcorrCamRY(l,1:100:1001),xcorrCamRX(l,1:100:1001),'b*'); hold on;
        end

        if chkbox_MapLine.Value
            plot(ax3,xcorrAftLY(l,:),xcorrAftLX(l,:),'r.'); hold on;
            plot(ax3,xcorrAftRY(l,:),xcorrAftRX(l,:),'r.'); hold on;
            plot(ax3,xcorrAftLY(l,1:100:1001),xcorrAftLX(l,1:100:1001),'r*'); hold on;
            plot(ax3,xcorrAftRY(l,1:100:1001),xcorrAftRX(l,1:100:1001),'r*'); hold on;
        end

        if chkbox_MapLane.Value
            plot(ax3,xcorrAftCY(l,:),xcorrAftCX(l,:),'g.'); hold on;
%             corIdx = [ceil(xcorrDxDlt(l,:)) floor(xcorrDxDlt(l,:))];
%             if corIdx == 0
%                 corIdx = 1;
%             else
%                 corIdx = corIdx + 1001;
%             end
%             plot(ax3,xcorrAftCY(l,corIdx),xcorrAftCX(l,corIdx),'gp'); hold on;
            plot(ax3,xcorrAftCY(l,1:100:1001),xcorrAftCX(l,1:100:1001),'g*'); hold on;
        end

        if chkbox_ICP.Value
            plot(ax3,xcorrCamLY(l,idxIcpCamLt(l,:)),xcorrCamLX(l,idxIcpCamLt(l,:)),'bo'); hold on;
            plot(ax3,xcorrCamRY(l,idxIcpCamRt(l,:)),xcorrCamRX(l,idxIcpCamRt(l,:)),'bo'); hold on;
            plot(ax3,xcorrAftLY(l,idxIcpMapLt(l,:)),xcorrAftLX(l,idxIcpMapLt(l,:)),'ro'); hold on;
            plot(ax3,xcorrAftRY(l,idxIcpMapRt(l,:)),xcorrAftRX(l,idxIcpMapRt(l,:)),'ro'); hold on;
        end
    else
        if chkbox_Comp1.Value
            i = 1;
        elseif chkbox_Comp2.Value
            i = 2;
        end
        if chkbox_camLine.Value
            plot(ax3,xcorrCamLYOrg{i}(l,:),xcorrCamLXOrg{i}(l,:),'b.'); hold on;
            plot(ax3,xcorrCamRYOrg{i}(l,:),xcorrCamRXOrg{i}(l,:),'b.'); hold on;
        end

        if chkbox_MapLine.Value
            plot(ax3,xcorrAftLYOrg{i}(l,:),xcorrAftLXOrg{i}(l,:),'r.'); hold on;
            plot(ax3,xcorrAftRYOrg{i}(l,:),xcorrAftRXOrg{i}(l,:),'r.'); hold on;
        end
    end

%     if chkbox_camC0Trace.Value
%         plot(ax3,TransClineLPosY(l,:),TransClineLPosX(l,:),'ro','MarkerFaceColor','r'); hold on;
%         plot(ax3,TransClineRPosY(l,:),TransClineRPosX(l,:),'ro','MarkerFaceColor','r'); hold on;
%     end
    titleName = text('String', sprintf('{�y�c�ʒu�␳������`��z\\newline\\color{blue}Cam \\color{red}Map \\color{black}�Z:ICP�g�p�_ *:���ԉ�����100m���̓_}'));
    title(ax3,titleName.String);

    ax4.NextPlot = 'add';
    cla(ax4);
    lnPntNum = 451;
    for ln = 0:15
        if mapLaneNum(l) > ln
            if cMpStartIdxOut(l,ln+1) ~= -1 && cMpEndIdxOut(l,ln+1)+1 ~= -1
                plot(ax4,cMpLtYOut(l,lnPntNum*ln+cMpStartIdxOut(l,ln+1)+1:lnPntNum*ln+cMpEndIdxOut(l,ln+1)+1),cMpXOut(l,lnPntNum*ln+cMpStartIdxOut(l,ln+1)+1:lnPntNum*ln+cMpEndIdxOut(l,ln+1)+1),'k.'); hold on;
                plot(ax4,cMpRtYOut(l,lnPntNum*ln+cMpStartIdxOut(l,ln+1)+1:lnPntNum*ln+cMpEndIdxOut(l,ln+1)+1),cMpXOut(l,lnPntNum*ln+cMpStartIdxOut(l,ln+1)+1:lnPntNum*ln+cMpEndIdxOut(l,ln+1)+1),'k.'); hold on;
            end
        end
    end
    if swComp == 0 || (chkbox_Comp1.Value == 0 && chkbox_Comp2.Value == 0) 
        plot(ax4,matchMapY(l,:),matchMapX(l,:),'r*'); hold on;
        plot(ax4,matchCamY(l,:),matchCamX(l,:),'bo'); hold on;
        if swMmLine
            plot(ax4,egoLaneLtLineY(l,:),egoLaneLtLineX(l,:),'ro'); hold on;
            plot(ax4,egoLaneRtLineY(l,:),egoLaneRtLineX(l,:),'ro'); hold on;
        end
    else
        if chkbox_Comp1.Value
            i = 1;
        elseif chkbox_Comp2.Value
            i = 2;
        end
        plot(ax4,matchMapYOrg{i}(l,:),matchMapXOrg{i}(l,:),'r*'); hold on;
        plot(ax4,matchCamYOrg{i}(l,:),matchCamXOrg{i}(l,:),'bo'); hold on;
    end
    titleName = text('String', sprintf('{�y���ʒu�␳�O�����`��z\\color{blue}Cam \\color{red}Map}'));
    title(ax4,titleName.String);

    ax5.NextPlot = 'add';
    cla(ax5);
    for ln = 0:15
        if mapLaneNum(l) > ln
            if cMpStartIdxOut(l,ln+1) ~= -1 && cMpEndIdxOut(l,ln+1)+1 ~= -1
                plot(ax5,cMpLtYOut(l,lnPntNum*ln+cMpStartIdxOut(l,ln+1)+1:lnPntNum*ln+cMpEndIdxOut(l,ln+1)+1),cMpXOut(l,lnPntNum*ln+cMpStartIdxOut(l,ln+1)+1:lnPntNum*ln+cMpEndIdxOut(l,ln+1)+1),'k.'); hold on;
                plot(ax5,cMpRtYOut(l,lnPntNum*ln+cMpStartIdxOut(l,ln+1)+1:lnPntNum*ln+cMpEndIdxOut(l,ln+1)+1),cMpXOut(l,lnPntNum*ln+cMpStartIdxOut(l,ln+1)+1:lnPntNum*ln+cMpEndIdxOut(l,ln+1)+1),'k.'); hold on;
            end
        end
    end
    if swComp == 0 || (chkbox_Comp1.Value == 0 && chkbox_Comp2.Value == 0) 
        plot(ax5,matchAftMapYLt(l,:),matchAftMapXLt(l,:),'r*'); hold on;
        plot(ax5,matchAftMapYRt(l,:),matchAftMapXRt(l,:),'r*'); hold on;
        plot(ax5,matchCamY(l,:),matchCamX(l,:),'bo'); hold on;
    else
        if chkbox_Comp1.Value
            i = 1;
        elseif chkbox_Comp2.Value
            i = 2;
        end
        plot(ax5,matchAftMapYLtOrg{i}(l,:),matchAftMapXLtOrg{i}(l,:),'r*'); hold on;
        plot(ax5,matchAftMapYRtOrg{i}(l,:),matchAftMapXRtOrg{i}(l,:),'r*'); hold on;
        plot(ax5,matchCamYOrg{i}(l,:),matchCamXOrg{i}(l,:),'bo'); hold on;
    end
    titleName = text('String', sprintf('{�y���ʒu�␳������`��z\\color{blue}Cam \\color{red}Map}'));
    title(ax5,titleName.String);

    ax6.NextPlot = 'add';
    cla(ax6);
    if swComp == 0 || (chkbox_Comp1.Value == 0 && chkbox_Comp2.Value == 0) 
        plot(ax6,xcorrAftDltLX(l,:),xcorrAftDltLY(l,:),'r.'); hold on;
        plot(ax6,xcorrCamDltLX(l,:),xcorrCamDltLY(l,:),'b.'); hold on;
        plot(ax6,xcorrAftDltRX(l,:),xcorrAftDltRY(l,:),'m.'); hold on;
        plot(ax6,xcorrCamDltRX(l,:),xcorrCamDltRY(l,:),'c.'); hold on;
        if chkbox_ICP.Value
            plot(ax6,xcorrAftDltLX(l,idxIcpMapLt(l,:)),xcorrAftDltLY(l,idxIcpMapLt(l,:)),'ro'); hold on;
            plot(ax6,xcorrCamDltLX(l,idxIcpCamLt(l,:)),xcorrCamDltLY(l,idxIcpCamLt(l,:)),'bo'); hold on;
            plot(ax6,xcorrAftDltRX(l,idxIcpMapRt(l,:)),xcorrAftDltRY(l,idxIcpMapRt(l,:)),'mo'); hold on;
            plot(ax6,xcorrCamDltRX(l,idxIcpCamRt(l,:)),xcorrCamDltRY(l,idxIcpCamRt(l,:)),'co'); hold on;
        end
    else
        if chkbox_Comp1.Value
            i = 1;
        elseif chkbox_Comp2.Value
            i = 2;
        end
        plot(ax6,xcorrAftDltLXOrg{i}(l,:),xcorrAftDltLYOrg{i}(l,:),'r.'); hold on;
        plot(ax6,xcorrCamDltLXOrg{i}(l,:),xcorrCamDltLYOrg{i}(l,:),'b.'); hold on;
        plot(ax6,xcorrAftDltRXOrg{i}(l,:),xcorrAftDltRYOrg{i}(l,:),'m.'); hold on;
        plot(ax6,xcorrCamDltRXOrg{i}(l,:),xcorrCamDltRYOrg{i}(l,:),'c.'); hold on;
        if chkbox_ICP.Value
            plot(ax6,xcorrAftDltLXOrg{i}(l,idxIcpMapLtOrg{i}(l,:)),xcorrAftDltLYOrg{i}(l,idxIcpMapLtOrg{i}(l,:)),'ro'); hold on;
            plot(ax6,xcorrCamDltLXOrg{i}(l,idxIcpCamLtOrg{i}(l,:)),xcorrCamDltLYOrg{i}(l,idxIcpCamLtOrg{i}(l,:)),'bo'); hold on;
            plot(ax6,xcorrAftDltRXOrg{i}(l,idxIcpMapRtOrg{i}(l,:)),xcorrAftDltRYOrg{i}(l,idxIcpMapRtOrg{i}(l,:)),'mo'); hold on;
            plot(ax6,xcorrCamDltRXOrg{i}(l,idxIcpCamRtOrg{i}(l,:)),xcorrCamDltRYOrg{i}(l,idxIcpCamRtOrg{i}(l,:)),'co'); hold on;
        end
    end
    titleName = text('String', sprintf('\\color{black}�y��Y�`��z\\color{red}MapLt \\color{blue}CamLt \\color{magenta}MapRt \\color{cyan}CamRt'));
    title(ax6,titleName.String);

    ax7.NextPlot = 'add';
    cla(ax7);
    if swComp == 0 || (chkbox_Comp1.Value == 0 && chkbox_Comp2.Value == 0) 
        if swPerrALL
            plot(ax7,-1000:49,abs(perrL(l,:)),'r.-'); hold on;
            plot(ax7,-1000:49,abs(perrR(l,:)),'b.-'); hold on;
        end
        plot(ax7,icpDist(l,1:204),perrMin(l,1:204),'r.-'); hold on;
        plot(ax7,icpDist(l,205:408),perrMin(l,205:408),'b.-'); hold on;
    else
        if chkbox_Comp1.Value
            i = 1;
        elseif chkbox_Comp2.Value
            i = 2;
        end
        plot(ax7,icpDistOrg{i}(l,1:204),perrMinOrg{i}(l,1:204),'r.-'); hold on;
        plot(ax7,icpDistOrg{i}(l,205:408),perrMinOrg{i}(l,205:408),'b.-'); hold on;
    end
    titleName = text('String', sprintf('�y��Y�c���`��(�c���ŏ���)�z\\color{red}Left \\color{blue}Right'));
    titleName.FontSize = 6;
    title(ax7,titleName.String);

    ax8.NextPlot = 'add';
    cla(ax8);
    plot(ax8,-1000:99,xcorrMCR(l,:),'b.-'); hold on;
    yline(ax8,900,'r-');
    ax8.XLim = [ -1000 100 ];
    ax8.YLim = [ 0 2000 ];
    yticks(ax8,[0:200:2000]);
    titleName = text('String', sprintf('�y���Ԏ��ӓ��H�ȗ����a�z'));
    titleName.FontSize = 6;
    title(ax8,titleName.String);
end

%% ���n��p�v���b�g
chgPlotFlg = ( exist( "rePlotFlag" ) == 0 || rePlotFlag == 0 ) || ( exist( "modeChangeFlag" ) == 1 && modeChangeFlag == 1 );
if chgPlotFlg
    if swComp
        compNum = zeros(length(axTime),1); % �e���n��f�[�^�̔�r�M����
    end
    axIndex = 1;
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    if swComp
        compNum(axIndex) = 5;
        plot(ax,time,eMapOrg{1},'mo-');
        plot(ax,time,eYRMOrg{1}*2,'mo-');
        plot(ax,time,selectedCtrlSttOrg{1}*4,'mo-');
        plot(ax,time,(initLnSttOrg{1}*2==1)*8, 'mo-');
        plot(ax,time,(initLnSttOrg{1}*2==2)*9,'mo-');
    end
    plot(ax,time,eMap,'r.-');
    plot(ax,time,eYRM*2,'b.-');
    plot(ax,time,(mhStt~=0)*3,'g.-');
    plot(ax,time,selectedCtrlStt*4,'m.-');
    plot(ax,time,mpuLnFlg*5,'c.-');
    plot(ax,time,tolGateFlg*6, 'Color',[0.5, 0, 0.5]); % ��
    plot(ax,time,laneResetFlg*7, 'Color',[1, 0.647, 0]); % �I�����W
    plot(ax,time,(initLnStt==1)*8, 'Color', [0, 0.392, 0]); % �Z����
    plot(ax,time,(initLnStt==2)*9,'k.-');
    xline(ax,time(l));
    ax.YLim = [ 0 9 ];
%     title(ax,'e Map, ��:e YRM, ��:mhStt, ��:souroStt');
end
titleName = text('String', sprintf('{�yLMStt�z\\newline\\color{red}eMap:%d, \\color{blue}eYRM:%d, \\color{green}mhStt:%d, \\color{magenta}souroStt:%d, \\color{cyan}MPUlnStt:%d, \\newline\\color[rgb]{0.5, 0, 0.5}tolgateFlg:%d, \\color[rgb]{1, 0.647, 0}lnResetFlg:%d, \\color[rgb]{0, 0.392, 0}UnitLn:%d, \\color{black}MultiLn:%d}', ...
    eMap(l), ...
    eYRM(l)*2, ...
    (mhStt(l)~=0)*3, ...
    selectedCtrlStt(l)*4, ...
    mpuLnFlg(l)*5, ...
    tolGateFlg(l)*6, ...
    laneResetFlg(l)*7, ...
    (initLnStt(l)==1)*8, ...
    (initLnStt(l)==2)*9));
title(axTime(1),titleName.String);

if chgPlotFlg
    axIndex =2;
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    plot(ax,time,1./abs(curv(:,2)),'r.-');  hold on;
    xline(ax,time(l));
    yticks( ax, 0:100:600 );
    ax.YLim = [ 0 600 ];
%     title(ax,'�ȗ����a[m]');
end
titleName = text('String', sprintf('{�yRoadRadius�z %5.0f[m]}', ...
    1./abs(curv(l,2))));
title(axTime(2),titleName.String);

if chgPlotFlg
    axIndex =3;
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    plot(ax,time,egoSpd*3.6,'k.-'); hold on;
    xline(ax,time(l));
    ax.YLim = [ 0 120 ];
%     title(ax,'�ԑ�[km/h]');
    yticks( ax, 0:20:120 );
end
titleName = text('String', sprintf('{�ySpeed�z %3.1f[km/h]}', ...
    egoSpd(l,1)*3.6 ));
title(axTime(3),titleName.String);

if chgPlotFlg
    axIndex =4;
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    if swComp 
        compNum(axIndex) = 13;
        plot(ax,time,bitget(lmPldSttOrg{1},13),'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},14)*2,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},15)*3,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},16)*4,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},17)*5,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},18)*6,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},19)*7,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},20)*8,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},21)*9,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},22)*10,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},23)*11,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},24)*12,'mo-'); hold on;
        plot(ax,time,bitget(lmPldSttOrg{1},25)*13,'mo-'); hold on;
    end
    plot(ax,time,bitget(lmPldStt,13),'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,14)*2,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,15)*3,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,16)*4,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,17)*5,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,18)*6,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,19)*7,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,20)*8,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,21)*9,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,22)*10,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,23)*11,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,24)*12,'.-'); hold on;
    plot(ax,time,bitget(lmPldStt,25)*13,'.-'); hold on;
    yticks(ax,[0:2:15]);
    xline(ax,time(l));
    yticklabels(ax,{'OFF','721','723','725','727','729','731'})
    % legend('[1]MH�ُ�','[2]�������H�O','[3]B2�֎~��ԑ��s','[4]�n�}�ႢASAP','[5]�n�}�Ⴂ�i�`��j','[6]�Ԑ����n�}�Ⴂ','[7]���ԃ��[���n�}���Ȃ�','[8]�n�}���[�����Ȃ�','[9]���ԃ��[���s����','[10]�H�����蒴��','[11]�F�����ׂɂ�鎩�Ȉʒu���X�g','[12]�f�b�h���R���ߌx��','[13]�f�b�h���R����','[14]�����n�}�Ⴂ','[15]�Ԑ���E���\���EHD');
    ax.YLim = [ 0 13 ];
%         title(ax,'lmPldStt');
end
onBit = '';
for bitCnt = 1:13
    if bitget(lmPldStt(l,:),12+bitCnt)
        onBit = strcat(onBit, string(bitCnt+719), ', ');
    end
end
titleName = text('String', sprintf('{�ylmPldStt�z %s}', ...
    onBit ));
title(axTime(4),titleName.String);

%         titleName = text('String', sprintf('{xcorrStt [1]:%d [2]:%d [3]:%d [4]:%d [5]:%d [6]:%d}', ...
%             bitget(xcorrStt(l,1),1), ...
%             bitget(xcorrStt(l,1),2)*2, ...
%             bitget(xcorrStt(l,1),3)*3, ...
%             bitget(xcorrStt(l,1),4)*4, ...
%             bitget(xcorrStt(l,1),5)*5, ...
%             bitget(xcorrStt(l,1),6)*6 ...
%             ));
%         title(axTime(4),titleName.String);
if chgPlotFlg
    % yrmStt
    axIndex = 5;
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    if swComp 
        compNum(axIndex) = 11;
        plot(ax,time,bitget(yrmSttOrg{1},1),'mo-'); hold on;
        plot(ax,time,bitget(yrmSttOrg{1},2)*2,'mo-'); hold on;
        plot(ax,time,bitget(yrmSttOrg{1},3)*3,'mo-'); hold on;
        plot(ax,time,bitget(yrmSttOrg{1},4)*4,'mo-'); hold on;
        plot(ax,time,bitget(yrmSttOrg{1},5)*5,'mo-'); hold on;
        plot(ax,time,bitget(yrmSttOrg{1},6)*6,'mo-'); hold on;
        plot(ax,time,bitget(yrmSttOrg{1},7)*7,'mo-'); hold on;
        plot(ax,time,bitget(yrmSttOrg{1},8)*8,'mo-'); hold on;
        plot(ax,time,bitget(yrmSttOrg{1},9)*9,'mo-'); hold on;
        plot(ax,time,bitget(yrmSttOrg{1},10)*10,'mo-'); hold on;
        plot(ax,time,bitget(yrmSttOrg{1},11)*11,'mo-'); hold on;
    end
    plot(ax,time,bitget(yrmStt,1),'.-'); hold on;
    plot(ax,time,bitget(yrmStt,2)*2,'.-'); hold on;
    plot(ax,time,bitget(yrmStt,3)*3,'.-'); hold on;
    plot(ax,time,bitget(yrmStt,4)*4,'.-'); hold on;
    plot(ax,time,bitget(yrmStt,5)*5,'.-'); hold on;
    plot(ax,time,bitget(yrmStt,6)*6,'.-'); hold on;
    plot(ax,time,bitget(yrmStt,7)*7,'.-'); hold on;
    plot(ax,time,bitget(yrmStt,8)*8,'.-'); hold on;
    plot(ax,time,bitget(yrmStt,9)*9,'.-'); hold on;
    plot(ax,time,bitget(yrmStt,10)*10,'.-'); hold on;
    plot(ax,time,bitget(yrmStt,11)*11,'.-'); hold on;
    xline(ax,time(l));
    % title(ax16,{'[1]e lineCam','[2]e lineMap','[3]e R','[4]e T','[5]e de','[6]e cnt','[7]e wrongLane','[8]CamLineLostFlg','[9]CamDiffAsapFlag','[10]CamLineLostBothFlg','[11]CamBothErrFlg'});
    ax.YLim = [ 0 12 ];
    yticks( ax, 0:2:15 );
    title(ax,'yrmStt');
end
onBit = '';
for bitCnt = 1:11
    if bitget(yrmStt(l,:),bitCnt)
        onBit = strcat(onBit, string(bitCnt), ', ');
    end
end
titleName = text('String', sprintf('{�yyrmStt�z %s}', ...
    onBit ));
title(axTime(5),titleName.String);

if chgPlotFlg
    axIndex = 6;
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    if swComp 
        compNum(axIndex) = 6;
        plot(ax,time,bitget(xcorrSttOrg{1},1),'mo-'); hold on;
        plot(ax,time,bitget(xcorrSttOrg{1},2)*2,'mo-'); hold on;
        plot(ax,time,bitget(xcorrSttOrg{1},3)*3,'mo-'); hold on;
        plot(ax,time,bitget(xcorrSttOrg{1},4)*4,'mo-'); hold on;
        plot(ax,time,bitget(xcorrSttOrg{1},5)*5,'mo-'); hold on;
        plot(ax,time,bitget(xcorrSttOrg{1},6)*6,'mo-'); hold on;
    end
    plot(ax,time,bitget(xcorrStt,1),'b.-'); hold on;
    plot(ax,time,bitget(xcorrStt,2)*2,'b.-'); hold on;
    plot(ax,time,bitget(xcorrStt,3)*3,'b.-'); hold on;
    plot(ax,time,bitget(xcorrStt,4)*4,'b.-'); hold on;
    plot(ax,time,bitget(xcorrStt,5)*5,'b.-'); hold on;
    plot(ax,time,bitget(xcorrStt,6)*6,'b.-'); hold on;
    xline(ax,time(l));
    ax.YLim = [ 0 6 ];
    yticks( ax, 0:2:6 );
%         title(ax,{'�c�ʒu�␳��� [1]ICP [2]DR [3]�� [4]FadeOut [5]limit'});
end
onBit = '';
for bitCnt = 1:6
    if bitget(xcorrStt(l,:),bitCnt)
        onBit = strcat(onBit, string(bitCnt), ', ');
    end
end
titleName = text('String', sprintf('{�yxcorrStt�z %s}', ...
    onBit ));
title(axTime(6),titleName.String);

if chgPlotFlg
    axIndex = 7;
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    if swXcorr == 0
        if swComp 
            compNum(axIndex) = 1;
            plot(ax,time,laneLocOrg{1},'mo-'); hold on;
        end
        plot(ax,time,laneLocType-1,'k.-','MarkerSize',20);
        plot(ax,time,laneLocNL-1,'c.-','MarkerSize',15);
        plot(ax,time,mpuLnLoc,'g.-','MarkerSize',10);
        plot(ax,time,initLaneLoc-1,'b.-','MarkerSize',5);
        plot(ax,time,laneLoc,'r.-','MarkerSize',2);
    else
        if swComp 
            compNum(axIndex) = 15;
        end
        for i = 1:15
            if swComp 
                plot(ax,time,bitget( xcorrIcpErrSttOrg{1}, i ) * i, "mo-" );
            end
            plot(ax,time,bitget( xcorrIcpErrStt, i ) * i, ".-" );
        end
        ax.YLim = [ 0 15 ];
        yticks( ax, 0:2:15 );        
    end
    xline(ax,time(l));
end
if swXcorr == 0
    titleName = text('String', sprintf('{�ylaneLoc�z \\color{black}type:%d, \\color{cyan}NL:%d, \\color{green}MPU:%d, \\color{blue}Init:%d, \\color{red}LM:%d}', ...
    laneLocType(l,:)-1, ...
    laneLocNL(l,:)-1, ...
    mpuLnLoc(l,:), ...
    initLaneLoc(l,:)-1, ...
    laneLoc(l,:)));
else
    onBit = '';
    for bitCnt = 1:15
        if bitget(xcorrIcpErrStt(l,:),bitCnt)
            onBit = strcat(onBit, string(bitCnt), ', ');
        end
    end
    titleName = text('String', sprintf('{�yxcorrIcpErrStt�z %s}', ...
    onBit ));
end
title(axTime(7),titleName.String);

if chgPlotFlg
    axIndex = 8;
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    if swComp 
        compNum(axIndex) = 1;
        plot(ax,time,lmCorrDxOrg{1},'mo-'); hold on;
%             plot(ax,time,xcorrIcpDxOrg{1},'mo-'); hold on;    
    end
    plot(ax,time,lmCorrDx,'b.-'); hold on;
%         plot(ax,time,S_lmmlXcorrIcpDx.signals.values,'r.-'); hold on;
%         ax.YLim = [ -30 30 ];
%         yticks( ax, -30:5:30 );
    xline(ax,time(l));
%         title(ax,'�c�ʒu�␳��[m]');
end
titleName = text('String', sprintf('{�yXcorrX�z %2.2f[m]}', ...
    lmCorrDx(l,:)));
title(axTime(8),titleName.String);

% if chgPlotFlg
%     axIndex = 8;
%     ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
%     plot(ax,time,lmCorrDy(:,:),'r.-'); hold on;
% %         ax.YLim = [ -4 4 ];
% %         yticks( ax, -4:1:4 );
%     xline(ax,time(l));
% %         title(ax,'���ʒu�␳��[m]');
% end
% titleName = text('String', sprintf('{�yYcorrY�z %2.2f[m]}', ...
%     lmCorrDy(l,:)));
% title(axTime(8),titleName.String);

if chgPlotFlg
    axIndex = 9;
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
%     plot(ax,time,lmCorrDyaw*180/pi,'r.-'); hold on;
%     xline(ax,time(l));
% %         ax.YLim = [ -5 5 ];
% %         yticks( ax, -4:2:4 );
% %         title(ax,{'�p���p�␳��[deg] (��:�� ��:�c)'});
% end
% titleName = text('String', sprintf('{�yYcorrYaw�z %2.2f[deg]}', ...
%     lmCorrDyaw(l,:)*180/pi));
    plot(ax,time(2:end),diff(Group1Time),'r.-'); hold on;
    if swCANape
        plot(ax,Group2Time(2:end),diff(Group2Time),'b.-'); hold on;
        plot(ax,Group1Time(2:end),diff(double(saTldMiBusOut_saTldEgoMovBusOut_log.saTldEgoMovCnt.signals.values))./(10^6),'g.-'); hold on;
        if length(Group2Time) > length(saTldMiBusOut_lmTldMapBusOut_log.lmTldMapCnt.signals.values)
            plot(ax,Group2Time(2:end-1),diff(double(saTldMiBusOut_lmTldCamBusOut_log.lmTldCamCnt.signals.values))./(10^6),'m.-'); hold on;
        elseif length(Group2Time) < length(saTldMiBusOut_lmTldMapBusOut_log.lmTldMapCnt.signals.values)
            plot(ax,Group2Time(2:end),diff(double(saTldMiBusOut_lmTldMapBusOut_log.lmTldMapCnt.signals.values(1:end-1)))./(10^6),'m.-'); hold on;
        else
            plot(ax,Group2Time(2:end),diff(double(saTldMiBusOut_lmTldMapBusOut_log.lmTldMapCnt.signals.values))./(10^6),'m.-'); hold on;
        end
        plot(ax,time,mpuDiffTime.*0.01,'c.-'); hold on;
    else
    end
    xline(ax,time(l));
end
if swCANape
    titleName = text('String', sprintf('{�yDiff(s)�z \\color{red}Gr1Tm, \\color{blue}Gr2Tm, \\color{green}CamCnt, \\color{magenta}MapCnt, \\color{cyan}MpuDf}'));
    % titleName = text('String', sprintf('{�yDiff(s)�z \\color{red}Gr1:%2.2f, \\color{blue}Gr2:%2.2f, \\color{green}Cam:%2.2f, \\color{magenta}Map:%2.2f}', ...
    % diff(Group1Time(max(l-1,1):l)), ...
    % diff(Group2Time(max(l-1,1):l)), ...
    % diff(double(saTldMiBusOut_saTldEgoMovBusOut_log.saTldEgoMovCnt.signals.values(max(l-1,1):l)))./(10^6), ...
    % diff(double(saTldMiBusOut_lmTldMapBusOut_log.lmTldMapCnt.signals.values(max(l-1,1):l)))./(10^6)));
else
    titleName = text('String', sprintf('{�yDiff(s)�z \\color{red}Gr1Tm}'));
end
title(axTime(9),titleName.String);

%% 2��ڂ̎��n��v���b�g
axIndex = plotGyo + 1;
if chgPlotFlg
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    plot(ax,time,camEndX(:,1),'r.-'); hold on;
    plot(ax,time,camEndX(:,2),'b.-'); hold on;
    xline(ax,time(l));
    ax.YLim = [ -5 150 ];
%     title(ax,'CamEndX[m]');
end
titleName = text('String', sprintf('{�yCamEndX�z \\color{red}Lt:%3.1f, \\color{blue}Rt:%3.1f}', ...
camEndX(l,1), ...
camEndX(l,2)));
title(axTime(axIndex),titleName.String);

axIndex = axIndex + 1;
if chgPlotFlg
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    plot(ax,time,laneConfidence(:,1),'r.-'); hold on;
    plot(ax,time,laneConfidence(:,2),'b.-'); hold on;
    xline(ax,time(l));
    ax.YLim = [ 0 1 ];
    yticks( ax, 0:0.2:1 );    
%     title(ax,'CamProb[m]');
end
titleName = text('String', sprintf('{�yCamConf�z \\color{red}Lt:%1.1f, \\color{blue}Rt:%1.1f}', ...
laneConfidence(l,1), ...
laneConfidence(l,2)));
title(axTime(axIndex),titleName.String);

axIndex = axIndex + 1;
if chgPlotFlg
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    plot(ax,time,laneQuality(:,1),'r.-'); hold on;
    plot(ax,time,laneQuality(:,2),'b.-'); hold on;
    plot(ax,time,linebFlg(:,1)*4,'k.-'); hold on;
    plot(ax,time,linebFlg(:,2)*5,'k.-'); hold on;
    xline(ax,time(l));
    ax.YLim = [ 0 5 ];
    yticks( ax, 0:1:5 );    
    % title(ax,'CamQualty&Clineb');
end
onBit = '';
for bitCnt = 1:2
    if linebFlg(l,bitCnt)
        if bitCnt == 1
            onBit = strcat(onBit, 'Lt');
        else
            onBit = strcat(onBit, ',Rt');
        end
    end
end
titleName = text('String', sprintf('{�yCamQuality&Clineb�z \\color{red}Lt:%d, \\color{blue}Rt:%d, \\color{black}clineb:%s}', ...
laneQuality(l,1), ...
laneQuality(l,2), ...
onBit));
title(axTime(axIndex),titleName.String);

axIndex = axIndex + 1;
if chgPlotFlg
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    plot(ax,time,camC0(:,1),'r.-','MarkerSize',10);
    plot(ax,time,camC0(:,2),'b.-','MarkerSize',10);
    ax.YLim = [ -3 3 ];
    xline(ax,time(l));
end
titleName = text('String', sprintf('{�yCamC0�z \\color{red}Lt:%3.2f, \\color{blue}Rt:%3.2f}', ...
camC0(l,1), ...
camC0(l,2)));
title(axTime(axIndex),titleName.String);

axIndex = axIndex + 1;
if chgPlotFlg
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    plot(ax,time,laneType(:,1),'r.-','MarkerSize',10);
    plot(ax,time,laneType(:,2),'b.-','MarkerSize',10);
    xline(ax,time(l));
end
titleName = text('String', sprintf('{�yCamType�z \\color{red}Lt:%d, \\color{blue}Rt:%d}', ...
laneType(l,1), ...
laneType(l,2)));
title(axTime(axIndex),titleName.String);

axIndex = axIndex + 1;
if chgPlotFlg
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    if swComp
        compNum(axIndex) = 1;
        plot(ax,time,tgtDiffyOrg{1},'mo-', "DisplayName", "��r��" );
    end
    plot(ax, time,tgtDiffy,'b.-', "DisplayName", "1.05�b��LM���H����" );
    xline(ax,time(l));
    yticks( ax, [-0.6:0.2:0.6]);
%     title(ax,'�ڕW�ʒu�ł̉��ʒu�덷[m]');
    ax.YLim = [ -0.5 0.5 ];
end
if swComp == 0
    titleName = text('String', sprintf('{�y1.05s�摖�H�덷�ʁz%3.2f[m]}', ...
    tgtDiffy(l,:)));
else
    titleName = text('String', sprintf('{�y1.05s�摖�H�덷��[m]�zMain:%3.2f Cmp:%3.2f}', ...
    tgtDiffy(l,:),tgtDiffyOrg{1}(l,:)));
end
title(axTime(axIndex),titleName.String);

axIndex = axIndex + 1;
if chgPlotFlg
    ax = axTime( axIndex ); ax.NextPlot = 'add'; cla(ax);
    if swCANape == 0
    elseif swCANape
%         plot(ax,time,yawR*180/pi,'k.-');
        plot(ax,time,strAgl*180/pi,'k.-');
        xline(ax,time(l));
%         title(ax,'yawR[deg/s]');
    end
end
if swCANape
%     titleName = text('String', sprintf('{�yyawR�z %2.2f[deg/s]}', ...
%     yawR(l,:)));
    titleName = text('String', sprintf('{�ystrAgl�z %2.2f[deg]}', ...
    strAgl(l,:)*180/pi));
    title(axTime(axIndex),titleName.String);
end

if ( swCANape == 0 )
    % �c�ʒu�␳�c���`��
    ax = axTime( axIndex );
    ax.NextPlot = 'add';
    cla(ax);
    CP_lmmlVecIcpMapMovePoint = -30:30;
    if swComp
        xline(ax,xcorrIdxMinDistCnvOrg{1}(l,:),'m-');
        compNum(axIndex) = 1;
        plot(ax, CP_lmmlVecIcpMapMovePoint, xcorrIcpErrOrg{1}(l,:), 'mo-');
    end
    xline(ax,xcorrIdxMinDistCnv(l,:),'b-');
    plot( ax, CP_lmmlVecIcpMapMovePoint, xcorrIcpErr(l,:), 'b.-');
    title(ax,'�c�ʒu�␳�c���`��');
    ax.XLim = [ min( CP_lmmlVecIcpMapMovePoint ) max( CP_lmmlVecIcpMapMovePoint ) ];
    ax.YLim = [ 0 0.5 ];
end

if swXcorr == 0
    if swWebCam == 0
        if chgPlotFlg
            ax = axTimeEx1( 1 ); ax.NextPlot = 'add'; cla(ax);
            ex11 = plot(ax, -150:300,DiffRangeAll(l,:),'k.-');
            ax.YLim = [ 0 0.5 ];
            ax.XLim = [ -150 300 ];   
            title(ax,'�yCtrl/MapEgo�Ԑ��e�_�ԋ���[m]�z');
        
            ax = axTimeEx1( 2 ); ax.NextPlot = 'add'; cla(ax);
%             ex121 = plot(ax, -149:298,YawAngleDataDiffMap(l,:)*180/pi,'b.-');
            ex122 = plot(ax, -149:298,YawAngleDataDiff(l,:)*180/pi,'k.-');
            ax.YLim = [ 0 0.02 ];
            ax.XLim = [ -150 300 ];   
        %     title(ax,'Ctrl�Ԑ��_��Ԋp�x[deg/m]');
            titleName = text('String', sprintf('{�y�_��Ԋp�x[deg/m^2]�zCtrl \\color{blue}MapEgo \\color{magenta}���i, \\color{cyan}�J�[�u}'));
            title(ax,titleName.String);
    
            ax = axTimeEx2( 1 ); ax.NextPlot = 'add'; cla(ax);
            plot(ax, time,maxDiffRangeAll,'k.-');
            ax.YLim = [ 0 0.5 ];
            ax.XLim = [ -150 300 ];   
    
            ax = axTimeEx2( 2 ); ax.NextPlot = 'add'; cla(ax);
            plot(ax, time,maxYawAngleDataDiff*180/pi,'k.-');
            ax.YLim = [ 0 0.02 ];
            ax.XLim = [ -150 300 ];   

            if swCANape
                ax = axTimeEx2( 3 ); ax.NextPlot = 'add'; cla(ax);
                plot(ax, time,bitget(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smVecSysActivateMode.signals.values,1)*1,'r.-');
                plot(ax, time,bitget(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smVecSysActivateMode.signals.values,2)*2,'b.-');
                plot(ax, time,bitget(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smVecSysActivateMode.signals.values,3)*3,'g.-');
                plot(ax, time,bitget(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smVecSysActivateMode.signals.values,7)*7,'m.-');
                plot(ax, time,bitget(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smVecSysActivateMode.signals.values,8)*8,'c.-');
                plot(ax, time,bitget(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smVecSysActivateMode.signals.values,12)*12,'Color',[0.5, 0, 0.5]); % ��
                plot(ax, time,bitget(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smVecSysActivateMode.signals.values,16)*16,'Color',[1, 0.647, 0]); % �I�����W
                yticks(ax,[0:2:16]);
            end
        end
        ex11.YData = DiffRangeAll(l,:);
%         ex121.YData = YawAngleDataDiffMap(l,:)*180/pi;
        ex122.YData = YawAngleDataDiff(l,:)*180/pi;
        titleName = text('String', sprintf('{�yCtrl/MapEgo�Ԑ���Max�����z %3.2f[m]}', ...
        maxDiffRangeAll(l,:)));
        title(axTimeEx2(1),titleName.String);
        titleName = text('String', sprintf('{�y�_��Ԋp�x�z %3.4f[deg/m^2]}', ...
        maxYawAngleDataDiff(l,:)*180/pi));
        title(axTimeEx2(2),titleName.String);
        
        if swCANape
            onBit = '';
            for bitCnt = 1:16
                if bitget(saTldMiBusOut_ahdfCp2ApBusOut_smApBusOut_log.smVecSysActivateMode.signals.values(l,:),bitCnt)
                    onBit = strcat(onBit, string(bitCnt), ', ');
                end
            end
            titleName = text('String', sprintf('{�ysysActivateMode�z %s}', ...
                onBit ));
            title(axTimeEx2(3),titleName.String);
        end
    end
end

initializeFlag = 0;
modeChangeFlag = 0;

for axIndexMul = 1:axIndex
    ax = axTime( axIndexMul );
    if swCANape || (axIndexMul ~= axIndex)
        deleteChild(ax);
        xlinePlot = xline(ax,time(l));
        if axIndexMul == 15
            yline( ax, -0.3, "-r", "DisplayName", "2sigma min" );
            yline( ax, 0.3, "-r", "DisplayName", "2sigma max" );
        end
    end
    if swCANape==0
        if swComp && (chkbox_Comp1.Value==0 && chkbox_Comp2.Value==0)
            if compNum(axIndexMul) ~= 0
                for nonVisIdx = 1:compNum(axIndexMul)
                    ax.Children(length(ax.Children)-nonVisIdx+1).Visible = "off";
                end
            end
        elseif swComp && (chkbox_Comp1.Value || chkbox_Comp2.Value)
            if compNum(axIndexMul) ~= 0
                for nonVisIdx = 1:compNum(axIndexMul)
                    ax.Children(length(ax.Children)-nonVisIdx+1).Visible = "on";
                end
            end
        end
    end
end
if swXcorr == 0
    deleteChild(ax3);
    deleteChild(ax5);
    yline(ax3,egoSpd(l,1)*1.05,'LineWidth',2);
    yline(ax5,egoSpd(l,1)*1.05,'LineWidth',2);
    if swWebCam == 0
        for axIndexEx = 1:length(axTimeEx1)
            ax = axTimeEx1( axIndexEx );
            deleteChild(ax);
            xlinePlot = xline(ax,egoSpd(l)*2,'g-');
            if axIndexEx == 2
                ylinePlot = yline(ax,0.0066,'m-');
                ylinePlot = yline(ax,0.013,'c-');
            end
        end
        for axIndexEx = 1:length(axTimeEx2)
            ax = axTimeEx2( axIndexEx );
            deleteChild(ax);
            xlinePlot = xline(ax,time(l));
            if axIndexEx == 2
                ylinePlot = yline(ax,0.0066,'m-');
                ylinePlot = yline(ax,0.013,'c-');
            elseif axIndexEx == 3
                xlinePlot = xline(ax,time(l));
            end
        end
    end
else
    deleteChild(ax3);
    deleteChild(ax4);
    deleteChild(ax5);
    deleteChild(ax6);
    deleteChild(ax7);
    deleteChild(ax8);
    yline(ax8,900,'r-');
end

function deleteChild(ax)
    delCnt = 0;
    maxChiIdx = length(ax.Children);
    for chiIdx = 1:maxChiIdx
        if strcmp(ax.Children(chiIdx-delCnt).Type,'text') || (strcmp(ax.Children(chiIdx-delCnt).Type,'constantline'))
            delete(ax.Children(chiIdx-delCnt));
            delCnt = delCnt + 1;
        end
    end
end
