%% SN��̃v���b�g�}���쐬����
% �ړI�F���H���x�������Ȃ�v������肷�邽�߂̃O���t���v���b�g����

% �K�X���L�X�C�b�`�̐ؑւ��s��
swMove = 0;      % ��Ԏ��̏d���J�E���g�𖳎�����Ƃ�1
distTld = 100;   % �J�E���g���Ă���**m�i�ނ܂ł̓J�E���g���Ȃ�

if swLoad
    % ���̓t�@�C�����w��
    [ blfName, blfPath ] = selectInputFile();
    if blfName == ""
        fprintf( "���̓t�@�C���̎w�肪�L�����Z������܂����B\n" )
        return;
    else
        fprintf( "Input : \n" );
        disp( blfName );
    end
end

xRng = [0 1000];
xInt = [100];
loopCnt = (xRng(end) - xRng(1)) / xInt;

cntLoseTotal = 0;
cntWinTotal = 0;

% ��ԍ����̃o�b�t�@
emap0to1 = zeros(length(blfName), 1);
emap1to0 = zeros(length(blfName), 1);
yrm0to1 = zeros(length(blfName), 1);
yrm1to0 = zeros(length(blfName), 1);
accWin = zeros(length(blfName), 1);
accLose = zeros(length(blfName), 1);

% �����o�͐�t�@�C��
save_folder = 'plot_sn_result';
if exist(save_folder, 'dir') == 0
    mkdir(save_folder);
end
% ���ʂ��i�[����t�@�C����
str = sprintf('%s\\dataList.txt', save_folder);
fileID = fopen(str,'w');
str = sprintf('%s\\emap_good.csv', save_folder);
file_emap10 = fopen(str, 'w');
fprintf(file_emap10, 'data, begin, end\n');
str = sprintf('%s\\emap_bad.csv', save_folder);
file_emap01 = fopen(str, 'w');
fprintf(file_emap01, 'data, begin, end\n');
str = sprintf('%s\\eyrm_good.csv', save_folder);
file_eyrm10 = fopen(str, 'w');
fprintf(file_eyrm10, 'data, begin, end\n');
str = sprintf('%s\\eyrm_bad.csv', save_folder);
file_eyrm01 = fopen(str, 'w');
fprintf(file_eyrm01, 'data, begin, end\n');
str = sprintf('%s\\accuracy_good.csv', save_folder);
file_acc_win = fopen(str, 'w');
fprintf(file_acc_win, 'data, begin, end\n');
str = sprintf('%s\\accuracy_bad.csv', save_folder);
file_acc_lose = fopen(str, 'w');
fprintf(file_acc_lose, 'data, begin, end\n');

% �e�f�[�^���`�F�b�N
for folderNo = 1:length(blfName)
    fprintf('�y%3d / %3d�zData : %s\n',folderNo, length(blfName), blfName{folderNo});
    fprintf(fileID,'�y%3d / %3d�zData : %s\n',folderNo, length(blfName), blfName{folderNo});
    if swLoad
        clearvars -except fileID loopCnt xInt xRng sw* distTld distC0Tld distC0TldSmCv folderNo blfName dirName folderName simResName dirNameOrg simResNameOrg *All matNameCalc cnt*Total emap*to* yrm*to* swDir X ts C0LngSmpl file* save_folder accWin accLose lc_invalid_sample
        folderName = blfName{folderNo};
        % �ȉ�plotLmLine����R�s�y
        % �f�[�^�����[�h
        fprintf( "�� Data Loading\n" );
        LoadData;
        swGenAndSig;

        % �f�[�^������̕ϐ��֓���
        tic;
        fprintf( "�� Data Setting" );
        SetData;
        fprintf('        �ˏ������ԁF%.1f[s]\n',toc);

        % C0�O��,LM���H���x�v�Z
%         if swCalcLoad
%             load(strcat(dirName, folderName, '\', matNameCalc,'.mat'));
%         else
        tic;
        fprintf( "�� Calc C0 Trace" );
        accuracyVerif;
        fprintf('       �ˏ������ԁF%.1f[s]\n',toc);
%         end

%         if swSave
%             tic;
%             fprintf( "�� Data Saving" );
%             saveSigSet = {'tgt*Diff*', ...
%                 'tgtStt', ...
%                 'num', ...
%                 'swC0PointSttDebug', ...
%                 'swWidth', ...
%                 'swTgtDiffDetail', ...
%                 'swExclude*', ...
%                 'TransCline*Pos*', ...
%                 'c0PointStt*', ...
%                 };
%             if swComp
%                 if length(simResNameOrg) == 1
%                     save(strcat(dirName, folderName, '\', 'analysisResult_',simResName,'_vs_',string(simResNameOrg{1}),'.mat'),saveSigSet{:});
%                 elseif length(simResNameOrg) == 2
%                     save(strcat(dirName, folderName, '\', 'analysisResult_',simResName,'_vs_',string(simResNameOrg{1}),'_vs_',string(simResNameOrg{2}),'.mat'),saveSigSet{:});
%                 end
%             else
%                 save(strcat(dirName, folderName, '\', 'analysisResult_',simResName,'.mat'),saveSigSet{:});
%             end
%             fprintf('         �ˏ������ԁF%.1f[s]\n',toc);
%         end
        % �����܂�plotLmLine����R�s�y            
        xcorrLB = S_lmmlXCorrMLB.signals.values;
        xcorrRB = S_lmmlXCorrMRB.signals.values;
        for i = 1:length(time)
            xcorrLNum(i) = sum(xcorrLB(i,1:1000));
            xcorrRNum(i) = sum(xcorrRB(i,1:1000));
        end
        xcorrCamLB = S_lmmlXCorrCamLB.signals.values;
        xcorrCamRB = S_lmmlXCorrCamRB.signals.values;
        for i = 1:length(time)
            xcorrCamLNum(i) = sum(xcorrCamLB(i,1:1000));
            xcorrCamRNum(i) = sum(xcorrCamRB(i,1:1000));
        end
    end

    dataNo = ones(size(time)) * folderNo;

   %% ���H�덷�f�[�^�W�v
    % figure�Ƀv���b�g�������
%     validFlg = double(bitget(S_lmInhStt.signals.values,3) == 0) ...
%            .*double(bitget(ORG{1}.S_lmInhStt.signals.values,3) == 0);
       
%     validFlg = double(bitget(S_lmmlXcorrStt.signals.values,1) == 1) ...
%            .*double(bitget(S_lmInhStt.signals.values,3) == 0) ...
%            .*double(bitget(S_lmInhStt.signals.values,5) == 0) ...
%            .*double(bitget(ORG{1}.S_lmInhStt.signals.values,3) == 0) ...
%            .*double(bitget(ORG{1}.S_lmInhStt.signals.values,5) == 0);

%     validFlg = ones(size(time));

    validFlg = double(bitget(S_lmInhStt.signals.values,3) == 0) ...
           .*double(bitget(S_lmInhStt.signals.values,5) == 0) ...
           .*double(bitget(ORG{1}.S_lmInhStt.signals.values,3) == 0) ...
           .*double(bitget(ORG{1}.S_lmInhStt.signals.values,5) == 0);

%     validFlg = double( double(bitget(S_lmmlXcorrStt.signals.values,1) == 1) ...
%            +double(bitget(S_lmmlXcorrStt.signals.values,2) == 1)  ~= 0 ) ...
%            .*double(bitget(S_lmInhStt.signals.values,3) == 0) ...
%            .*double(bitget(S_lmInhStt.signals.values,5) == 0) ...
%            .*double(bitget(ORG{1}.S_lmInhStt.signals.values,3) == 0) ...
%            .*double(bitget(ORG{1}.S_lmInhStt.signals.values,5) == 0);

    % �����Ƀv���b�g����M��
    % xLabel = 1./S_lmVecCtrlLnPntCurvature.signals.values(:,151+451);
    icpBwLineLen = max(min(xcorrLNum,xcorrCamLNum),min(xcorrRNum,xcorrCamRNum));
    xLabel = icpBwLineLen';

    % �c���Ƀv���b�g����M��
    % yLabel = abs(tgtDiffy);
%     yLabel = abs(transpose(tgtDiffyOrg{1})) - abs(tgtDiffy);
    yLabel = abs(tgtDiffyOrg{1}) - abs(tgtDiffy);

    % �f�[�^���W�v����
    cntLose = zeros(loopCnt,1);
    cntWin = zeros(loopCnt,1);
    cntDraw = zeros(loopCnt,1);
    cnt = zeros(loopCnt,2);
    smplCnt = zeros(loopCnt,3);
    sumMovX = zeros(loopCnt,3);
    acc_lose = zeros(length(time), 1);
    acc_win = zeros(length(time), 1);
    for i = 1:length(time)
        for j = 1:loopCnt
            xMin = xRng(1) + xInt * (j - 1);
            xMax = xRng(1) + xInt * j;
            if (xLabel(i) >= xMin) && (xLabel(i) <= xMax)
                if (yLabel(i) < -0.2) && (validFlg(i) == 1) && (abs(tgtDiffy(i)) > 0.3) && (abs(tgtDiffyOrg{1}(i)) < 0.3)
%                 if (yLabel(i) < -0.1) && (validFlg(i) == 1)
                    if swMove
                        for k = smplCnt(j,1)+1:i
                            sumMovX(j,1) = sumMovX(j,1) + EgoMovX(k);
                        end
                    end
                    if (sumMovX(j,1) > distTld) || (smplCnt(j,1) == 0) || (swMove == 0)
                        cntLose(j) = cntLose(j) + 1;
                        sumMovX(j,1) = 0;
                        smplCnt(j,1) = i;
                        acc_lose(i) = 1;
                        break;
                    end
                elseif (yLabel(i) > 0.2) && (validFlg(i) == 1) && (abs(tgtDiffyOrg{1}(i)) > 0.3) && (abs(tgtDiffy(i)) < 0.3)
%                 elseif (yLabel(i) > 0.1) && (validFlg(i) == 1)
                    if swMove
                        for k = smplCnt(j,2)+1:i
                            sumMovX(j,2) = sumMovX(j,2) + EgoMovX(k);
                        end
                    end
                    if (sumMovX(j,2) > distTld) || (smplCnt(j,2) == 0) || (swMove == 0)
                        cntWin(j) = cntWin(j) + 1;
                        sumMovX(j,2) = 0;
                        smplCnt(j,2) = i;
                        acc_win(i) = 1;
                        break;
                    end
                else
                    if swMove
                        for k = smplCnt(j,3)+1:i
                            sumMovX(j,3) = sumMovX(j,3) + EgoMovX(k);
                        end
                    end
                    if (sumMovX(j,3) > distTld) || (smplCnt(j,3) == 0) || (swMove == 0)
                        cntDraw(j) = cntDraw(j) + 1;
                        sumMovX(j,3) = 0;
                        smplCnt(j,3) = i;
                        break;
                    end
                end
            end
        end
    end
    
    cnt(:,1) = cntLose;
    cnt(:,2) = cntWin;
    cnt(:,3) = cntDraw;
    
    xLabelAll{folderNo} = xLabel;
    yLabelAll{folderNo} = yLabel;
    validFlgAll{folderNo} = validFlg;
    timeAll{folderNo} = time;
    dataNoAll{folderNo} = dataNo;
    cntAll{folderNo} = cnt;
    
    for j = 1:loopCnt
        cntLoseTotal = cntLoseTotal + cntLose(j);
        cntWinTotal = cntWinTotal + cntWin(j);
    end
    
    %% lmInhStt ��r
    org_emap = cast(bitget(ORG{1}.S_lmInhStt.signals.values,3), 'int32');
    mod_emap = cast(bitget(S_lmInhStt.signals.values,3), 'int32');
    org_yrm = cast(bitget(ORG{1}.S_lmInhStt.signals.values,5), 'int32');
    mod_yrm = cast(bitget(S_lmInhStt.signals.values,5), 'int32');
    
    sub_emap = mod_emap - org_emap;
    
    sub_emap01 = sub_emap;
    sub_emap01(sub_emap01<=0) = 0;
    sub_emap01 = checkContStt(sub_emap01, time, 5);
    emap0to1(folderNo) = nnz(sub_emap01);
    
    sub_emap10 = sub_emap;
    sub_emap10(sub_emap10>=0) = 0;
    sub_emap10 = checkContStt(sub_emap10, time, 5);
    emap1to0(folderNo) = nnz(sub_emap10);
    
    sub_yrm = mod_yrm - org_yrm;
    
    sub_yrm01 = sub_yrm;
    sub_yrm01(sub_yrm01<=0) = 0;
    sub_yrm01 = checkContStt(sub_yrm01, time, 5);
    yrm0to1(folderNo) = nnz(sub_yrm01);
    
    sub_yrm10 = sub_yrm;
    sub_yrm10(sub_yrm10>=0) = 0;
    sub_yrm10 = checkContStt(sub_yrm10, time, 5);
    yrm1to0(folderNo) = nnz(sub_yrm10);
    
    accWin(folderNo) = nnz(acc_win);
    accLose(folderNo) = nnz(acc_lose);
        
    %% �t�@�C�������o��
    writeSttDiff(file_emap01, sub_emap01, time, blfName{folderNo}, 0);
    writeSttDiff(file_emap10, sub_emap10, time, blfName{folderNo}, 0);
    writeSttDiff(file_eyrm01, sub_yrm01, time, blfName{folderNo}, 0);
    writeSttDiff(file_eyrm10, sub_yrm10, time, blfName{folderNo}, 0);
    writeSttDiff(file_acc_win, acc_win, time, blfName{folderNo}, 0);
    writeSttDiff(file_acc_lose, acc_lose, time, blfName{folderNo}, 0);
end

fclose(file_emap01);
fclose(file_emap10);
fclose(file_eyrm01);
fclose(file_eyrm10);
fclose(file_acc_win);
fclose(file_acc_lose);
fclose(fileID);

% if swLoad && (swCalcLoad == 0)
if swLoad
    save(strcat(dirName,'aggregationResult_',simResName,'vs',simResNameOrg{1},'.mat'),'blfName','xLabelAll','yLabelAll','validFlgAll','timeAll','dataNoAll','cnt*Total','cnt*All','loopCnt');
end

fprintf( "�� Figure Plotting\n" );

%% ���H�덷�W�v����figure�쐬
cntLoseAll = zeros(loopCnt,1);
cntWinAll = zeros(loopCnt,1);
cntDrawAll = zeros(loopCnt,1);
for folderNo = 1:length(blfName)
    if length(cntAll{folderNo}) == 3
    else
        cntLoseAll = cntLoseAll + cntAll{folderNo}(:,1);
        cntWinAll = cntWinAll + cntAll{folderNo}(:,2);
        cntDrawAll = cntDrawAll + cntAll{folderNo}(:,3);
    end
end

cntAllCnv(:,1) = cntLoseAll;
cntAllCnv(:,2) = cntWinAll;

%% �f�[�^�W�v 
% �~�O���t���v���b�g
figure(122); clf;
plotPieFig(accWin,accLose,save_folder,'���H���x�ω�����');

figure(123); clf;
plotPieFig(emap1to0,emap0to1,save_folder,'eMap�ω�����');

figure(124); clf;
plotPieFig(yrm1to0,yrm0to1,save_folder,'eYRM�ω�����');

% �����W�v�̂��߂̖_�O���t�v���b�g
% ���H���x
loseCntPerData = zeros(length(blfName),1);
winCntPerData = zeros(length(blfName),1);
for folderNo = 1:length(blfName)
    for i = 1:10
        loseCntPerData(folderNo) = loseCntPerData(folderNo) + cntAll{folderNo}(i,1);
        winCntPerData(folderNo) = winCntPerData(folderNo) + cntAll{folderNo}(i,2);
    end
end

clear compRes;
compRes = [accWin accLose]; % [���P���� ��������]�̏��œ��͂��邱��
legendGood = '���H���xUP'; legendBad = '���H���xDOWN';
dataNum = length(blfName);
figSN = figure(999999);
figSN.Name = '���ԑO��1.05s��̑��H�덷��r����';
plotBarRes(compRes,legendGood,legendBad,dataNum,save_folder);

% eMap
clear compRes;
compRes = [emap1to0 emap0to1]; % [���P���� ��������]�̏��œ��͂��邱��
legendGood = '�n�}�p����UP(eMap1��0)'; legendBad = '�n�}�p����DOWN(eMap0��1)';
dataNum = length(blfName);
figSN = figure(111111);
figSN.Name = '�n�}�p����(eMap��ON/OFF)��r����';
plotBarRes(compRes,legendGood,legendBad,dataNum,save_folder);

% eYrm
clear compRes;
compRes = [yrm1to0 yrm0to1]; % [���P���� ��������]�̏��œ��͂��邱��
legendGood = '�n�}�}�b�`���O��UP(eYrm1��0)'; legendBad = '�n�}�}�b�`���O��DOWN(eYrm0��1)';
dataNum = length(blfName);
figSN = figure(111112);
figSN.Name = '�n�}�}�b�`���O(eYrm��ON/OFF)��r����';
plotBarRes(compRes,legendGood,legendBad,dataNum,save_folder);

function plotBarRes(compRes,legendGood,legendBad,dataNum,save_folder)
    hold on; grid on;
    b = bar(compRes);
    legend(legendGood,legendBad);
    xticks([0:dataNum]);
    xlabel('�f�[�^No'); ylabel('�������������T���v�����O��');
    xtips1 = b(1).XEndPoints; ytips1 = b(1).YEndPoints; labels1 = string(b(1).YData);
    text(xtips1,ytips1,labels1,'HorizontalAlignment','center','VerticalAlignment','bottom')
    xtips2 = b(2).XEndPoints; ytips2 = b(2).YEndPoints; labels2 = string(b(2).YData);
    text(xtips2,ytips2,labels2,'HorizontalAlignment','center','VerticalAlignment','bottom')
    saveas(gcf, [save_folder, '\\accuracy_comp.fig']);
end


function [ blfName, blfPath ] = selectInputFile()
   [ blfName, blfPath] = uigetfile({'../*.blf'}, 'Pick blf files', 'MultiSelect', 'on');
   if isequal( blfName, 0 )
       blfName = "";
   else
       blfName = strrep(blfName, '.BLF', '');
       blfName = strrep(blfName, '.mat', ''); %mat�t�@�C����I�����ꂽ�ꍇ�������ł���悤�ɏC��
       blfName = strrep(blfName, '.blf', '');
       blfName = cellstr( blfName );
   end
end

function writeSttDiff(file, stt_diff, time, folderName, thr)
    found = false;
    begin_index = 0;
    for i = 1:length(time)
        if stt_diff(i)
            if found
                % ���̂܂�
            else
                found = true;
                begin_index = i;
            end
        else
            if found
                found = false;
                if i - begin_index > thr
                    fprintf(file, '%s, %f, %f\n', folderName, time(begin_index), time(i - 1));
                end
            else
                % ���̂܂�
            end
        end
    end
    if found
        if length(time) - begin_index > thr
            fprintf(file, '%s, %f, %f\n', folderName, time(begin_index), time(end));
        end
    end
end

function stt_diff2 = checkContStt(stt_diff, time, thr)
    stt_diff2 = stt_diff;
    found = false;
    begin_index = 0;
    for i = 1:length(time)
        if stt_diff(i)
            if found
                % ���̂܂�
            else
                found =true;
                begin_index = i;
            end
        else
            if found
                found = false;
                if i - begin_index < thr
                    stt_diff2(begin_index:i-1) = 0;
                end
            else
                % ���̂܂�
            end
        end
    end
    
    if found
        if length(time) - begin_index < thr
            stt_diff2(begin_index:length(time)) = 0;
        end
    end
end

function plotPieFig(win,lose,save_folder,titleName)
    cntWinTotal = sum(win);
    cntLoseTotal = sum(lose);
    cntTotal = cntWinTotal + cntLoseTotal;
    if cntTotal == 0
        p = pie([0 0]);
    else
        p = pie([cntWinTotal/cntTotal*100 cntLoseTotal/cntTotal*100]);
    end
    p(1).FaceColor = 'b';
    p(3).FaceColor = 'r';
    p(2).FontSize = 20;
    p(4).FontSize = 20;
    ldg = legend('���x����','���x����');
    ldg.Location = 'bestoutside';
    fprintf(1,'���x���� = %d�T���v��\n���x���� = %d�T���v��\n', cntWinTotal, cntLoseTotal);
    title(titleName);
    saveas(gcf, [save_folder, '\\', titleName, '_accuracy.fig']);
end
