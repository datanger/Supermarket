1. <fix>(问题点筛选): 根据客户需求更改问题点筛选逻辑
2. <fix>(parapara): 修正绘制曲线时相邻y值不同点之间无竖直线连接的问题
3. <fix>(汇总表生成): 根据客户需求更改汇总表的模板以及输入格式
4. <fix>(解析表格生成): 根据客户需求更改解析表格输出格式及sheet页名称
5. <feat>(parapara): 根据客户需求更改Parapara显示内容
6.  'master' into zhou_parapara_20250820
7. *<feat>(parapara): 根据客户需求更改Parapara显示内容
