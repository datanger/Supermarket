function RePlotLmLine( h, event )
    parent = h.Parent;
    figure( parent );
    
    children = h.Parent.Children;
    for i = 1:length( children )
        child = children( i );
        if class( child ) == "matlab.ui.control.UIControl"
            if child.Tag == "time"
                if child.Style == "slider"
                    slider_obj = child;
                elseif child.Style == "edit"
                    timeEdit_obj = child;
                end
            end
        end
    end

    %edit��slider����
    if strcmp( h.Tag, "time" )
        if strcmp( h.Style, "edit" )
            % edit�̓��e��slider�ɔ��f
            time = evalin( "caller", "time" );
            time = round(time,2);
            slider_obj = evalin( "caller", "slider_obj" );
            nowTime =  str2double( h.String );
%             if mod(nowTime,0.05) > 0.025 
%                 nowTimeFix = nowTime + 0.05 - mod(nowTime,0.05);
%             else
%                 nowTimeFix = nowTime - mod(nowTime,0.05);
%             end
%             nowIdx = find( abs( time - nowTimeFix ) == min(abs((time - nowTimeFix))) );
%             slider_obj.Value = nowIdx(1);
            [~, pIndex] = min(abs(nowTime - time));
            slider_obj.Value = pIndex;
%             slider_obj.Value = find( abs( time - str2double( h.String ) ) < 0.01 );
            assignin( "caller", "slider_obj", slider_obj );
        elseif strcmp( h.Style, "slider" )
            % slider�̒l��edit�ɔ��f
            timeEdit_obj = evalin( "caller", "timeEdit_obj" );
            time = evalin( "caller", "time" );
            time = round(time,2);
            timeEdit_obj.String = num2str( time( floor( h.Value ) ) );
            assignin( "caller", "timeEdit_obj", timeEdit_obj );
        elseif strcmp( h.Style, "pushbutton" )
            slider_obj = evalin( "caller", "slider_obj" );
            timeIndex = uint32( slider_obj.Value + ( 20 * str2double( h.String ) ) );
            slider_obj.Value = timeIndex;
            assignin( "caller", "slider_obj", slider_obj );
            timeEdit_obj = evalin( "caller", "timeEdit_obj" );
            time = evalin( "caller", "time" );
            time = round(time,2);
            timeEdit_obj.String = num2str( time( timeIndex ) );
            assignin( "caller", "timeEdit_obj", timeEdit_obj );
        end
    elseif strcmp( h.Tag, "mode" )
        
        currentMode = evalin( "caller", "swXcorr" );
        
        if h.Value == 1
            newMode = 0;
        elseif h.Value == 2
            newMode = 1;
        elseif h.Value == 3
            newMode = 2;
        elseif h.Value == 4
            newMode = 3;
        end
           
        if currentMode ~= newMode
            assignin( "caller", "swXcorr", newMode );
            assignin( "caller", "modeChangeFlag", 1 );
        end
    end
    
    % �ĕ`��    
    assignin( "caller", "rePlotFlag", 1 );
    assignin( "caller", "figLmLine", parent );
    try
        evalin( "caller", "PlotLmLine" );
    catch ME
        evalin( "caller", "clear rePlotFlag;" );
        rethrow( ME );
    end
    evalin( "caller", "clear rePlotFlag;" );
end