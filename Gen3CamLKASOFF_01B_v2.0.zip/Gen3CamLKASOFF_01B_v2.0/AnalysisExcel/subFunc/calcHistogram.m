% �q�X�g�O�����o�͎��̃f�[�^�T���v���͈͂���͂��邱��
startIndex = 1; endIndex = samples;
numBins = 20;
swOutlier = 0;
outlier = 40;
outlierIndex = [];
% LM���H���x�̓��v����
if swWidth == 1
    analysisData = tgtDiffw;
else
    analysisData = tgtDiffy;
end
% startIndex = checkAnalysisStartIndex( analysisData, outlier );

fprintf( "���v���\n" );
[ sgm2ZoneMin, sgm2ZoneMax ] = calcHistogramFunc( analysisData, numBins,  startIndex, endIndex, swOutlier, outlier, outlierIndex );  
if swComp
    for dc = 1:compDataNum
        if swRoadWidth == 1
            analysisDataOrg{dc} = tgtDiffWOrg{dc};
        else
            analysisDataOrg{dc} = tgtDiffyOrg{dc};
        end
        fprintf( "��r��%d\n", dc );
        [ sgm2ZoneMin, sgm2ZoneMax ] = calcHistogramFunc( analysisDataOrg{dc}, numBins,  startIndex, endIndex, swOutlier, outlier, outlierIndex );  
    end
end
            
function [ sgm2ZoneMin, sgm2ZoneMax ] = calcHistogramFunc( inputData, numBins, startIndex, endIndex, swOutlier, outlier, outlierIndex )

    var = inputData;
    if length(startIndex) == 1
        varEv = zeros(length(startIndex:endIndex),1);
    else
        varEv = zeros(length(startIndex(1):endIndex(1))+length(startIndex(2):endIndex(2)),1);
    end
    cnt = 1;
    for idxNo = 1:length(startIndex)
        for i=startIndex(idxNo):endIndex(idxNo)
            if swOutlier
                forceEndFlg= 0;
                for j =1:length(outlierIndex)
                    if i == outlierIndex(j)
                        forceEndFlg = 1;
                        continue;
                    end
                end
                if forceEndFlg
                    continue;
                end
            end
            if (~isnan(var(i))) && (var(i)<outlier)
                varEv(cnt) = var(i);
                cnt = cnt + 1;
            end
    %     fprintf(1,'%d�ӏ��� %d�C���f�b�N�X %d���[�v\n',idxNo,i,cnt)
        end
    end
    fprintf(1,'%d���[�v\n',cnt)

    ave = mean(varEv);
    sgm = std(varEv);
    sgm2ZoneMin = ave - 2*sgm;
    sgm2ZoneMax = ave + 2*sgm;
    fprintf(1,'ave = %f\n',ave);
    fprintf(1,'2��Max = %f\n',sgm2ZoneMax);
    fprintf(1,'2��Min = %f\n',sgm2ZoneMin);
    fprintf(1,'2�� = %f\n',2*sgm);

    figure(666); clf;
    h = histogram(varEv,1000);
%     xlim([-0.5 0.5]);
%     xticks([-0.8:0.1:0.8]);
    hold on; grid on;
    h.NumBins = numBins;
    xline(sgm2ZoneMax,'r-', 'LineWidth',2);
    xline(sgm2ZoneMin,'r-', 'LineWidth',2);
end


function startIndex = checkAnalysisStartIndex( inputData, outlier )
%% �ǂ̃T���v�����O���琸�x�]�����J�n�����2�Ђ̒l���ǂ��Ȃ邩�𒲍�����X�N���v�g
    cntJ = 0;
    var = inputData;
    for j = 0:0.2:700
        cntJ= cntJ + 1;
%         fprintf(1,'start j = %3.1f\n',j);
        startSmpl = uint16(j * 5 + 1);
        endSmpl = uint16( length( inputData ) );
        startT(cntJ) = j;
        clear varEv
        varEv = zeros(length(startSmpl:endSmpl),1);
        cnt = 0;
        for i=startSmpl:endSmpl
            if (~isnan(var(i))) && (var(i)<outlier)
                cnt = cnt + 1;
                varEv(cnt) = var(i);
            end
        end

        ave = mean(varEv);
        sgm(cntJ) = std(varEv);
    end

    figure(6666); clf;
    hold on; grid on;
    plot(startT,2*sgm,'r.-');
    
    [ ~, startIndex ] = min( sgm );

end
