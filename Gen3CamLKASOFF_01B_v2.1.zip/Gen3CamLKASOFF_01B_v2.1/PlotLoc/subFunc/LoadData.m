
if swCANape
    matName = OnlyMF4DataPath;
    sigSetCom = {'Group1Time',...
        'Group2Time',...
        'Group3Time',...
        'saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log',...
        'saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log',...
        'saTldMiBusOut_lmTldCamBusOut_lmCamBusOut_log',...
        'saTldMiBusOut_lmTldMapBusOut_lmTldMapDebugBusOut_log',...
        'saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log',...
        'saTldMiBusOut_ahdfCp2ApBusOut_tc10mMeBusOut_log',...
        'saTldMiBusOut_fcCamBusOut_saCf1LaneBusOut_log',...
        'saTldLaneCnvBusOut_saCurrentCtrlBusOut_log', ...
        'saTldLaneCnvBusOut_saCurrentCamBusOut_log', ...
        'saTldClineCnvBusOut_saFcLaneBusOut_log', ...
        };

    tic;
    load(matName,sigSetCom{:});
    fprintf('     ⇒処理時間：%.1f[s]\n',toc);
else
    matName = dataPath;

    sigSetCom = {'S_lmInhStt', ...
        'S_lmVecCtrlLnPntCurvature', ...
        'S_lmVecCtrlLnPntX', ...
        'S_lmVecCtrlLnPntY', ...
        'S_lmVecClinePointPosY_Cam',...
        'S_lmVecClineProbability_Cam', ...
        'S_lmVecClineQuality_Cam', ...
        'S_lmVecClineType_Cam', ...
        'S_lmPldStt',...
        'S_lmslLeftLcFlg',...
        'S_lmslRightLcFlg',...
        'S_saEgo50BusMovXYR',...
        'S_lmCtrlLnExistFlg', ...
        'S_saEgoSpd',...
        'S_Group1Time', ...
        };

    warning_state = warning;
    warning('off');
    tic;
    fprintf( "  ・Data Loading 1" );
    load(matName,sigSetCom{:});
    fprintf('     ⇒処理時間：%.1f[s]\n',toc);
end


if swCANape == 1
    % Group1Timeと50ms周期で計測している変数の配列数が違う際の処理
    GroupTimeTmp = Group1Time; clear Group1Time;
    Group1Time = TimeColAdjst(GroupTimeTmp, length(saTldLaneCnvBusOut_saCurrentCtrlBusOut_log.saCtrlLnMode.signals.values(:,1)));
    clear GroupTimeTmp;
    % Group2Timeと100ms周期で計測している変数の配列数が違う際の処理
    if exist('Group3Time')
        fprintf('\nGroup3Timeを100msの時間信号として使います。\n');
        clear Group2Time;
        Group2Time = Group3Time;
    end
    GroupTimeTmp = Group2Time; clear Group2Time;
    Group2Time = TimeColAdjst(GroupTimeTmp, length(saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmPldStt.signals.values(:,1)));
    clear GroupTimeTmp;
    time = Group1Time;
elseif swCANape == 0
    time = S_Group1Time.signals.values;
    onFlg = 0;
    for i = 2:length(time)
        if time(i) ~= 0
            not0TimeSmpl = i;
            onFlg = 1;
        elseif onFlg
            time(i) = time(not0TimeSmpl)+(i-not0TimeSmpl)*0.05;
        end
    end    
end

if swCANape == 1
    
    try
        S_lmInhSttTmp = saTldMiBusOut_lmTldMapBusOut_lmSttBusOut_log.lmInhStt;
    catch
        S_lmInhSttTmp.signals.values = zeros(length(time),1);
    end

    % 点列位置X, Y
    S_lmVecCtrlLnPntXTmp.signals.values = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntX.signals.values;
    S_lmVecCtrlLnPntYTmp.signals.values = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntY.signals.values;
    % 車線有効フラグ
    S_lmCtrlLnExistFlgTmp = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnExistFlg;

    S_lmVecClinePointPosY = saTldLaneCnvBusOut_saCurrentCamBusOut_log.saVecClinePointPosY;


    % 道路曲率
    S_lmVecCtrlLnPntCurvatureTmp = saTldMiBusOut_lmTldMapBusOut_lmCtrlBusOut_log.lmVecCtrlLnPntCurvature;

    S_egoSpd = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoSpd;

    % 自車横点ステータス
    S_MElaneExistenceProb.signals.values = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadConf.signals.values;
    S_MElaneQuality.signals.values = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadQuality.signals.values;
    S_MElaneType.signals.values = saTldClineCnvBusOut_saFcLaneBusOut_log.saVecFcRoadType.signals.values;

    S_lmodEgoMovX = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoMovX;
    S_lmodEgoMovY = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoMovY;
    S_lmodEgoRot = saTldMiBusOut_saTldEgoMovBusOut_saEgo50BusOut_log.saEgoRot;

    S_lmInhStt.signals.values = zeros(length(time),1);
    S_lmVecCtrlLnPntX.signals.values = zeros(length(time),1353);
    S_lmVecCtrlLnPntY.signals.values = zeros(length(time),1353);
    S_lmCtrlLnExistFlg.signals.values = zeros(length(time),3);
    S_lmVecCtrlLnPntCurvature.signals.values = zeros(length(time),1353);
    for i = 1:length(Group1Time)
        for j = 2:length(Group2Time(1:end-1))
            if Group1Time(i)>Group2Time(j-1) && Group1Time(i)<=Group2Time(j)
                S_lmInhStt.signals.values(i,:) = S_lmInhSttTmp.signals.values(j,:);
                S_lmVecCtrlLnPntX.signals.values(i,:) = S_lmVecCtrlLnPntXTmp.signals.values(j,:);
                S_lmVecCtrlLnPntY.signals.values(i,:) = S_lmVecCtrlLnPntYTmp.signals.values(j,:);
                S_lmCtrlLnExistFlg.signals.values(i,:) = S_lmCtrlLnExistFlgTmp.signals.values(j,:);
                S_lmVecCtrlLnPntCurvature.signals.values(i,:) = S_lmVecCtrlLnPntCurvatureTmp.signals.values(j,:);
                break;
            end
        end
    end

elseif swCANape == 0
    S_lmVecClinePointPosY.signals.values = S_lmVecClinePointPosY_Cam.signals.values;
    S_egoSpd.signals.values = S_saEgoSpd.signals.values;

    S_lmodEgoMovX.signals.values(:,1) = S_saEgo50BusMovXYR.signals.values(:,1);
    S_lmodEgoMovY.signals.values(:,1) = S_saEgo50BusMovXYR.signals.values(:,2);
    S_lmodEgoRot.signals.values(:,1) = S_saEgo50BusMovXYR.signals.values(:,3); 

    S_MElaneExistenceProb.signals.values = S_lmVecClineProbability_Cam.signals.values;
	S_MElaneType.signals.values = S_lmVecClineType_Cam.signals.values;
    S_MElaneQuality.signals.values = S_lmVecClineQuality_Cam.signals.values;
end

% LCしている箇所をCtrl車線の自車横跳びで判断
if exist('S_lmslLeftLcFlg')==0
    S_lmslLeftLcFlg.signals.values = CalcCtrlJump(...
        S_lmCtrlLnExistFlg.signals.values(:, 2), ...
        S_lmVecCtrlLnPntY.signals.values(:,602), ...
        time);
    % 後でleftとrightでxorをとるのでrightは0で良い
end

if exist('S_lmslRightLcFlg') == 0
    S_lmslRightLcFlg.signals.values = zeros(length(time),1);
end


% setData.m
samples = length(time);
% LM内部信号格納
lmInhStt = S_lmInhStt.signals.values;
eMap = bitget( lmInhStt, 3 );

% 点列位置X, Y
lmCtrlX = S_lmVecCtrlLnPntX.signals.values;
lmCtrlY = S_lmVecCtrlLnPntY.signals.values;
% 車線有効フラグ
cOutFlg = S_lmCtrlLnExistFlg.signals.values;

lmCamY = S_lmVecClinePointPosY.signals.values;


% 道路曲率
curv(:,1) = S_lmVecCtrlLnPntCurvature.signals.values(:,151);
curv(:,2) = S_lmVecCtrlLnPntCurvature.signals.values(:,151+451);
curv(:,3) = S_lmVecCtrlLnPntCurvature.signals.values(:,151+451*2);
egoSpd = S_egoSpd.signals.values;

% 自車横点ステータス
laneConfidence = S_MElaneExistenceProb.signals.values(:,1:4);   % エラー回避用スクリプト
laneQuality = S_MElaneQuality.signals.values(:,1:4);                    % エラー回避用スクリプト
laneType = S_MElaneType.signals.values(:,1:4);                          % エラー回避用スクリプト

if sw3dOdo
    if exist('S_lmodEgoMov3DX', 'var')
        EgoMovX = S_lmodEgoMov3DX.signals.values(:,1);
        EgoMovY = S_lmodEgoMov3DY.signals.values(:,1);
        EgoRot = S_lmodEgo3DR.signals.values(:,1);
    else
        fprintf(1,'\n2次元オドメトリから可変周期のECU動作に合わせてオドメトリ量の計算を開始します。\n');
        EgoMovX = modmov(S_lmodEgoMovX.signals.values(:,1),time,0.05,0);
        EgoMovY = modmov(S_lmodEgoMovY.signals.values(:,1),time,0.05,0);
        EgoRot = modmov(S_lmodEgoRot.signals.values(:,1),time,0.05,0);
    end
else
    EgoMovX = S_lmodEgoMovX.signals.values(:,1);
    EgoMovY = S_lmodEgoMovY.signals.values(:,1);
    EgoRot = S_lmodEgoRot.signals.values(:,1);
end


function ctrlJump = CalcCtrlJump(exist_flg, ctrl_y, time)
    ctrlJump = zeros(length(time),1);
    for i = 2:length(time)
        if exist_flg(i) == 0 || exist_flg(i - 1) == 0
            % Ctrl車線がないので何も見ない
            continue;
        end
        if abs(ctrl_y(i) - ctrl_y(i - 1)) > 2
            ctrlJump(i) = 1;
        end
    end
end

function mov = modmov(movraw,time,unitsec,mode)
    tmp = movraw;

    if size(time,1) == 1
        difftime = [0 diff(time)];
    else
        difftime = [0;diff(time)];
    end
    for i = 2:length(movraw)
        if difftime(i) > unitsec
            if mode ==0
                tmp(i) = (movraw(i)*(difftime(i)+ unitsec)   + movraw(i-1)*(difftime(i)-unitsec))/(2*unitsec);
            else
                tmp(i) = movraw(i)*(difftime(i)/unitsec);
            end
        end
    end
    mov = tmp;
end

function GroupTime = TimeColAdjst(GroupTimeIn, varLen)
    % Group2Timeと100ms周期で計測している変数の配列数が違う際の処理
    lenGroupTime = length(GroupTimeIn);
    lenGroupTimeVar = varLen;
    if lenGroupTime > lenGroupTimeVar
        GroupTime = GroupTimeIn(1:end-1);
    elseif lenGroupTime < lenGroupTimeVar
        GroupTime = [GroupTimeIn(1:end) GroupTimeIn(end)+0.1];
    else
        GroupTime = GroupTimeIn;
    end
end
