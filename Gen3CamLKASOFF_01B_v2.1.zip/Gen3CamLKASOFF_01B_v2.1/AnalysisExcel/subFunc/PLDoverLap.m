global n v;
clearvars obj obj1;
warning('off','MATLAB:declareGlobalBeforeUse');
n = 1;
v = 0;
obj(1).text = "";
obj(1).length = double(0);
obj(1).startEnd = [0,0];
obj(1).listName = "777";
for i = 1:10
    col = chkFlgNameList(:,i);
    col = char(col);
    col = col(1:3);
    intervals = find_intervals(chkFlgListTmp(:,i));
    if ~isempty(intervals)
        [a,b] = size(intervals);
        for j = 1:a
            obj = compareObj(intervals(j,:),n,col,obj);
        end
    end
end
obj1(1).text = "";
obj1(1).length = double(0);
obj1(1).startEnd = [0,0];
obj1(1).listName = "777";
for i = 1:length(obj)
    if length(obj(i).text)>3
        l = length(obj1);
        obj1(l+1) = obj(i);
    end
end

for i = 2:length(obj1)
    intervals(i-1,1) = obj1(i).startEnd(1,1);
    intervals(i-1,2) = obj1(i).startEnd(1,2);
    intervals(i-1,3) = double(string(obj1(i).listName));
end
if ~isempty(intervals)
    [groups, groupIntervals] = findContinuousOverlaps(intervals);
    intervals = sortrows(intervals, 1);
    intervals = num2cell(intervals);
    for i = 1:length(groupIntervals)
        intervals(max(cell2mat(groupIntervals(1,i))),4) = cellstr("1");
    end
    [a,~] = size(intervals);
    startIndex = 1;
    endIndex = 1;
    outputList = [];
    while(endIndex<=a)
        if isequal(intervals(endIndex,4),cellstr("1"))
            outRange = intervals(startIndex:endIndex,1:3);
            [row,col] = size(outRange);
            outputList = outputIssue(outRange,row,outputList);
            startIndex = endIndex + 1;
        end
        endIndex = endIndex + 1;
    end
    for i = 1:a-1
        if cell2mat(intervals(i,3)) == 732 && cell2mat(intervals(i+1,3)) == 728 && ~isequal(intervals(i,4),cellstr("1"))
            [l,~] = size(outputList);
            outputList(l+1,:) = cell2mat(intervals(i+1,1:3));
        end
    end
    if ~isempty(outputList)
        output = transpose(strcat(string(outputList(:,3)),'_',string(outputList(:,1)+1)));
        output = unique(output,'stable');
    else
        output = string([]);
    end
else
    output = string([]);
end

function outputList = outputIssue(outRange,row,outputList)
    if (cell2mat(outRange(1,3)) == 711 || cell2mat(outRange(1,3)) == 710 || cell2mat(outRange(1,3)) == 731) && row ~= 1
        [l,~] = size(outputList);
        outputList(l+1,:) = cell2mat(outRange(2,:));
        outRange = outRange(2:end,:);
        [row,~] = size(outRange);
        outputList = outputIssue(outRange,row,outputList);
    end
end

function [groups, groupIntervals] = findContinuousOverlaps(intervals)
    sortedIntervals = sortrows(intervals, 1);
    numIntervals = size(sortedIntervals, 1);
    groups = [];
    groupIntervals = {};
    
    currentStart = sortedIntervals(1,1);
    currentEnd = sortedIntervals(1,2);
    groupIndices = [1];
    
    for i = 2:numIntervals
        if sortedIntervals(i,1) <= currentEnd
            currentEnd = max(currentEnd, sortedIntervals(i,2));
            groupIndices(end+1) = i;
        else
            groups(end+1, :) = [currentStart, currentEnd];
            groupIntervals{end+1} = groupIndices;
            currentStart = sortedIntervals(i,1);
            currentEnd = sortedIntervals(i,2);
            groupIndices = [i];
        end
    end
    groups(end+1, :) = [currentStart, currentEnd];
    groupIntervals{end+1} = groupIndices;
end

function [intervals] = find_intervals(vec)
    vec = double(vec);
    transitions = diff(vec);
    if vec(1,1) == 1
        starts(1,1) = 1;
        starts1 = find(transitions == 1);
        starts = vertcat(starts,starts1);
    else
       starts = find(transitions == 1); 
    end
    ends = find(transitions == -1) + 1;
    if vec(end) == 1
        ends(end+1,1) = length(vec);
    end
    intervals = [starts,ends];
end

function obj = compareObj(interval,n,col,obj)
    global n;
    a = 0;
    for o = 1:length(obj)
        interval1 = obj(o).startEnd;
        overlap = interval(1,1) < interval1(1,2) && interval1(1,1) < interval(1,2);
        if overlap
            obj = myStruct(interval,n,col,obj,o,a);
            a = 1;
        end
    end
    if ~a
        obj(n).text = col;
        obj(n).length = interval(1,2) - interval(1,1) + 1;
        obj(n).startEnd = interval;
        obj(n).listName = col;
        if n == 1
        end
            n = n + 1;
    end
end

function obj = myStruct(interval,n,col,obj,o,a)
    global n;
    if a == 0
        n = n;
    else
        n = n - 1;
    end
    if ~contains(obj(o).text,col)
        obj(n).text = strcat(obj(o).text,col);
        obj(o).text = strcat(obj(o).text,col);
    elseif contains(obj(o).text,col) && length(obj(o).text)>3
        obj(n).text = obj(o).text;
    else
        obj(n).text = obj(o).text;
    end
    obj(n).length = interval(2) - interval(1) + 1;
    obj(n).startEnd = interval;
    obj(n).listName = col;
    n = n + 1;
end