function [ TransClineCPosX, TransClineCPosY, TransClineLPosX, TransClineLPosY, TransClineRPosX, TransClineRPosY, TransClineLStt, TransClineRStt, TransClineCStt ] = makeC0Trace( EgoMovX, EgoMovY, EgoRot, lmCamY, C0LngSmpl, swC0Stt, c0ValidFlg )
    for j=1:4
        for i=1:251
            ClinePointY(i,j,:) = lmCamY(:,(251*(j-1))+i);
        end
    end

    ClineLPosY = squeeze(ClinePointY(101,1,:));
    ClineLPosX = zeros(size(ClineLPosY));
    ClineRPosY = squeeze(ClinePointY(101,2,:));
    ClineRPosX = zeros(size(ClineRPosY));

    TransClineLPosX = zeros(length( EgoMovX ),201);     % �G���[���p�ɏC��
    TransClineLPosY = zeros(length( EgoMovX ),201);     % �G���[���p�ɏC��
    TransClineRPosX = zeros(length( EgoMovX ),201);     % �G���[���p�ɏC��
    TransClineRPosY = zeros(length( EgoMovX ),201);     % �G���[���p�ɏC��
    TransClineCPosX = zeros(length( EgoMovX ),201);
    TransClineCPosY = zeros(length( EgoMovX ),201);
    if swC0Stt
        TransClineLStt = zeros(length( EgoMovX ),201);      % �G���[���p�ɏC��
        TransClineRStt = zeros(length( EgoMovX ),201);      % �G���[���p�ɏC��
        TransClineCStt = zeros(length( EgoMovX ),201);
    end
    
    samples = min(length(TransClineLPosX),length(ClineLPosY));

    EgoPosRot = zeros(1, size(EgoRot,1));
    for i=2:samples
        EgoPosRot(i) = EgoPosRot(i-1) + EgoRot(i);
    end
    
    for i=1:samples
    %       fprintf('loop%d���\n',i);
    %             fprintf('�J�����O�Ճf�[�^�쐬\n');
        if i+C0LngSmpl < samples
            end_frame = i+C0LngSmpl;
        else
            end_frame = samples;
        end
        if i-C0LngSmpl >= 1
            start_frame = i-C0LngSmpl;
        else
            start_frame = 1;
        end

        TransEgoPosX = [0.];
        TransEgoPosY = [0.];
        TransEgoPosRot = EgoPosRot(:) - EgoPosRot(i);
        % ���
        for j=i-1:-1:start_frame
            TransEgoPosX = [TransEgoPosX(1)-(EgoMovX(j+1)*cos(TransEgoPosRot(j))-EgoMovY(j+1)*sin(TransEgoPosRot(j))) TransEgoPosX];
            TransEgoPosY = [TransEgoPosY(1)-(EgoMovX(j+1)*sin(TransEgoPosRot(j))+EgoMovY(j+1)*cos(TransEgoPosRot(j))) TransEgoPosY];    % �J�����f���Ƃ̔�r�̂��߁A���𕉂Ƃ��Ĉ���
        end
        % �O��
        for j=i+1:end_frame
            TransEgoPosX = [TransEgoPosX TransEgoPosX(end)+(EgoMovX(j)*cos(TransEgoPosRot(j-1))-EgoMovY(j)*sin(TransEgoPosRot(j-1)))];
            TransEgoPosY = [TransEgoPosY TransEgoPosY(end)+(EgoMovX(j)*sin(TransEgoPosRot(j-1))+EgoMovY(j)*cos(TransEgoPosRot(j-1)))];    % �J�����f���Ƃ̔�r�̂��߁A���𕉂Ƃ��Ĉ���
        end

        for j=start_frame:end_frame
            cnt = 0;
            TransClineLPosX(i,j+1-start_frame) = TransEgoPosX(j+1-start_frame) + ClineLPosX(j) * cos(TransEgoPosRot(j)) - ClineLPosY(j) * sin(TransEgoPosRot(j));
            TransClineLPosY(i,j+1-start_frame) = TransEgoPosY(j+1-start_frame) + ClineLPosX(j) * sin(TransEgoPosRot(j)) + ClineLPosY(j) * cos(TransEgoPosRot(j));        
            TransClineRPosX(i,j+1-start_frame) = TransEgoPosX(j+1-start_frame) + ClineRPosX(j) * cos(TransEgoPosRot(j)) - ClineRPosY(j) * sin(TransEgoPosRot(j));
            TransClineRPosY(i,j+1-start_frame) = TransEgoPosY(j+1-start_frame) + ClineRPosX(j) * sin(TransEgoPosRot(j)) + ClineRPosY(j) * cos(TransEgoPosRot(j));

            if ((ClineLPosX(j)==0)&&(ClineLPosY(j)==0))&&~((ClineRPosX(j)==0)&&(ClineRPosY(j)==0))
                TransClineLPosX(i,j+1-start_frame) = NaN;
                TransClineLPosY(i,j+1-start_frame) = NaN;
                cnt = cnt + 1;
            end
            if ((ClineRPosX(j)==0)&&(ClineRPosY(j)==0))&&~((ClineLPosX(j)==0)&&(ClineLPosY(j)==0))
                TransClineRPosX(i,j+1-start_frame) = NaN;
                TransClineRPosY(i,j+1-start_frame) = NaN;
                cnt = cnt + 1;
            end

            % C0���S���v�Z
            if cnt > 0
                TransClineCPosX(i,j+1-start_frame) = NaN;
                TransClineCPosY(i,j+1-start_frame) = NaN;
            else
                TransClineCPosX(i,j+1-start_frame) = (TransClineLPosX(i,j+1-start_frame) + TransClineRPosX(i,j+1-start_frame))/2;
                TransClineCPosY(i,j+1-start_frame) = (TransClineLPosY(i,j+1-start_frame) + TransClineRPosY(i,j+1-start_frame))/2;
            end
            if swC0Stt
                TransClineLStt(i,j+1-start_frame) = c0ValidFlg(j,1);       
                TransClineRStt(i,j+1-start_frame) = c0ValidFlg(j,2);       
                TransClineCStt(i,j+1-start_frame) = c0ValidFlg(j,1).*c0ValidFlg(j,2);       
            end
        end
    end
end