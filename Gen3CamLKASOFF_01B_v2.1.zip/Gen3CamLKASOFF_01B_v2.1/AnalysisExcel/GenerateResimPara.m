function GenerateResimPara(currentDir,NameListOnlyMF4,reapperType)
	sw_DataType = evalin('base', 'sw_DataType');
    time1 = evalin('base', 'curSignalTime');

    if reapperType == "latest"
        dataFolder = fullfile(currentDir,'data','matdata',NameListOnlyMF4.name);
    elseif reapperType == "real"
        dataFolder = fullfile(currentDir,'data','realMatdata',NameListOnlyMF4.name);
    end
    point = double(strrep(strrep(strrep(NameListOnlyMF4.point,'time_',''),'[sec]',''),'.png',''));
    [~, pointr] = min(abs(point - time1));
    point = ceil(pointr);
	if sw_DataType == 1
    	simResNames = dir(strcat(dataFolder,'\*2YCkai_LM*.mat'));
        if isempty(simResNames)
            simResNames = dir(strcat(dataFolder,'\*MAPvcl_LM*.mat'));
        end
	else
		simResNames = dir(strcat(dataFolder,'\*MAPvcl_LM*.mat'));
	end
    simResName = strrep(simResNames.name,'.mat','');
    folderName = split(simResNames.folder,'\');
    folderName = string(folderName(end));
    dirName = strrep(simResNames.folder,folderName,'');
    addpath(genpath('subFunc'))
    PlotLmLine;
    if NameListOnlyMF4.type == "724_CenterLineOfForwardMapIsBroken"
%         if mod(point,0.05)<=0.25
%             point = point-mod(point,0.05);
%         else
%             
%         end
        chkbox_camC0Trace.Value = 0;
        timeEdit_obj.String=string(time1(point));
        RePlotLmLine( timeEdit_obj );
        saveas(figLmLine,fullfile(pwd,'tmpFig','LMMapPic.png'));
        chkbox_camC0Trace.Value = 1;
    end
    ZZ_pickUpIndex = [point-1;point];
    for pickUpIndexCnt=1:length(ZZ_pickUpIndex)
        l=ZZ_pickUpIndex(pickUpIndexCnt);
        xmin1 = -10;  xmax1 = 10;
        ymin1 = -100; ymax1 = 100;

        figPara=figure('visible','off');clf;
        pause(0.00001);
        set(figPara, 'units', 'points', 'Position', get(0,'Screensize'));


        ax99 = subplot(9,4,[1,2,5,6,9,10,13,14,17,18,21,22,25,26,29,30,33,34]);
        swDispCont = [6 4 5 7 8 9];
        chkbox_MapLane.Value = 1;
        SelectPlot2;
        
        ax99.XDir='reverse';

        yline(ax99,egoSpd(l,1)*1.05,'k-','LineWidth',2);

        grid on; hold off;
        title('LM OUTPUT / LINE');    

        XlimTextBox = annotation('textbox', 'Position',[.1 .97 .05 .02], 'LineStyle','none', 'FontSize',10,'String',['fig\_time\_:',sprintf('%0.2f[sec]',time1(l))]);

        axis([xmin1 xmax1 ymin1 ymax1]);

        timeChartIndex = l;
        SetTimePlot_r06;
        RankBTimePlot;

        set(figPara, 'Name', sprintf('fig_time_:%0.2f[sec]',time1(l)));
        if reapperType == "latest"
            picName = strcat("latestPara_",string(pickUpIndexCnt-1),".png");
        elseif reapperType == "real"
            picName = strcat("realPara_",string(pickUpIndexCnt-1),".png");
        end  
        saveas(figPara, strcat(pwd,'\tmpFig\',picName));
        close(figPara);
    end
    rmpath(genpath('subFunc'))
    close all;
end