1. <fix>(判断逻辑): LKASOFF分类DEF判断逻辑修正
