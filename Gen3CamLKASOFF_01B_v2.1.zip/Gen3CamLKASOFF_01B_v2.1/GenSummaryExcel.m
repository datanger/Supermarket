close all;
clear all; clc;
clear,clc;
summaryStartTime = clock;
isQuick = "0";
dataType = "1";
dataLocation = input('please input data location japan/LA/OH :',"s");
if dataType == "0"
    sw_DataType = 0; % 0:OldData_US
    resimMatType = '\MAPvcl_*.mat';
%     writeMatType = 'MAPvcl';
else
    sw_DataType = 1; % 1:JP/NewData_US
    resimMatType = '\2YCkai_*.mat';
%     writeMatType = '2QDkai';
end
VideoTimeInterval = input('please input avi time(300 or 900):',"s");
VideoTimeInterval = str2double(VideoTimeInterval);
writeMatType = input('Car No.:',"s");

selPath = uigetdir('',' Please select Folder contains L01L02_Analysis.xlsx/L03_Analysis.xlsx/chkResultExcel');
latestDataFolder = uigetdir('','Please select latest data folder.');

TemplateFormPath = fullfile(pwd,'�y���H�F���zGEN3�f�[�^��͕\.xlsx');
if exist(fullfile(pwd,'Gen3Excel.xlsx'),'file')
    error(strcat("Error Already exists ",fullfile(pwd,'Gen3Excel.xlsx'),' Please delete Gen3Excel.xlsx'));
    [result,msg] = copyfile(TemplateFormPath,fullfile(pwd,'Gen3Excel.xlsx'));
else
    result = copyfile(TemplateFormPath,fullfile(pwd,'Gen3Excel.xlsx'));
end
TemplateFormPath = fullfile(pwd,'Gen3Excel.xlsx');
filePathDir = dir(selPath);
chkFlgNameList = ["�p�^�[��A","�p�^�[��B","�p�^�[��C","�p�^�[��DEF","Other"];
for i = 3:length(filePathDir)
    namefile = strrep(string(filePathDir(i).name),'.xlsx','');
    if contains(filePathDir(i).name,'�p�^�[��')
        LKAS = 1;
        break;
    end
end
if LKAS == 1
    Excel = actxserver('Excel.Application');
    Workbooks = Excel.Workbook;
    excelFile = Workbooks.Open(TemplateFormPath);
    set(Excel,'Visible',1);
    Sheets = Excel.ActiveWorkBook.Sheets;
    Sheet1 = get(Sheets,'Item',1);
    Sheet1.Activate;
    ReverseMemoSum = [];
    MemoSumlist = [];    
    for i=1:length(chkFlgNameList)   
        excelFilePath = strcat(chkFlgNameList(i),'.xlsx');
        excelName= fullfile(selPath,excelFilePath);
        if isfile(excelName)         
            sheets = sheetnames(excelName);
            for j=1:length(sheets)            
                [~,~,DataDetail] = xlsread(excelName,j,'AB2:AC27');
                AnalysisMemo = DataDetail(:,2);
                ReverseMemoSum = [ReverseMemoSum,AnalysisMemo]; 
            end
        end              
    end
    ReverseMemoSum = [DataDetail(:,1),ReverseMemoSum];
    for k=1:length(ReverseMemoSum(1,:))       
        MemoSum = reshape(ReverseMemoSum(:,k),1,[]);
        MemoSumlist = [MemoSumlist;MemoSum];     
    end
    MemoSumlist(find(cellfun(@(x) any(isnan(x)),MemoSumlist))) = {""};
    MemoSumlist = string(MemoSumlist);
    isEnableRealData = "0";
    info = {};
    info{1,1} = "dataName";
    info{1,2} = "tgtDiffyLatestResim";
    info{1,3} = "tgtDiffyRealResim";
    info{1,4} = "eMapLatestResim";
    info{1,5} = "curvLatestResim";
    info{1,6} = "eMapRealResim";
    info{1,7} = "curvRealResim";
    info{1,8} = "Group1Time";
    info{1,9} = "tgtDiffyOnlyMF4";
    info{1,10} = "time0Resim";
    [row2,~] = size(MemoSumlist);
    count0 = 2;
    for i = 2:row2
        LALinfo = split(MemoSumlist(i,22),',');
        Longitude = LALinfo(2,1);
        Latitude = LALinfo(1,1);
        GoogleMapLink = strcat("https://maps.google.com/maps?q=",num2str(Latitude,'%.20g')," ",num2str(Longitude,'%.20g'));
        displayLink = strcat(num2str(Latitude,'%.20g'),",",num2str(Longitude,'%.20g'));
       
        dataName = MemoSumlist(i,5);
        point = double(MemoSumlist(i,6));
        point = round(point * 20) / 20;
%         if mod(point,0.05)<=0.025
%             point = point-mod(point,0.05);
%         else
%             point = point-mod(point,0.05)+0.05;
%         end
        [row,~] = size(info);
        % firstColumn = info(:,1);
        % % ������?
        % nonEmptyIndices = ~cellfun(@isempty, firstColumn);
        % firstColumnNonEmpty = firstColumn(nonEmptyIndices);

        % % ???��������?
        % tmp = string(firstColumnNonEmpty);
        tmp = string(info(:,1));
        if isempty(find(tmp == dataName)) || row == 1
            latestDataPathDir = dir(fullfile(latestDataFolder,dataName,resimMatType));
            if isempty(latestDataPathDir)
                resimMatType = '\MAPvcl_*.mat';
%                 writeMatType = '2QDkai';
                latestDataPathDir = dir(fullfile(latestDataFolder,dataName,resimMatType));
            end

            latestDataPath = fullfile(latestDataPathDir.folder,latestDataPathDir.name);
            realDataPath = [];
            OnlyMF4DataDir = dir(fullfile(latestDataFolder,dataName,'*_ACore_XCP_remap.mat'));
            OnlyMF4DataPath = fullfile(OnlyMF4DataDir.folder,OnlyMF4DataDir.name);
            clearvars tgtDiffy eMap curv tgtDiffyLatestResim eMapLatestResim curvLatestResim
            if ~isempty(latestDataPath)
                if isQuick == "0"
                    [tgtDiffy,eMap,curv,time0] = GenerateResim(latestDataPath,dataName,sw_DataType);
                    tgtDiffyLatestResim = tgtDiffy;
                    eMapLatestResim = eMap;
                    curvLatestResim = curv;
                    time0Resim = time0;
                else
                    tgtDiffyLatestResim = [];
                    eMapLatestResim = [];
                    curvLatestResim = [];
                    time0Resim = []; 
                end
            end
            clearvars tgtDiffy eMap curv tgtDiffyRealResim eMapRealResim curvRealResim
            if ~isempty(realDataPath)  
                [tgtDiffy,eMap,curv,time0] = GenerateResim(realDataPath,dataName,sw_DataType);
                tgtDiffyRealResim = tgtDiffy;
                eMapRealResim = eMap;
                curvRealResim = curv;
                time0RealResim = time0;
            else
                tgtDiffyRealResim = [];
                eMapRealResim = [];
                curvRealResim = [];
                time0RealResim = [];
            end
            clearvars tgtDiffy Group1Time egoSpd tgtDiffyOnlyMF4
            if ~isempty(OnlyMF4DataPath)
                if isQuick == "0"
                    [Group1Time,tgtDiffy,egoSpd] = GenerateOnlyMF4(OnlyMF4DataPath,dataName,sw_DataType);
                    tgtDiffyOnlyMF4 = tgtDiffy;
                else
                    Group1Time = [];
                    tgtDiffyOnlyMF4 = [];
                end
            end
            if ~isempty(Group1Time)
                onlyMF4Point = double(MemoSumlist(i,6));
                [~, onlyMF4Index] = min(abs(onlyMF4Point - Group1Time));
            else
                onlyMF4Index = 1;
            end

%             for ii = 1:length(Group1Time)
%                 if abs(double(Group1Time(ii))-onlyMF4Point)<0.01
%                     onlyMF4Index = ii;
%                     break
%                 end
%             end
            info{count0,1} = dataName;
            info{count0,2} = tgtDiffyLatestResim;
            info{count0,3} = tgtDiffyRealResim;
            info{count0,4} = eMapLatestResim;
            info{count0,5} = curvLatestResim;
            info{count0,6} = eMapRealResim;
            info{count0,7} = curvRealResim;
            info{count0,8} = Group1Time;
            info{count0,9} = tgtDiffyOnlyMF4;
            info{count0,10} = time0Resim;
            count0 = count0 + 1;
            if ~isempty(tgtDiffyOnlyMF4)
                DiscrepancyOnlyMF4 = tgtDiffyOnlyMF4(onlyMF4Index);
                if isnan(DiscrepancyOnlyMF4)
                    DiscrepancyOnlyMF4 = "NaN";
                end
            else
                DiscrepancyOnlyMF4 = "";
            end
            % load(latestDataPath,'S_Group1Time');
            % time0 = S_Group1Time.signals.values;
            if ~isempty(time0Resim)
                [~, pointr] = min(abs(point - time0Resim));
            else
                pointr = 1;
            end
            if ~isempty(tgtDiffyLatestResim)
                DiscrepancyLatestResim = tgtDiffyLatestResim(pointr);
                if isnan(DiscrepancyLatestResim)
                    DiscrepancyLatestResim = "NaN";
                end
            else
                DiscrepancyLatestResim = "";
            end
            if ~isempty(eMapLatestResim)
                eMapLatestValue = eMapLatestResim(pointr);
            else
                eMapLatestValue = "";
            end
            if ~isempty(curvLatestResim)
                curvLatestValue = curvLatestResim(pointr);
            else
                curvLatestValue = "";
            end
            if ~isempty(tgtDiffyRealResim)
                DiscrepancyRealResim = tgtDiffyRealResim(pointr);
                if isnan(DiscrepancyRealResim)
                    DiscrepancyRealResim = "NaN";
                end
            else
                DiscrepancyRealResim = "";
            end
            if ~isempty(eMapRealResim)
                eMapRealValue = string(eMapRealResim(pointr));
            else
                eMapRealValue = "";
            end
            if ~isempty(curvRealResim)
                curvRealValue = curvRealResim(pointr);
            else
                curvRealValue = "";
            end
        else
            index = find(tmp == dataName);
            time = info{index,8};
            onlyMF4Point = double(MemoSumlist(i,6));
            
            if ~isempty(time)
                [~, onlyMF4Index] = min(abs(onlyMF4Point - time));
            else
                onlyMF4Index = 1;
            end
            
%             for ii = 1:length(time)
%                 if abs(double(time(ii))-onlyMF4Point)<0.01
%                     onlyMF4Index = ii;
%                     break
%                 end
%             end
            tgtDiffyOnlyMF4 = info{index,9};
            if ~isempty(tgtDiffyOnlyMF4)
                DiscrepancyOnlyMF4 = tgtDiffyOnlyMF4(onlyMF4Index);
                if isnan(DiscrepancyOnlyMF4)
                    DiscrepancyOnlyMF4 = "NaN";
                end
            else
                DiscrepancyOnlyMF4 = "";
            end

            
            time0Resim = info{index,10};
            if ~isempty(time0Resim)
                [~, pointr] = min(abs(onlyMF4Point - time0Resim));
            else
                pointr = 1;
            end
            tgtDiffyLatestResim = info{index,2};
            if ~isempty(tgtDiffyLatestResim)
                DiscrepancyLatestResim = tgtDiffyLatestResim(pointr);
                if isnan(DiscrepancyLatestResim)
                    DiscrepancyLatestResim = "NaN";
                end
            else
                DiscrepancyLatestResim = "";
            end
            eMapLatestResim = info{index,4};
            if ~isempty(eMapLatestResim)
                eMapLatestValue = eMapLatestResim(pointr);
            else
                eMapLatestValue = "";
            end
            curvLatestResim = info{index,5};
            if ~isempty(curvLatestResim)
                curvLatestValue = curvLatestResim(pointr);
            else
                curvLatestValue = "";
            end

            if ~isempty(tgtDiffyRealResim)
                tgtDiffyRealResim = info{index,3};
                DiscrepancyRealResim = tgtDiffyRealResim(pointr);
                if isnan(DiscrepancyRealResim)
                    DiscrepancyRealResim = "NaN";
                end
            else
                DiscrepancyRealResim = "";
            end
            if ~isempty(eMapRealResim)
                eMapRealResim = info{index,6};
                eMapRealValue = eMapRealResim(pointr);
            else
                eMapRealValue = "";
            end
            if ~isempty(curvRealResim)
                curvRealResim = info{index,7};
                curvRealValue = curvRealResim(pointr);
            else
                curvRealValue = "";
            end
        end
        if (isEnableRealData == "1") && curvRealValue>1000
            curvRealValue = "1000�ȏ�";
        end
        if isnumeric(curvLatestValue) && curvLatestValue>1000
            curvLatestValue = "1000�ȏ�";
        end
        
        % Location
        Sheet1.Range(strcat('C',string(i-1+6))).value = dataLocation;

        % GNSS�ܓx�o�x(GoogleMap�����N)
        obj = Sheet1.Range(strcat('M',string(i-1+6)));
        obj.Hyperlinks.Add(obj, GoogleMapLink,"","",displayLink);
        % PLDStt
        Sheet1.Range(strcat("D",string(i-1+6))).value = MemoSumlist(i,2);
        % �\�t�gVer
        Sheet1.Range(strcat("K",string(i-1+6))).value = "";
        % �\�t�gVer �ŐV
        Sheet1.Range(strcat("L",string(i-1+6))).value = MemoSumlist(i,7);
        % ���ޔԍ�
        Sheet1.Range(strcat("E",string(i-1+6))).value = MemoSumlist(i,23);
        
        % �ԗ�No.
        Sheet1.Range(strcat("O",string(i-1+6))).value = writeMatType;
        % BLF�f�[�^��� �t�@�C����
        Sheet1.Range(strcat("Q",string(i-1+6))).value = MemoSumlist(i,5);
        % BLF�f�[�^��� ����[s]
        Sheet1.Range(strcat("R",string(i-1+6))).value = MemoSumlist(i,6);
        % MF4�f�[�^��� �t�@�C����
        Sheet1.Range(strcat("S",string(i-1+6))).value = MemoSumlist(i,3);
        % MF4�f�[�^��� ����[s]
        Sheet1.Range(strcat("T",string(i-1+6))).value = MemoSumlist(i,4);

        % �Č��� �ŐVResim����
%         Sheet1.Range(strcat("V",string(i-1+6))).value = MemoSumlist(i,8);
        % ���H�덷��[m]L0102��͂ł͋L�ڂ��Ȃ� MF4
        Sheet1.Range(strcat("W",string(i-1+6))).value = string(DiscrepancyOnlyMF4);

        % ���H�덷��[m]L0102��͂ł͋L�ڂ��Ȃ� �ŐVresim����
        Sheet1.Range(strcat("Y",string(i-1+6))).value = string(DiscrepancyLatestResim);
        % eMap�l �ŐVresim����
        Sheet1.Range(strcat("AA",string(i-1+6))).value = string(eMapLatestValue);
        % ���H�ȗ����a[R] �ŐVresim����
        Sheet1.Range(strcat("AC",string(i-1+6))).value = string(curvLatestValue);

        if isEnableRealData == "1"
            % ���H�덷��[m]L0102��͂ł͋L�ڂ��Ȃ� ����resim����
            Sheet1.Range(strcat("X",string(i-1+6))).value = string(DiscrepancyRealResim);
            % eMap�l ����resim����
            Sheet1.Range(strcat("Z",string(i-1+6))).value = string(eMapRealValue);
            % ���H�ȗ����a[R] ����resim����
            Sheet1.Range(strcat("AB",string(i-1+6))).value = string(curvRealValue);
            % �Č��� ����Resim����
            Sheet1.Range(strcat("U",string(i-1+6))).value = MemoSumlist(i,10);
        else
            % ���H�덷��[m]L0102��͂ł͋L�ڂ��Ȃ� ����resim����
            Sheet1.Range(strcat("X",string(i-1+6))).value = "-";
            % eMap�l ����resim����
            Sheet1.Range(strcat("Z",string(i-1+6))).value = "-";
            % ���H�ȗ����a[R] ����resim����
            Sheet1.Range(strcat("AB",string(i-1+6))).value = "-";
            % �Č��� ����Resim����
            Sheet1.Range(strcat("U",string(i-1+6))).value = "-";
        end

        % �ԑ�[km/h]
        Sheet1.Range(strcat("AD",string(i-1+6))).value = MemoSumlist(i,8);
        % �V�C
        Sheet1.Range(strcat("AE",string(i-1+6))).value = MemoSumlist(i,9);
        % �C�x���g���P
        Sheet1.Range(strcat("AF",string(i-1+6))).value = MemoSumlist(i,10);
        % �C�x���g���2
        Sheet1.Range(strcat("AG",string(i-1+6))).value = MemoSumlist(i,11);
        % �C�x���g���3
        Sheet1.Range(strcat("AH",string(i-1+6))).value = MemoSumlist(i,12);
        % �H�ʏ��1
        Sheet1.Range(strcat("AI",string(i-1+6))).value = MemoSumlist(i,13);
        % �H�ʏ��2
        Sheet1.Range(strcat("AJ",string(i-1+6))).value = MemoSumlist(i,14);
        % �ԗ��󋵂P
        Sheet1.Range(strcat("AK",string(i-1+6))).value = MemoSumlist(i,15);
        % �ԗ���2
        Sheet1.Range(strcat("AL",string(i-1+6))).value = MemoSumlist(i,16);
        % ���W�󋵂P
        Sheet1.Range(strcat("AM",string(i-1+6))).value = MemoSumlist(i,17);
        % ���W��2
        Sheet1.Range(strcat("AN",string(i-1+6))).value = MemoSumlist(i,18);
        % �������
        Sheet1.Range(strcat("AO",string(i-1+6))).value = MemoSumlist(i,19);
        % �����F
        Sheet1.Range(strcat("AP",string(i-1+6))).value = MemoSumlist(i,20);
        % �������
        Sheet1.Range(strcat("AQ",string(i-1+6))).value = MemoSumlist(i,21);
        % ���l
        Sheet1.Range(strcat("AS",string(i-1+6))).value = MemoSumlist(i,24);
        % �אڎԐ���Ctrl�Ԑ����o�Ă��Ȃ�/�ُ�̏ꍇ�Ɂ~���L��
        Sheet1.Range(strcat("AX",string(i-1+6))).value = MemoSumlist(i,26);
        excelFile.Save;
    end
    Excel.Quit;
    Excel.delete;
end

summaryEndTime = clock;
elapsed_time = etime(summaryEndTime, summaryStartTime); 
fprintf('total waste time�F%.1f[s]\n', elapsed_time);


function [tgtDiffy,eMap,curv,time0] = GenerateResim(dataPath,dataName,sw_DataType)
    
    fprintf( "~~~~~~~~Resim %s~~~~~~~~\n", dataName);
    addpath(genpath('PlotLoc'));
    folderName = dataName;
    PlotLmLine;
    time0 = time;
    curvR(:,2) = S_lmVecCtrlLnPntCurvature.signals.values(:,151+451);
    curv = 1./abs(curvR(:,2));
    rmpath(genpath('PlotLoc'))
end

function [Group1Time,tgtDiffy,egoSpd] = GenerateOnlyMF4(OnlyMF4DataPath,dataName,sw_DataType)
    fprintf( "~~~~~~~~OnlyMF4 %s~~~~~~~~\n", dataName);
    addpath(genpath('PlotLoc'));
    onlyMF4Flg = 1;

    folderName = dataName;
    PlotLmLine;
    egoSpd = abs(S_egoSpd.signals.values);
    rmpath(genpath('PlotLoc'))
end

function colStr = xlsnum2a(n)
    if n < 1, error('COL NEED >1'); end
    colStr = '';
    while n > 0
        n = n - 1;
        rem = mod(n, 26);
        colStr = [char(65 + rem), colStr]; 
        n = floor(n / 26);
    end
end